# API Reference Documentation

## Overview

The IgniteHub API provides comprehensive access to platform features through RESTful endpoints. This documentation covers all available endpoints, authentication, and integration guidelines.

## Authentication 🔒

### API Keys

ℹ️ **Key Types:**
1. Public Key: For client-side operations
2. Secret Key: For server-side operations
3. Test Keys: For development environment

### Authentication Headers

```http
Authorization: Bearer YOUR_API_KEY
Content-Type: application/json
Accept: application/json
```

## Base URLs 🌐

```
Production: https://api.ignitehub.me/v1
Staging: https://staging-api.ignitehub.me/v1
Development: https://dev-api.ignitehub.me/v1
```

## Rate Limits ⚠️

| Plan | Rate Limit | Burst Limit |
|------|------------|-------------|
| Basic | 100/min | 150/min |
| Pro | 500/min | 750/min |
| Enterprise | Custom | Custom |

## Endpoints Reference 📚

### Authentication Endpoints

#### Login
```http
POST /auth/login
```

**Request Body:**
```json
{
    "email": "user@example.com",
    "password": "secure_password",
    "2fa_code": "123456"  // Optional
}
```

**Response:**
```json
{
    "token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
    "expires_at": "2024-12-31T23:59:59Z",
    "user": {
        "id": 1,
        "email": "user@example.com",
        "role": "user"
    }
}
```

### Services

#### List Services
```http
GET /services
```

**Query Parameters:**
- `page`: Page number (default: 1)
- `limit`: Items per page (default: 10)
- `category`: Filter by category
- `status`: Filter by status

**Response:**
```json
{
    "data": [
        {
            "id": 1,
            "name": "Service Name",
            "description": "Service Description",
            "price": 99.99,
            "category": "Category Name",
            "status": "active"
        }
    ],
    "meta": {
        "current_page": 1,
        "total_pages": 5,
        "total_items": 48
    }
}
```

### Orders

#### Create Order
```http
POST /orders
```

**Request Body:**
```json
{
    "service_id": 1,
    "quantity": 1,
    "requirements": "Order requirements",
    "attachments": ["file1.pdf", "file2.jpg"]
}
```

**Response:**
```json
{
    "order_id": "ORD-123456",
    "status": "pending",
    "total_amount": 99.99,
    "created_at": "2024-01-20T12:00:00Z"
}
```

### Wallet

#### Get Balance
```http
GET /wallet/balance
```

**Response:**
```json
{
    "balance": 500.00,
    "currency": "USD",
    "last_updated": "2024-01-20T12:00:00Z"
}
```

#### Create Transaction
```http
POST /wallet/transactions
```

**Request Body:**
```json
{
    "amount": 100.00,
    "type": "deposit",
    "payment_method": "credit_card"
}
```

### Telegram Bots

#### Create Bot
```http
POST /bots
```

**Request Body:**
```json
{
    "name": "Trading Bot",
    "type": "crypto",
    "settings": {
        "trading_pair": "BTC/USD",
        "strategy": "momentum",
        "risk_level": "medium"
    }
}
```

## Webhook Events 🔔

### Available Events

1. **Order Events**
   - `order.created`
   - `order.updated`
   - `order.completed`
   - `order.cancelled`

2. **Payment Events**
   - `payment.succeeded`
   - `payment.failed`
   - `refund.processed`

### Webhook Format

```json
{
    "event": "order.created",
    "created_at": "2024-01-20T12:00:00Z",
    "data": {
        "order_id": "ORD-123456",
        "status": "pending",
        "amount": 99.99
    }
}
```

## Error Handling ⚠️

### Error Codes

| Code | Description |
|------|-------------|
| 400 | Bad Request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not Found |
| 429 | Too Many Requests |
| 500 | Server Error |

### Error Response Format

```json
{
    "error": {
        "code": "ERROR_CODE",
        "message": "Error description",
        "details": {
            "field": "Additional information"
        }
    }
}
```

## Best Practices 💡

### Security

1. **API Key Security**
   - Never expose secret keys
   - Rotate keys regularly
   - Use environment variables
   - Implement key restrictions

2. **Request Security**
   - Use HTTPS only
   - Validate all inputs
   - Implement timeouts
   - Handle rate limits

### Performance

1. **Optimization**
   - Use pagination
   - Implement caching
   - Minimize request size
   - Batch operations

2. **Error Handling**
   - Implement retries
   - Handle timeouts
   - Log errors
   - Monitor responses

## SDK Support 🔧

### Official SDKs

- PHP: `ignitehub/php-sdk`
- Python: `ignitehub-python`
- JavaScript: `@ignitehub/js-sdk`
- Ruby: `ignitehub-ruby`

### Installation

```bash
# PHP
composer require ignitehub/php-sdk

# Python
pip install ignitehub-python

# JavaScript
npm install @ignitehub/js-sdk

# Ruby
gem install ignitehub-ruby
```

## Testing 🧪

### Test Environment

```bash
# Test API Key
TEST-API-KEY-xxxxx

# Test Webhook
https://webhook.test/ignitehub
```

### Test Cards

| Card Number | Brand | Result |
|------------|-------|---------|
| 4242424242424242 | Visa | Success |
| 4000000000000002 | Visa | Declined |

## Support Resources 📚

### Documentation

- API Reference
- Integration Guides
- Code Examples
- Troubleshooting

### Contact

📧 **Support:**
- Email: api-support@ignitehub.me
- Support tickets
- Developer forum
- API status page

---

Last updated: [Current Date]

⚠️ **Note:** API features and endpoints may be updated. Check regularly for the latest changes.
