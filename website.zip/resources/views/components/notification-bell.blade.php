<div class="dropdown notification-bell">
    <button class="btn btn-link nav-link py-2 px-0 px-lg-2 dropdown-toggle d-flex align-items-center"
            id="notification-dropdown"
            type="button"
            data-bs-toggle="dropdown"
            aria-expanded="false">
        <i class="fas fa-bell"></i>
        @if($unreadCount > 0)
            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                {{ $unreadCount > 99 ? '99+' : $unreadCount }}
                <span class="visually-hidden">unread notifications</span>
            </span>
        @endif
    </button>

    <div class="dropdown-menu dropdown-menu-end notification-dropdown-menu" 
         aria-labelledby="notification-dropdown"
         style="width: 360px; max-height: 480px; overflow-y: auto;">
        <div class="d-flex justify-content-between align-items-center px-3 py-2 border-bottom">
            <h6 class="mb-0">Notifications</h6>
            @if($unreadCount > 0)
                <form action="{{ route('notification-preferences.mark-all-read') }}" method="POST" class="d-inline">
                    @csrf
                    <button type="submit" class="btn btn-link btn-sm text-decoration-none p-0">
                        Mark all read
                    </button>
                </form>
            @endif
        </div>

        @if($notifications->count() > 0)
            <div class="notifications-list">
                @foreach($notifications as $notification)
                    <a href="{{ route('notification-preferences.show', $notification->id) }}" 
                       class="dropdown-item notification-item d-flex align-items-center p-3 border-bottom {{ !$notification->read_at ? 'bg-light' : '' }}">
                        <div class="flex-grow-1 me-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <h6 class="mb-0 text-truncate">
                                    {{ $notification->data['title'] ?? 'Notification' }}
                                </h6>
                                <small class="text-muted ms-2">{{ $notification->created_at->diffForHumans() }}</small>
                            </div>
                            <p class="mb-0 small text-muted text-truncate">
                                {{ $notification->data['message'] ?? '' }}
                            </p>
                        </div>
                        @if(!$notification->read_at)
                            <span class="badge bg-primary rounded-pill">New</span>
                        @endif
                    </a>
                @endforeach
            </div>

            @if($hasMore)
                <div class="p-2 text-center border-top">
                    <a href="{{ route('notification-preferences.index') }}" class="btn btn-link btn-sm text-decoration-none">
                        View All Notifications
                    </a>
                </div>
            @endif
        @else
            <div class="p-4 text-center text-muted">
                <i class="fas fa-bell fa-2x mb-3"></i>
                <p class="mb-0">No notifications</p>
            </div>
        @endif
    </div>
</div>

@push('styles')
<style>
.notification-bell .dropdown-toggle::after {
    display: none;
}

.notification-bell .badge {
    font-size: 0.65em;
}

.notification-dropdown-menu {
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.notification-item {
    transition: background-color 0.2s;
}

.notification-item:hover {
    background-color: #f8f9fa;
}

.notification-item h6 {
    font-size: 0.875rem;
    max-width: 200px;
}

.notification-item p {
    font-size: 0.8125rem;
}

.notification-item .badge {
    font-size: 0.75rem;
}
</style>
@endpush
