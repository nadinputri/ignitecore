<?php

return [
    /*
    |--------------------------------------------------------------------------
    | LLM Configuration
    |--------------------------------------------------------------------------
    |
    | This file contains the configuration settings for the Local LLM integration.
    | These settings control model behavior, resource usage, and safety features.
    |
    */

    'python' => [
        /*
        |--------------------------------------------------------------------------
        | Python Path
        |--------------------------------------------------------------------------
        |
        | Path to the Python executable. This should point to a Python environment
        | with all required dependencies installed.
        |
        */
        'path' => env('LLM_PYTHON_PATH', base_path('venv/bin/python3')),

        /*
        |--------------------------------------------------------------------------
        | Scripts Directory
        |--------------------------------------------------------------------------
        |
        | Directory containing Python scripts for model management and inference.
        |
        */
        'scripts_dir' => base_path('scripts'),
    ],

    'defaults' => [
        /*
        |--------------------------------------------------------------------------
        | Default Model Settings
        |--------------------------------------------------------------------------
        |
        | Default settings for model configuration. These can be overridden
        | through the admin interface or environment variables.
        |
        */
        'model_name' => env('LLM_MODEL_NAME', 'llama2'),
        'model_size' => env('LLM_MODEL_SIZE', '7B'),
        'model_variant' => env('LLM_MODEL_VARIANT', 'chat'),
        'model_path' => env('LLM_MODELS_PATH', storage_path('app/models')),
        'quantization' => env('LLM_QUANTIZATION', '4-bit'),
        'max_tokens' => env('LLM_MAX_TOKENS', 2048),
        'temperature' => env('LLM_TEMPERATURE', 0.7),
    ],

    'models' => [
        /*
        |--------------------------------------------------------------------------
        | Available Models
        |--------------------------------------------------------------------------
        |
        | Configuration for supported models, including available sizes and variants.
        |
        */
        'llama2' => [
            'name' => 'Llama 2',
            'sizes' => ['7B', '13B', '70B'],
            'variants' => ['chat', 'instruct', 'base'],
            'default_size' => '7B',
            'default_variant' => 'chat',
            'repo_id' => 'meta-llama/Llama-2-{size}-{variant}-hf',
            'description' => 'Meta\'s Llama 2 model, optimized for chat and instruction following.',
            'requirements' => [
                'ram' => [
                    '7B' => '16GB',
                    '13B' => '32GB',
                    '70B' => '64GB'
                ],
                'vram' => [
                    '7B' => '8GB',
                    '13B' => '16GB',
                    '70B' => '32GB'
                ]
            ]
        ],
        'mistral' => [
            'name' => 'Mistral',
            'sizes' => ['7B'],
            'variants' => ['instruct', 'base'],
            'default_size' => '7B',
            'default_variant' => 'instruct',
            'repo_id' => 'mistralai/Mistral-{size}B-{variant}-v0.1',
            'description' => 'Mistral\'s efficient and powerful language model.',
            'requirements' => [
                'ram' => [
                    '7B' => '16GB'
                ],
                'vram' => [
                    '7B' => '8GB'
                ]
            ]
        ]
    ],

    'performance' => [
        /*
        |--------------------------------------------------------------------------
        | Performance Settings
        |--------------------------------------------------------------------------
        |
        | Settings that affect model performance and resource usage.
        |
        */
        'batch_size' => env('LLM_BATCH_SIZE', 32),
        'threads' => env('LLM_THREADS', 4),
        'gpu_layers' => env('LLM_GPU_LAYERS', -1),
        'context_window' => env('LLM_CONTEXT_WINDOW', 4096),
    ],

    'cache' => [
        /*
        |--------------------------------------------------------------------------
        | Cache Settings
        |--------------------------------------------------------------------------
        |
        | Configuration for response caching to improve performance.
        |
        */
        'enabled' => env('LLM_CACHE_ENABLED', true),
        'ttl' => env('LLM_CACHE_TTL', 3600),
        'driver' => env('LLM_CACHE_DRIVER', 'redis'),
    ],

    'safety' => [
        /*
        |--------------------------------------------------------------------------
        | Safety Settings
        |--------------------------------------------------------------------------
        |
        | Settings for content filtering and rate limiting.
        |
        */
        'max_requests_per_minute' => env('LLM_MAX_REQUESTS_PER_MINUTE', 60),
        'max_tokens_per_request' => env('LLM_MAX_TOKENS_PER_REQUEST', 4096),
        'content_filtering' => env('LLM_CONTENT_FILTERING', true),
        'blocked_words' => explode(',', env('LLM_BLOCKED_WORDS', '')),
    ],

    'fallback' => [
        /*
        |--------------------------------------------------------------------------
        | Fallback Settings
        |--------------------------------------------------------------------------
        |
        | Configuration for fallback behavior when primary generation fails.
        |
        */
        'enabled' => env('LLM_FALLBACK_ENABLED', true),
        'max_retries' => env('LLM_FALLBACK_MAX_RETRIES', 3),
        'timeout' => env('LLM_FALLBACK_TIMEOUT', 30),
        'response' => env('LLM_FALLBACK_RESPONSE'),
    ],

    'monitoring' => [
        /*
        |--------------------------------------------------------------------------
        | Monitoring Settings
        |--------------------------------------------------------------------------
        |
        | Settings for system monitoring and logging.
        |
        */
        'enabled' => env('LLM_MONITORING_ENABLED', true),
        'log_requests' => env('LLM_LOG_REQUESTS', true),
        'log_responses' => env('LLM_LOG_RESPONSES', true),
        'log_errors' => env('LLM_LOG_ERRORS', true),
        'metrics_enabled' => env('LLM_METRICS_ENABLED', true),
        'log_channel' => env('LLM_LOG_CHANNEL', 'llm'),
    ],

    'paths' => [
        /*
        |--------------------------------------------------------------------------
        | File System Paths
        |--------------------------------------------------------------------------
        |
        | Various paths used by the LLM system.
        |
        */
        'models' => env('LLM_MODELS_PATH', storage_path('app/models')),
        'cache' => storage_path('framework/cache/llm'),
        'logs' => storage_path('logs/llm'),
    ],
];
