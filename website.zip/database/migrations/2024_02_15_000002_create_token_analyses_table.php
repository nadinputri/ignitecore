<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('token_analyses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('meme_token_id')->constrained('meme_tokens')->onDelete('cascade');
            $table->decimal('ai_score', 5, 2); // 0-100 score based on AI analysis
            $table->json('sentiment_analysis'); // Store sentiment from various sources
            $table->json('risk_factors'); // Identified risk factors
            $table->json('technical_indicators'); // Technical analysis indicators
            $table->json('social_metrics'); // Social media metrics
            $table->text('ai_recommendation'); // AI's trading recommendation
            $table->timestamp('analyzed_at');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('token_analyses');
    }
};
