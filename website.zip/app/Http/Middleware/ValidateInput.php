<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Services\SecurityService;

class ValidateInput
{
    /**
     * The security service instance.
     *
     * @var \App\Services\SecurityService
     */
    protected $securityService;

    /**
     * Patterns for common malicious inputs
     *
     * @var array
     */
    protected $maliciousPatterns = [
        // XSS Patterns
        '/<script\b[^>]*>(.*?)<\/script>/is',
        '/javascript:/i',
        '/vbscript:/i',
        '/onclick/i',
        '/onload/i',
        '/onunload/i',
        '/onabort/i',
        '/onerror/i',
        '/onblur/i',
        '/onchange/i',
        '/onfocus/i',
        '/onreset/i',
        '/onsubmit/i',
        '/ondblclick/i',
        '/onkeydown/i',
        '/onkeypress/i',
        '/onkeyup/i',
        '/onmousedown/i',
        '/onmousemove/i',
        '/onmouseout/i',
        '/onmouseover/i',
        '/onmouseup/i',
        '/onresize/i',
        '/onselect/i',
        
        // SQL Injection Patterns
        '/\bUNION\b/i',
        '/\bSELECT\b.*\bFROM\b/i',
        '/\bINSERT\b.*\bINTO\b/i',
        '/\bUPDATE\b.*\bSET\b/i',
        '/\bDELETE\b.*\bFROM\b/i',
        '/\bDROP\b.*\bTABLE\b/i',
        '/\bTRUNCATE\b.*\bTABLE\b/i',
        
        // Path Traversal
        '/\.\.\//i',
        '/\.\.\\\/i',
    ];

    /**
     * Fields that should be excluded from validation
     *
     * @var array
     */
    protected $excludedFields = [
        'password',
        'password_confirmation',
        '_token',
        '_method'
    ];

    /**
     * Create a new middleware instance.
     *
     * @param  \App\Services\SecurityService  $securityService
     * @return void
     */
    public function __construct(SecurityService $securityService)
    {
        $this->securityService = $securityService;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        try {
            $input = $request->all();
            $sanitizedInput = $this->sanitizeInput($input);
            
            // Check for malicious patterns
            if ($this->containsMaliciousPatterns($sanitizedInput)) {
                Log::warning('Potentially malicious input detected', [
                    'ip' => $request->ip(),
                    'path' => $request->path(),
                    'input' => $input
                ]);

                return response()->json([
                    'error' => 'Invalid input detected'
                ], 422);
            }

            // Replace the request input with sanitized values
            $request->replace($sanitizedInput);

            return $next($request);
        } catch (\Exception $e) {
            Log::error('Input validation error: ' . $e->getMessage(), [
                'ip' => $request->ip(),
                'path' => $request->path()
            ]);

            return response()->json([
                'error' => 'An error occurred while processing your request'
            ], 500);
        }
    }

    /**
     * Sanitize input recursively
     *
     * @param  mixed  $input
     * @return mixed
     */
    protected function sanitizeInput($input)
    {
        if (is_array($input)) {
            return array_map([$this, 'sanitizeInput'], $input);
        }

        if (is_string($input)) {
            // Skip sanitization for excluded fields
            $backtrace = debug_backtrace(DEBUG_BACKTRACE_PROVIDE_OBJECT, 2);
            $caller = $backtrace[1] ?? null;
            if ($caller && isset($caller['args'][0]) && in_array($caller['args'][0], $this->excludedFields)) {
                return $input;
            }

            // Basic sanitization
            $sanitized = strip_tags($input);
            $sanitized = htmlspecialchars($sanitized, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            
            // Remove null bytes and other control characters
            $sanitized = preg_replace('/[\x00-\x1F\x7F]/u', '', $sanitized);
            
            // Normalize line endings
            $sanitized = str_replace(["\r\n", "\r"], "\n", $sanitized);
            
            // Remove multiple spaces
            $sanitized = preg_replace('/\s+/', ' ', $sanitized);
            
            // Trim whitespace
            $sanitized = trim($sanitized);

            return $sanitized;
        }

        return $input;
    }

    /**
     * Check if input contains malicious patterns
     *
     * @param  mixed  $input
     * @return bool
     */
    protected function containsMaliciousPatterns($input)
    {
        if (is_array($input)) {
            foreach ($input as $value) {
                if ($this->containsMaliciousPatterns($value)) {
                    return true;
                }
            }
            return false;
        }

        if (is_string($input)) {
            foreach ($this->maliciousPatterns as $pattern) {
                if (preg_match($pattern, $input)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Add custom malicious patterns
     *
     * @param  array  $patterns
     * @return void
     */
    public function addMaliciousPatterns(array $patterns)
    {
        $this->maliciousPatterns = array_merge($this->maliciousPatterns, $patterns);
    }

    /**
     * Add fields to exclude from validation
     *
     * @param  array  $fields
     * @return void
     */
    public function addExcludedFields(array $fields)
    {
        $this->excludedFields = array_merge($this->excludedFields, $fields);
    }
}
