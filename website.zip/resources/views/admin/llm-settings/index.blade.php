@extends('layouts.admin')

@section('title', 'LLM Settings')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <!-- Model Status Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="card-title">Model Status</h3>
                    <div class="card-tools">
                        <a href="{{ route('admin.llm-settings.logs') }}" class="btn btn-sm btn-info">
                            <i class="fas fa-history"></i> View Logs
                        </a>
                        <a href="{{ route('admin.llm-settings.test') }}" class="btn btn-sm btn-primary">
                            <i class="fas fa-vial"></i> Test Model
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="info-box">
                                <span class="info-box-icon bg-info">
                                    <i class="fas fa-brain"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Current Model</span>
                                    <span class="info-box-number">
                                        {{ $settings->model_name }} ({{ $settings->model_size }})
                                        <small class="text-muted">{{ $settings->model_variant }}</small>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="info-box">
                                <span class="info-box-icon {{ $settings->is_enabled ? 'bg-success' : 'bg-danger' }}">
                                    <i class="fas fa-power-off"></i>
                                </span>
                                <div class="info-box-content">
                                    <span class="info-box-text">Status</span>
                                    <span class="info-box-number">
                                        {!! $settings->health_status_badge !!}
                                        <small class="text-muted">Last check: {{ $settings->last_health_check?->diffForHumans() ?? 'Never' }}</small>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    @if($metrics)
                    <div class="row mt-4">
                        <div class="col-md-3">
                            <div class="small-box bg-info">
                                <div class="inner">
                                    <h3>{{ $metrics['cpu']['percent'] }}%</h3>
                                    <p>CPU Usage</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-microchip"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h3>{{ $metrics['memory']['percent'] }}%</h3>
                                    <p>Memory Usage</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-memory"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="small-box bg-warning">
                                <div class="inner">
                                    <h3>{{ $metrics['disk']['percent'] }}%</h3>
                                    <p>Disk Usage</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-hdd"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="small-box bg-danger">
                                <div class="inner">
                                    <h3>{{ isset($metrics['gpu']) ? count($metrics['gpu']) : '0' }}</h3>
                                    <p>GPU{{ isset($metrics['gpu']) && count($metrics['gpu']) !== 1 ? 's' : '' }} Available</p>
                                </div>
                                <div class="icon">
                                    <i class="fas fa-server"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    @if(isset($metrics['gpu']))
                    <div class="row mt-4">
                        <div class="col-12">
                            <h5>GPU Details</h5>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Device</th>
                                            <th>Name</th>
                                            <th>Memory Usage</th>
                                            <th>Utilization</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($metrics['gpu'] as $gpu)
                                        <tr>
                                            <td>GPU {{ $gpu['id'] }}</td>
                                            <td>{{ $gpu['name'] }}</td>
                                            <td>
                                                {{ format_bytes($gpu['memory_used']) }} / {{ format_bytes($gpu['memory_total']) }}
                                                ({{ round(($gpu['memory_used'] / $gpu['memory_total']) * 100, 1) }}%)
                                            </td>
                                            <td>
                                                @if($gpu['utilization'])
                                                    {{ $gpu['utilization'] }}%
                                                @else
                                                    N/A
                                                @endif
                                            </td>
                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    @endif
                    @endif
                </div>
            </div>

            <!-- Model Settings Form -->
            <form action="{{ route('admin.llm-settings.update') }}" method="POST" class="card">
                @csrf
                @method('PUT')
                
                <div class="card-header">
                    <h3 class="card-title">Model Settings</h3>
                </div>
                
                <div class="card-body">
                    <div class="row">
                        <!-- Model Selection -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="model_name">Model</label>
                                <select name="model_name" id="model_name" class="form-control @error('model_name') is-invalid @enderror">
                                    <option value="llama2" {{ $settings->model_name === 'llama2' ? 'selected' : '' }}>Llama 2</option>
                                    <option value="mistral" {{ $settings->model_name === 'mistral' ? 'selected' : '' }}>Mistral</option>
                                </select>
                                @error('model_name')
                                    <span class="invalid-feedback">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="model_size">Size</label>
                                <select name="model_size" id="model_size" class="form-control @error('model_size') is-invalid @enderror">
                                    <option value="7B" {{ $settings->model_size === '7B' ? 'selected' : '' }}>7B Parameters</option>
                                    <option value="13B" {{ $settings->model_size === '13B' ? 'selected' : '' }}>13B Parameters</option>
                                    <option value="70B" {{ $settings->model_size === '70B' ? 'selected' : '' }}>70B Parameters</option>
                                </select>
                                @error('model_size')
                                    <span class="invalid-feedback">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="model_variant">Variant</label>
                                <select name="model_variant" id="model_variant" class="form-control @error('model_variant') is-invalid @enderror">
                                    <option value="chat" {{ $settings->model_variant === 'chat' ? 'selected' : '' }}>Chat</option>
                                    <option value="instruct" {{ $settings->model_variant === 'instruct' ? 'selected' : '' }}>Instruct</option>
                                    <option value="base" {{ $settings->model_variant === 'base' ? 'selected' : '' }}>Base</option>
                                </select>
                                @error('model_variant')
                                    <span class="invalid-feedback">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="row mt-4">
                        <!-- Performance Settings -->
                        <div class="col-md-6">
                            <h5>Performance Settings</h5>
                            
                            <div class="form-group">
                                <label for="batch_size">Batch Size</label>
                                <input type="number" name="batch_size" id="batch_size" class="form-control @error('batch_size') is-invalid @enderror"
                                    value="{{ $settings->batch_size }}" min="1" max="128">
                                @error('batch_size')
                                    <span class="invalid-feedback">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label for="threads">CPU Threads</label>
                                <input type="number" name="threads" id="threads" class="form-control @error('threads') is-invalid @enderror"
                                    value="{{ $settings->threads }}" min="1" max="32">
                                @error('threads')
                                    <span class="invalid-feedback">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label for="gpu_layers">GPU Layers</label>
                                <input type="number" name="gpu_layers" id="gpu_layers" class="form-control @error('gpu_layers') is-invalid @enderror"
                                    value="{{ $settings->gpu_layers }}" min="-1">
                                <small class="form-text text-muted">Use -1 for all layers</small>
                                @error('gpu_layers')
                                    <span class="invalid-feedback">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label for="context_window">Context Window</label>
                                <input type="number" name="context_window" id="context_window" class="form-control @error('context_window') is-invalid @enderror"
                                    value="{{ $settings->context_window }}" min="512" max="8192" step="512">
                                @error('context_window')
                                    <span class="invalid-feedback">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Generation Settings -->
                        <div class="col-md-6">
                            <h5>Generation Settings</h5>
                            
                            <div class="form-group">
                                <label for="max_tokens">Max Tokens</label>
                                <input type="number" name="max_tokens" id="max_tokens" class="form-control @error('max_tokens') is-invalid @enderror"
                                    value="{{ $settings->max_tokens }}" min="1" max="4096">
                                @error('max_tokens')
                                    <span class="invalid-feedback">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label for="temperature">Temperature</label>
                                <input type="number" name="temperature" id="temperature" class="form-control @error('temperature') is-invalid @enderror"
                                    value="{{ $settings->temperature }}" min="0" max="2" step="0.1">
                                @error('temperature')
                                    <span class="invalid-feedback">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label for="quantization">Quantization</label>
                                <select name="quantization" id="quantization" class="form-control @error('quantization') is-invalid @enderror">
                                    <option value="4-bit" {{ $settings->quantization === '4-bit' ? 'selected' : '' }}>4-bit</option>
                                    <option value="8-bit" {{ $settings->quantization === '8-bit' ? 'selected' : '' }}>8-bit</option>
                                    <option value="none" {{ $settings->quantization === 'none' ? 'selected' : '' }}>None</option>
                                </select>
                                @error('quantization')
                                    <span class="invalid-feedback">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="row mt-4">
                        <!-- Safety Settings -->
                        <div class="col-md-6">
                            <h5>Safety Settings</h5>
                            
                            <div class="form-group">
                                <label for="max_requests_per_minute">Rate Limit (requests/minute)</label>
                                <input type="number" name="max_requests_per_minute" id="max_requests_per_minute" 
                                    class="form-control @error('max_requests_per_minute') is-invalid @enderror"
                                    value="{{ $settings->max_requests_per_minute }}" min="1">
                                @error('max_requests_per_minute')
                                    <span class="invalid-feedback">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="form-group">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="content_filtering" name="content_filtering"
                                        {{ $settings->content_filtering ? 'checked' : '' }}>
                                    <label class="custom-control-label" for="content_filtering">Enable Content Filtering</label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="blocked_words">Blocked Words</label>
                                <textarea name="blocked_words" id="blocked_words" rows="3" 
                                    class="form-control @error('blocked_words') is-invalid @enderror"
                                    placeholder="Enter words separated by commas">{{ implode(', ', $settings->blocked_words ?? []) }}</textarea>
                                @error('blocked_words')
                                    <span class="invalid-feedback">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <!-- Monitoring Settings -->
                        <div class="col-md-6">
                            <h5>Monitoring Settings</h5>
                            
                            <div class="form-group">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="monitoring_enabled" name="monitoring_enabled"
                                        {{ $settings->monitoring_enabled ? 'checked' : '' }}>
                                    <label class="custom-control-label" for="monitoring_enabled">Enable System Monitoring</label>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="log_requests" name="log_requests"
                                        {{ $settings->log_requests ? 'checked' : '' }}>
                                    <label class="custom-control-label" for="log_requests">Log Requests</label>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="log_responses" name="log_responses"
                                        {{ $settings->log_responses ? 'checked' : '' }}>
                                    <label class="custom-control-label" for="log_responses">Log Responses</label>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="custom-control custom-switch">
                                    <input type="checkbox" class="custom-control-input" id="log_errors" name="log_errors"
                                        {{ $settings->log_errors ? 'checked' : '' }}>
                                    <label class="custom-control-label" for="log_errors">Log Errors</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-footer">
                    <button type="submit" class="btn btn-primary">Save Settings</button>
                    <a href="{{ route('admin.llm-settings.index') }}" class="btn btn-secondary">Cancel</a>
                </div>
            </form>

            <!-- Model Download -->
            <div class="card mt-4">
                <div class="card-header">
                    <h3 class="card-title">Model Management</h3>
                </div>
                <div class="card-body">
                    <form id="download-form" action="{{ route('admin.llm-settings.download') }}" method="POST" class="mb-4">
                        @csrf
                        <div class="row">
                            <div class="col-md-3">
                                <select name="model_name" class="form-control">
                                    <option value="llama2">Llama 2</option>
                                    <option value="mistral">Mistral</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select name="model_size" class="form-control">
                                    <option value="7B">7B Parameters</option>
                                    <option value="13B">13B Parameters</option>
                                    <option value="70B">70B Parameters</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select name="model_variant" class="form-control">
                                    <option value="chat">Chat</option>
                                    <option value="instruct">Instruct</option>
                                    <option value="base">Base</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <button type="submit" class="btn btn-primary">Download Model</button>
                            </div>
                        </div>
                    </form>

                    <div id="download-status" class="alert alert-info d-none"></div>
                    <button id="cancel-download" class="btn btn-danger d-none">Cancel Download</button>

                    @if($models)
                    <div class="table-responsive mt-4">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Model</th>
                                    <th>Size</th>
                                    <th>Variant</th>
                                    <th>Last Modified</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($models as $name => $info)
                                <tr>
                                    <td>{{ $info['name'] }}</td>
                                    <td>{{ $info['size'] }}</td>
                                    <td>{{ $info['variant'] }}</td>
                                    <td>{{ $info['last_modified'] ? \Carbon\Carbon::parse($info['last_modified'])->diffForHumans() : 'N/A' }}</td>
                                    <td>
                                        <button class="btn btn-sm btn-danger">Delete</button>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<link rel="stylesheet" href="{{ asset('css/admin/llm-settings.css') }}">
@endpush

@push('scripts')
<script src="{{ asset('js/admin/llm-settings.js') }}"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-refresh metrics every 30 seconds
    setInterval(function() {
        window.location.reload();
    }, 30000);
});
</script>
@endpush
