@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>{{ $bot->name }}</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="{{ route('user.telegram-bots.edit', $bot) }}" class="btn btn-primary">
                <i class="fas fa-edit"></i> Edit Bot
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Bot Status</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span>Status:</span>
                        <span class="badge {{ $bot->status === 'active' ? 'bg-success' : 'bg-danger' }}">
                            {{ ucfirst($bot->status) }}
                        </span>
                    </div>

                    <form action="{{ route('user.telegram-bots.toggle-status', $bot) }}" method="POST">
                        @csrf
                        @method('PATCH')
                        <button type="submit" class="btn btn-sm w-100 {{ $bot->status === 'active' ? 'btn-warning' : 'btn-success' }}">
                            <i class="fas fa-power-off"></i> 
                            {{ $bot->status === 'active' ? 'Deactivate' : 'Activate' }}
                        </button>
                    </form>
                </div>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Credit Usage</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <small class="text-muted">Total Credits Used:</small>
                        <div class="h3">{{ number_format($bot->total_credits_used) }}</div>
                    </div>

                    <div class="mb-3">
                        <small class="text-muted">Available Credits:</small>
                        <div class="h4">{{ number_format(auth()->user()->wallet->balance) }}</div>
                    </div>

                    <a href="{{ route('user.wallet.index') }}" class="btn btn-outline-primary btn-sm w-100">
                        <i class="fas fa-wallet"></i> Manage Credits
                    </a>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Memecoin Settings</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <small class="text-muted">Network:</small>
                                <div>{{ ucfirst($bot->settings['network'] ?? 'ethereum') }}</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <small class="text-muted">Trading Status:</small>
                                <div>
                                    @if($bot->settings['trading_enabled'] ?? false)
                                        <span class="text-success">
                                            <i class="fas fa-check-circle"></i> Enabled
                                        </span>
                                    @else
                                        <span class="text-danger">
                                            <i class="fas fa-times-circle"></i> Disabled
                                        </span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <small class="text-muted">Max Slippage:</small>
                                <div>{{ $bot->settings['max_slippage'] ?? 5 }}%</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <small class="text-muted">Gas Limit:</small>
                                <div>{{ number_format($bot->settings['gas_limit'] ?? 300000) }}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Recent Credit Usage</h5>
                    <a href="{{ route('user.telegram-bots.credit-history', $bot) }}" class="btn btn-sm btn-link">
                        View All
                    </a>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Action</th>
                                <th>Credits</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($creditHistory as $credit)
                                <tr>
                                    <td>{{ $credit->created_at->format('M d, Y H:i') }}</td>
                                    <td>{{ $credit->action_type }}</td>
                                    <td>{{ number_format($credit->credits_used) }}</td>
                                    <td>
                                        @if($credit->metadata)
                                            <button type="button" class="btn btn-sm btn-link" 
                                                data-bs-toggle="tooltip" 
                                                data-bs-html="true"
                                                title="{{ json_encode($credit->metadata, JSON_PRETTY_PRINT) }}">
                                                <i class="fas fa-info-circle"></i>
                                            </button>
                                        @endif
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4" class="text-center py-3">
                                        No credit usage history yet
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
</script>
@endpush
