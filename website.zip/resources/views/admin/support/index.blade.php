@extends('layouts.admin')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Support Tickets</h2>
        </div>
        <div class="col-md-4">
            <form action="{{ route('admin.support-tickets.index') }}" method="GET" class="d-flex gap-2">
                <input type="text" 
                       name="search" 
                       class="form-control" 
                       placeholder="Search tickets..."
                       value="{{ request('search') }}">
                <button type="submit" class="btn btn-primary">Search</button>
            </form>
        </div>
    </div>

    <!-- Filters -->
    <div class="row mb-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('admin.support-tickets.index') }}" method="GET" class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select" onchange="this.form.submit()">
                                <option value="">All Statuses</option>
                                <option value="open" {{ request('status') === 'open' ? 'selected' : '' }}>Open</option>
                                <option value="in_progress" {{ request('status') === 'in_progress' ? 'selected' : '' }}>In Progress</option>
                                <option value="resolved" {{ request('status') === 'resolved' ? 'selected' : '' }}>Resolved</option>
                                <option value="closed" {{ request('status') === 'closed' ? 'selected' : '' }}>Closed</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Priority</label>
                            <select name="priority" class="form-select" onchange="this.form.submit()">
                                <option value="">All Priorities</option>
                                <option value="low" {{ request('priority') === 'low' ? 'selected' : '' }}>Low</option>
                                <option value="medium" {{ request('priority') === 'medium' ? 'selected' : '' }}>Medium</option>
                                <option value="high" {{ request('priority') === 'high' ? 'selected' : '' }}>High</option>
                            </select>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    @if($tickets->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Ticket #</th>
                                        <th>User</th>
                                        <th>Subject</th>
                                        <th>Status</th>
                                        <th>Priority</th>
                                        <th>Assigned To</th>
                                        <th>Last Updated</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($tickets as $ticket)
                                    <tr>
                                        <td>{{ $ticket->ticket_number }}</td>
                                        <td>{{ $ticket->user->name }}</td>
                                        <td>
                                            <a href="{{ route('admin.support-tickets.show', $ticket) }}" class="text-decoration-none">
                                                {{ $ticket->subject }}
                                            </a>
                                            @if($ticket->replies_count > 0)
                                                <span class="badge bg-info">{{ $ticket->replies_count }} {{ Str::plural('reply', $ticket->replies_count) }}</span>
                                            @endif
                                        </td>
                                        <td>
                                            <span class="badge bg-{{ 
                                                $ticket->status === 'open' ? 'warning' : 
                                                ($ticket->status === 'in_progress' ? 'info' : 
                                                ($ticket->status === 'resolved' ? 'success' : 'secondary'))
                                            }}">
                                                {{ ucfirst(str_replace('_', ' ', $ticket->status)) }}
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-{{ 
                                                $ticket->priority === 'high' ? 'danger' : 
                                                ($ticket->priority === 'medium' ? 'warning' : 'info')
                                            }}">
                                                {{ ucfirst($ticket->priority) }}
                                            </span>
                                        </td>
                                        <td>
                                            @if($ticket->assignedTo)
                                                {{ $ticket->assignedTo->name }}
                                            @else
                                                <span class="text-muted">Unassigned</span>
                                            @endif
                                        </td>
                                        <td>{{ $ticket->updated_at->diffForHumans() }}</td>
                                        <td>
                                            <div class="btn-group">
                                                <a href="{{ route('admin.support-tickets.show', $ticket) }}" 
                                                   class="btn btn-sm btn-outline-primary">
                                                    View
                                                </a>
                                                <button type="button" 
                                                        class="btn btn-sm btn-outline-primary dropdown-toggle dropdown-toggle-split"
                                                        data-bs-toggle="dropdown">
                                                </button>
                                                <ul class="dropdown-menu">
                                                    <li>
                                                        <button type="button" 
                                                                class="dropdown-item" 
                                                                data-bs-toggle="modal" 
                                                                data-bs-target="#assignTicketModal"
                                                                data-ticket-id="{{ $ticket->id }}">
                                                            Assign
                                                        </button>
                                                    </li>
                                                    <li>
                                                        <button type="button" 
                                                                class="dropdown-item" 
                                                                data-bs-toggle="modal" 
                                                                data-bs-target="#updateStatusModal"
                                                                data-ticket-id="{{ $ticket->id }}">
                                                            Update Status
                                                        </button>
                                                    </li>
                                                </ul>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <div class="d-flex justify-content-center mt-4">
                            {{ $tickets->links() }}
                        </div>
                    @else
                        <div class="text-center py-4">
                            <h4>No Support Tickets Found</h4>
                            <p class="text-muted">No tickets match your search criteria.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Assign Ticket Modal -->
<div class="modal fade" id="assignTicketModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="assignTicketForm" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Assign Ticket</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Assign to Admin</label>
                        <select name="admin_id" class="form-select" required>
                            <option value="">Select Admin</option>
                            @foreach($admins as $admin)
                                <option value="{{ $admin->id }}">{{ $admin->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Assign</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Update Status Modal -->
<div class="modal fade" id="updateStatusModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="updateStatusForm" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Update Ticket Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select" required>
                            <option value="open">Open</option>
                            <option value="in_progress">In Progress</option>
                            <option value="resolved">Resolved</option>
                            <option value="closed">Closed</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const assignModal = document.getElementById('assignTicketModal');
    const statusModal = document.getElementById('updateStatusModal');

    assignModal.addEventListener('show.bs.modal', function(event) {
        const button = event.relatedTarget;
        const ticketId = button.dataset.ticketId;
        const form = this.querySelector('#assignTicketForm');
        form.action = `/admin/support/${ticketId}/assign`;
    });

    statusModal.addEventListener('show.bs.modal', function(event) {
        const button = event.relatedTarget;
        const ticketId = button.dataset.ticketId;
        const form = this.querySelector('#updateStatusForm');
        form.action = `/admin/support/${ticketId}/status`;
    });
});
</script>
@endpush
@endsection
