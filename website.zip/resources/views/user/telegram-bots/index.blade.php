@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>My Telegram Bots</h2>
        </div>
        <div class="col-md-4 text-end">
            @can('create', App\Models\TelegramBot::class)
            <a href="{{ route('user.telegram-bots.create') }}" class="btn btn-primary">
                <i class="fas fa-plus"></i> Create New Bot
            </a>
            @endcan
        </div>
    </div>

    @if($bots->isEmpty())
        <div class="alert alert-info">
            You haven't created any Telegram bots yet. 
            @can('create', App\Models\TelegramBot::class)
                <a href="{{ route('user.telegram-bots.create') }}">Create your first bot</a>
            @endcan
        </div>
    @else
        <div class="row">
            @foreach($bots as $bot)
                <div class="col-md-6 mb-4">
                    <div class="card h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <h5 class="card-title mb-0">{{ $bot->name }}</h5>
                                <span class="badge {{ $bot->status === 'active' ? 'bg-success' : 'bg-danger' }}">
                                    {{ ucfirst($bot->status) }}
                                </span>
                            </div>
                            
                            <div class="mb-3">
                                <small class="text-muted">Credits Used:</small>
                                <div class="h4">{{ number_format($bot->total_credits_used) }}</div>
                            </div>

                            <div class="mb-3">
                                <small class="text-muted">Created:</small>
                                <div>{{ $bot->created_at->format('M d, Y') }}</div>
                            </div>

                            <div class="d-flex gap-2">
                                <a href="{{ route('user.telegram-bots.show', $bot) }}" class="btn btn-sm btn-primary">
                                    <i class="fas fa-eye"></i> View Details
                                </a>
                                
                                <form action="{{ route('user.telegram-bots.toggle-status', $bot) }}" method="POST" class="d-inline">
                                    @csrf
                                    @method('PATCH')
                                    <button type="submit" class="btn btn-sm {{ $bot->status === 'active' ? 'btn-warning' : 'btn-success' }}">
                                        <i class="fas fa-power-off"></i> 
                                        {{ $bot->status === 'active' ? 'Deactivate' : 'Activate' }}
                                    </button>
                                </form>

                                <div class="dropdown">
                                    <button class="btn btn-sm btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                        More
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a class="dropdown-item" href="{{ route('user.telegram-bots.edit', $bot) }}">
                                                <i class="fas fa-edit"></i> Edit
                                            </a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="{{ route('user.telegram-bots.credit-history', $bot) }}">
                                                <i class="fas fa-history"></i> Credit History
                                            </a>
                                        </li>
                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>
                                        <li>
                                            <form action="{{ route('user.telegram-bots.destroy', $bot) }}" method="POST" 
                                                onsubmit="return confirm('Are you sure you want to delete this bot?');">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="dropdown-item text-danger">
                                                    <i class="fas fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <div class="d-flex justify-content-center mt-4">
            {{ $bots->links() }}
        </div>
    @endif
</div>
@endsection

@push('styles')
<style>
    .card {
        transition: transform 0.2s;
    }
    .card:hover {
        transform: translateY(-5px);
    }
</style>
@endpush
