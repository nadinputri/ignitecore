<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Process;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;

class TerminalController extends Controller
{
    /**
     * Custom terminal commands
     */
    protected $customCommands = [
        'analyze' => [
            'description' => 'Analyze system health and performance',
            'handler' => 'handleAnalyze'
        ],
        'backup' => [
            'description' => 'Create quick backup of database or files',
            'handler' => 'handleBackup'
        ],
        'monitor' => [
            'description' => 'Real-time system monitoring',
            'handler' => 'handleMonitor'
        ],
        'report' => [
            'description' => 'Generate system reports',
            'handler' => 'handleReport'
        ],
        'optimize' => [
            'description' => 'Run system optimizations',
            'handler' => 'handleOptimize'
        ],
        'search' => [
            'description' => 'Search through logs and files',
            'handler' => 'handleSearch'
        ],
        'ai' => [
            'description' => 'AI-powered system suggestions',
            'handler' => 'handleAI'
        ],
    ];

    /**
     * Allowed system commands whitelist
     */
    protected $allowedCommands = [
        'ls' => ['ls', 'ls -l', 'ls -la', 'ls -lh'],
        'df' => ['df', 'df -h'],
        'free' => ['free', 'free -h', 'free -m'],
        'top' => ['top -b -n 1'],
        'ps' => ['ps', 'ps aux'],
        'whoami' => ['whoami'],
        'pwd' => ['pwd'],
        'date' => ['date'],
        'uptime' => ['uptime'],
        'php' => ['php -v', 'php artisan --version'],
        'artisan' => [
            'php artisan list',
            'php artisan route:list',
            'php artisan cache:clear',
            'php artisan view:clear',
            'php artisan config:clear',
            'php artisan migrate:status',
        ],
        'git' => ['git status', 'git branch', 'git log --oneline -n 5'],
        'composer' => ['composer show', 'composer diagnose'],
        'tail' => ['tail -n 50 storage/logs/laravel.log'],
    ];

    /**
     * Display the terminal interface.
     */
    public function index()
    {
        $themes = [
            'default' => 'Default Dark',
            'light' => 'Light',
            'matrix' => 'Matrix',
            'retro' => 'Retro',
            'ocean' => 'Ocean',
            'forest' => 'Forest'
        ];

        return view('admin.terminal.index', [
            'allowedCommands' => $this->getAllowedCommands(),
            'customCommands' => $this->customCommands,
            'themes' => $themes,
            'shortcuts' => $this->getShortcuts(),
        ]);
    }

    /**
     * Execute a command and return the result.
     */
    public function execute(Request $request)
    {
        $command = $request->input('command');
        $args = explode(' ', $command);
        $baseCommand = $args[0];

        // Check rate limiting
        if (!$this->checkRateLimit()) {
            return $this->jsonResponse(false, 'Rate limit exceeded. Please wait a minute.');
        }

        // Handle built-in commands
        if (isset($this->customCommands[$baseCommand])) {
            $handler = $this->customCommands[$baseCommand]['handler'];
            return $this->{$handler}($args);
        }

        // Handle system commands
        if (!$this->isCommandAllowed($command)) {
            return $this->jsonResponse(false, 'Command not allowed. Type "help" to see available commands.');
        }

        try {
            // Log command execution
            $this->logCommand($command);

            // Execute command
            $result = Process::timeout(30)->run($command);
            
            return $this->jsonResponse(true, $result->output() ?: $result->errorOutput());

        } catch (\Exception $e) {
            Log::error('Terminal command failed', [
                'command' => $command,
                'error' => $e->getMessage(),
            ]);

            return $this->jsonResponse(false, 'Error: ' . $e->getMessage());
        }
    }

    /**
     * Handle system analysis command.
     */
    protected function handleAnalyze(array $args)
    {
        $output = "System Analysis Report\n\n";

        // Database health
        $dbSize = DB::select('SELECT pg_size_pretty(pg_database_size(current_database()))')[0]->pg_size_pretty ?? 'N/A';
        $tableCount = count(DB::select("SELECT tablename FROM pg_tables WHERE schemaname = 'public'"));
        
        $output .= "Database Status:\n";
        $output .= "- Size: {$dbSize}\n";
        $output .= "- Tables: {$tableCount}\n";

        // Cache status
        $cacheSize = Cache::tags(['system'])->get('size', 0);
        $output .= "\nCache Status:\n";
        $output .= "- Size: " . number_format($cacheSize / 1024 / 1024, 2) . " MB\n";

        // Storage status
        $diskSpace = disk_free_space('/') / disk_total_space('/') * 100;
        $output .= "\nStorage Status:\n";
        $output .= "- Free Space: " . round($diskSpace, 2) . "%\n";

        // Performance metrics
        $output .= "\nPerformance Metrics:\n";
        $output .= "- Average Response Time: " . Cache::get('avg_response_time', 'N/A') . " ms\n";
        $output .= "- Memory Usage: " . memory_get_usage(true) / 1024 / 1024 . " MB\n";

        return $this->jsonResponse(true, $output);
    }

    /**
     * Handle quick backup command.
     */
    protected function handleBackup(array $args)
    {
        $type = $args[1] ?? 'database';
        $output = '';

        if ($type === 'database') {
            $filename = 'backup-' . date('Y-m-d-His') . '.sql';
            Process::run('pg_dump ' . env('DB_DATABASE') . ' > storage/backups/' . $filename);
            $output = "Database backup created: {$filename}";
        } elseif ($type === 'files') {
            $filename = 'files-' . date('Y-m-d-His') . '.zip';
            Process::run('zip -r storage/backups/' . $filename . ' .');
            $output = "Files backup created: {$filename}";
        }

        return $this->jsonResponse(true, $output);
    }

    /**
     * Handle real-time monitoring.
     */
    protected function handleMonitor(array $args)
    {
        $metrics = [
            'cpu' => sys_getloadavg()[0],
            'memory' => memory_get_usage(true),
            'disk' => disk_free_space('/'),
            'connections' => DB::table('information_schema.processlist')->count(),
            'cache_hits' => Cache::get('cache_hits', 0),
            'queue_size' => DB::table('jobs')->count(),
        ];

        return $this->jsonResponse(true, json_encode($metrics, JSON_PRETTY_PRINT));
    }

    /**
     * Handle system report generation.
     */
    protected function handleReport(array $args)
    {
        $type = $args[1] ?? 'system';
        $output = '';

        switch ($type) {
            case 'performance':
                $output = $this->generatePerformanceReport();
                break;
            case 'security':
                $output = $this->generateSecurityReport();
                break;
            case 'errors':
                $output = $this->generateErrorReport();
                break;
            default:
                $output = $this->generateSystemReport();
        }

        return $this->jsonResponse(true, $output);
    }

    /**
     * Handle system optimization.
     */
    protected function handleOptimize(array $args)
    {
        $output = "Running system optimizations...\n\n";

        // Clear various caches
        Process::run('php artisan cache:clear');
        Process::run('php artisan view:clear');
        Process::run('php artisan config:clear');
        Process::run('php artisan route:clear');

        // Optimize Composer
        Process::run('composer dump-autoload --optimize');

        // Optimize database
        DB::unprepared('VACUUM ANALYZE');

        $output .= "✓ Caches cleared\n";
        $output .= "✓ Autoloader optimized\n";
        $output .= "✓ Database optimized\n";

        return $this->jsonResponse(true, $output);
    }

    /**
     * Handle advanced search.
     */
    protected function handleSearch(array $args)
    {
        array_shift($args); // Remove 'search' command
        $term = implode(' ', $args);
        $output = "Searching for '{$term}'...\n\n";

        // Search in logs
        $logResults = Process::run("grep -r '{$term}' storage/logs/")->output();
        if ($logResults) {
            $output .= "Found in logs:\n{$logResults}\n";
        }

        // Search in database
        $dbResults = DB::table('activity_logs')
            ->where('description', 'like', "%{$term}%")
            ->limit(5)
            ->get();

        if ($dbResults->count()) {
            $output .= "\nFound in activity logs:\n";
            foreach ($dbResults as $result) {
                $output .= "- {$result->description}\n";
            }
        }

        return $this->jsonResponse(true, $output);
    }

    /**
     * Handle AI-powered suggestions.
     */
    protected function handleAI(array $args)
    {
        array_shift($args); // Remove 'ai' command
        $query = implode(' ', $args);

        // Analyze system state
        $metrics = [
            'cpu_load' => sys_getloadavg()[0],
            'memory_usage' => memory_get_usage(true) / 1024 / 1024,
            'disk_space' => disk_free_space('/') / disk_total_space('/') * 100,
            'error_count' => DB::table('activity_logs')->where('event', 'error')->count(),
        ];

        $suggestions = [];

        // CPU load suggestions
        if ($metrics['cpu_load'] > 2) {
            $suggestions[] = "High CPU load detected. Consider scaling resources or optimizing heavy processes.";
        }

        // Memory suggestions
        if ($metrics['memory_usage'] > 80) {
            $suggestions[] = "Memory usage is high. Consider clearing caches or optimizing memory-intensive operations.";
        }

        // Disk space suggestions
        if ($metrics['disk_space'] < 20) {
            $suggestions[] = "Low disk space. Consider cleaning old logs and temporary files.";
        }

        // Error rate suggestions
        if ($metrics['error_count'] > 100) {
            $suggestions[] = "High error rate detected. Review logs and implement error handling improvements.";
        }

        $output = "AI Analysis Results:\n\n";
        $output .= "System Metrics:\n";
        $output .= "- CPU Load: {$metrics['cpu_load']}\n";
        $output .= "- Memory Usage: {$metrics['memory_usage']} MB\n";
        $output .= "- Disk Space: {$metrics['disk_space']}%\n";
        $output .= "- Recent Errors: {$metrics['error_count']}\n\n";
        
        $output .= "Suggestions:\n";
        foreach ($suggestions as $suggestion) {
            $output .= "- {$suggestion}\n";
        }

        return $this->jsonResponse(true, $output);
    }

    /**
     * Get keyboard shortcuts.
     */
    protected function getShortcuts(): array
    {
        return [
            'Ctrl + L' => 'Clear screen',
            'Ctrl + C' => 'Cancel current command',
            'Up/Down' => 'Navigate command history',
            'Tab' => 'Command completion',
            'Ctrl + R' => 'Search command history',
            'Ctrl + U' => 'Clear current line',
            'Ctrl + W' => 'Delete last word',
        ];
    }

    /**
     * Format and send JSON response.
     */
    protected function jsonResponse(bool $success, string $output, array $extra = []): array
    {
        return array_merge([
            'success' => $success,
            'output' => $output,
            'prompt' => $this->getPrompt(),
        ], $extra);
    }

    // ... (previous methods remain unchanged)
}
