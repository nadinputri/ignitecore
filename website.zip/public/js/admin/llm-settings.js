document.addEventListener('DOMContentLoaded', function() {
    // Model selection handling
    const modelSelect = document.getElementById('model_name');
    const sizeSelect = document.getElementById('model_size');
    const variantSelect = document.getElementById('model_variant');

    const modelSizes = {
        llama2: ['7B', '13B', '70B'],
        mistral: ['7B']
    };

    const modelVariants = {
        llama2: ['chat', 'instruct', 'base'],
        mistral: ['instruct', 'base']
    };

    function updateModelOptions() {
        const model = modelSelect.value;
        
        // Update sizes
        const sizes = modelSizes[model] || [];
        sizeSelect.innerHTML = sizes.map(size => 
            `<option value="${size}">${size} Parameters</option>`
        ).join('');

        // Update variants
        const variants = modelVariants[model] || [];
        variantSelect.innerHTML = variants.map(variant => 
            `<option value="${variant}">${variant.charAt(0).toUpperCase() + variant.slice(1)}</option>`
        ).join('');
    }

    modelSelect?.addEventListener('change', updateModelOptions);

    // Download status polling
    let downloadStatusInterval;
    const downloadForm = document.getElementById('download-form');
    const downloadStatus = document.getElementById('download-status');
    const cancelDownload = document.getElementById('cancel-download');

    downloadForm?.addEventListener('submit', function(e) {
        e.preventDefault();
        
        fetch(this.action, {
            method: 'POST',
            body: new FormData(this),
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'started') {
                startStatusPolling();
                downloadStatus.textContent = 'Download started...';
                cancelDownload.classList.remove('d-none');
            } else {
                downloadStatus.textContent = 'Failed to start download: ' + data.message;
            }
        })
        .catch(error => {
            downloadStatus.textContent = 'Error: ' + error.message;
        });
    });

    function startStatusPolling() {
        downloadStatusInterval = setInterval(checkDownloadStatus, 2000);
    }

    function checkDownloadStatus() {
        fetch('/admin/llm-settings/download-status')
            .then(response => response.json())
            .then(data => {
                switch(data.status) {
                    case 'running':
                        downloadStatus.textContent = 'Downloading...';
                        break;
                    case 'completed':
                        downloadStatus.textContent = 'Download completed successfully';
                        stopStatusPolling();
                        cancelDownload.classList.add('d-none');
                        break;
                    case 'failed':
                        downloadStatus.textContent = 'Download failed: ' + data.error;
                        stopStatusPolling();
                        cancelDownload.classList.add('d-none');
                        break;
                    default:
                        downloadStatus.textContent = 'Unknown status';
                        stopStatusPolling();
                        cancelDownload.classList.add('d-none');
                }
            })
            .catch(error => {
                downloadStatus.textContent = 'Error checking status: ' + error.message;
                stopStatusPolling();
            });
    }

    function stopStatusPolling() {
        if (downloadStatusInterval) {
            clearInterval(downloadStatusInterval);
            downloadStatusInterval = null;
        }
    }

    cancelDownload?.addEventListener('click', function(e) {
        e.preventDefault();
        
        fetch('/admin/llm-settings/cancel-download', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'cancelled') {
                downloadStatus.textContent = 'Download cancelled';
                stopStatusPolling();
                this.classList.add('d-none');
            } else {
                downloadStatus.textContent = 'Failed to cancel download: ' + data.message;
            }
        })
        .catch(error => {
            downloadStatus.textContent = 'Error cancelling download: ' + error.message;
        });
    });

    // System metrics auto-refresh
    const metricsContainer = document.getElementById('system-metrics');
    let metricsInterval;

    if (metricsContainer) {
        metricsInterval = setInterval(updateMetrics, 5000);
    }

    function updateMetrics() {
        fetch('/admin/llm-settings')
            .then(response => response.text())
            .then(html => {
                const parser = new DOMParser();
                const doc = parser.parseFromString(html, 'text/html');
                const newMetrics = doc.getElementById('system-metrics');
                if (newMetrics) {
                    metricsContainer.innerHTML = newMetrics.innerHTML;
                }
            })
            .catch(error => console.error('Error updating metrics:', error));
    }

    // Cleanup on page unload
    window.addEventListener('beforeunload', function() {
        stopStatusPolling();
        if (metricsInterval) {
            clearInterval(metricsInterval);
        }
    });

    // Test model
    const testForm = document.getElementById('test-form');
    const testResult = document.getElementById('test-result');

    testForm?.addEventListener('submit', function(e) {
        e.preventDefault();
        testResult.textContent = 'Testing...';
        
        fetch(this.action, {
            method: 'GET',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                testResult.innerHTML = `<div class="alert alert-success">Test successful:<br>${data.response}</div>`;
            } else {
                testResult.innerHTML = `<div class="alert alert-danger">Test failed: ${data.error}</div>`;
            }
        })
        .catch(error => {
            testResult.innerHTML = `<div class="alert alert-danger">Error: ${error.message}</div>`;
        });
    });

    // Performance settings tooltips
    const tooltips = {
        'batch_size': 'Number of tokens to process in parallel. Higher values use more memory but can improve speed.',
        'threads': 'Number of CPU threads to use. Set to number of CPU cores for best performance.',
        'gpu_layers': 'Number of layers to offload to GPU. -1 means all layers.',
        'context_window': 'Maximum number of tokens to consider for context. Higher values use more memory.',
        'temperature': 'Controls randomness in generation. Higher values (>1.0) make output more random, lower values make it more focused.',
        'max_tokens': 'Maximum number of tokens to generate in response.'
    };

    Object.entries(tooltips).forEach(([id, text]) => {
        const element = document.getElementById(id);
        if (element) {
            element.setAttribute('title', text);
            new bootstrap.Tooltip(element);
        }
    });
});
