<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();
            $table->text('value')->nullable();
            $table->string('type')->default('string'); // string, boolean, integer, json, etc.
            $table->string('group')->default('general'); // general, mail, payment, etc.
            $table->string('label')->nullable();
            $table->text('description')->nullable();
            $table->boolean('is_public')->default(false); // Whether setting is accessible publicly
            $table->boolean('is_system')->default(false); // System settings cannot be deleted
            $table->json('validation_rules')->nullable(); // JSON encoded validation rules
            $table->integer('sort_order')->default(0);
            $table->timestamps();

            // Add index for faster lookups
            $table->index(['key', 'group']);
        });

        // Insert default settings
        $defaultSettings = [
            [
                'key' => 'site_name',
                'value' => 'IgniteHub',
                'type' => 'string',
                'group' => 'general',
                'label' => 'Site Name',
                'description' => 'The name of your website',
                'is_public' => true,
                'is_system' => true,
                'validation_rules' => json_encode(['required', 'string', 'max:255']),
                'sort_order' => 1,
            ],
            [
                'key' => 'site_description',
                'value' => 'Your Digital Services Marketplace',
                'type' => 'text',
                'group' => 'general',
                'label' => 'Site Description',
                'description' => 'A brief description of your website',
                'is_public' => true,
                'is_system' => true,
                'validation_rules' => json_encode(['required', 'string']),
                'sort_order' => 2,
            ],
            [
                'key' => 'maintenance_mode',
                'value' => '0',
                'type' => 'boolean',
                'group' => 'system',
                'label' => 'Maintenance Mode',
                'description' => 'Put the site into maintenance mode',
                'is_public' => false,
                'is_system' => true,
                'validation_rules' => json_encode(['boolean']),
                'sort_order' => 3,
            ],
            [
                'key' => 'currency',
                'value' => 'USD',
                'type' => 'string',
                'group' => 'payment',
                'label' => 'Currency',
                'description' => 'Default currency for payments',
                'is_public' => true,
                'is_system' => true,
                'validation_rules' => json_encode(['required', 'string', 'size:3']),
                'sort_order' => 4,
            ],
        ];

        DB::table('settings')->insert($defaultSettings);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('settings');
    }
};
