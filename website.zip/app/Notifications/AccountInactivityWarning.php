<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Carbon\Carbon;

class AccountInactivityWarning extends Notification implements ShouldQueue
{
    use Queueable;

    protected $lastActive;
    protected $inactiveDays;

    /**
     * Create a new notification instance.
     */
    public function __construct(Carbon $lastActive, int $inactiveDays)
    {
        $this->lastActive = $lastActive;
        $this->inactiveDays = $inactiveDays;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail', 'database'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject('Account Inactivity Warning')
            ->greeting("Hello {$notifiable->name},")
            ->line("We noticed that you haven't been active on our platform since " . $this->lastActive->format('M d, Y') . ".")
            ->line("After {$this->inactiveDays} days of inactivity, accounts are automatically marked as inactive for security purposes.")
            ->line("To keep your account active, simply log in and perform any action within the next few days.")
            ->action('Log In Now', url('/login'))
            ->line("If you need any assistance, our support team is here to help.");
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            'title' => 'Account Inactivity Warning',
            'message' => "Your account will be marked as inactive after {$this->inactiveDays} days without activity.",
            'type' => 'account_warning',
            'last_active' => $this->lastActive->toDateTimeString(),
            'inactive_days' => $this->inactiveDays,
            'action_text' => 'Log In Now',
            'action_url' => url('/login'),
        ];
    }
}
