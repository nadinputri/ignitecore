<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use App\Services\SecurityService;
use App\Services\FileUploadService;
use App\Console\Commands\SecurityAudit;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // Register SecurityService as a singleton
        $this->app->singleton(SecurityService::class, function ($app) {
            return new SecurityService();
        });

        // Register FileUploadService
        $this->app->bind(FileUploadService::class, function ($app) {
            return new FileUploadService($app->make(SecurityService::class));
        });
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Force HTTPS in production
        if ($this->app->environment('production')) {
            URL::forceScheme('https');
        }

        // Set default string length for database migrations
        Schema::defaultStringLength(191);

        // Add custom password validation rules
        Validator::extend('secure_password', function ($attribute, $value, $parameters, $validator) {
            $minLength = config('security.passwords.min_length', 12);
            
            // Check minimum length
            if (strlen($value) < $minLength) {
                return false;
            }

            // Check for mixed case if required
            if (config('security.passwords.require_mixed_case', true)) {
                if (!preg_match('/[A-Z]/', $value) || !preg_match('/[a-z]/', $value)) {
                    return false;
                }
            }

            // Check for numbers if required
            if (config('security.passwords.require_numbers', true)) {
                if (!preg_match('/[0-9]/', $value)) {
                    return false;
                }
            }

            // Check for special characters if required
            if (config('security.passwords.require_special_chars', true)) {
                if (!preg_match('/[^A-Za-z0-9]/', $value)) {
                    return false;
                }
            }

            // Check against common passwords if required
            if (config('security.passwords.prevent_common_passwords', true)) {
                $commonPasswords = [
                    'password', '123456', '12345678', 'qwerty', 'abc123',
                    'monkey', 'letmein', 'dragon', '111111', 'baseball',
                    'iloveyou', 'trustno1', 'shadow', 'master', '666666',
                    'qwertyuiop', '123321', 'mustang', 'access', 'michael',
                    'superman', '696969', '123qwe', 'jesus', 'password1',
                    'welcome', '1qaz2wsx', 'admin', 'abc123', 'football'
                ];

                if (in_array(strtolower($value), $commonPasswords)) {
                    return false;
                }
            }

            return true;
        });

        // Schedule security tasks
        if ($this->app->runningInConsole()) {
            $schedule = $this->app->make(\Illuminate\Console\Scheduling\Schedule::class);
            
            // Run security audit daily
            $schedule->command('security:audit --notify')
                ->daily()
                ->at('02:00')
                ->appendOutputTo(storage_path('logs/security-audit.log'));

            // Clean old activity logs
            $schedule->command('activity-logs:clean')
                ->daily()
                ->at('03:00');

            // Clean inactive users
            $schedule->command('users:clean-inactive')
                ->daily()
                ->at('04:00');

            // Clean old notifications
            $schedule->command('notifications:clean')
                ->daily()
                ->at('05:00');
        }

        // Register global security headers
        $this->registerSecurityHeaders();
    }

    /**
     * Register global security headers
     */
    protected function registerSecurityHeaders(): void
    {
        $this->app['router']->middleware(function ($request, $next) {
            $response = $next($request);

            if (method_exists($response, 'header')) {
                // Remove potentially dangerous headers
                $response->headers->remove('X-Powered-By');
                $response->headers->remove('Server');

                // Add security headers from config
                if (config('security.headers.strict-transport-security.enabled', true)) {
                    $maxAge = config('security.headers.strict-transport-security.max-age', 31536000);
                    $includeSubDomains = config('security.headers.strict-transport-security.include-subdomains', true);
                    $preload = config('security.headers.strict-transport-security.preload', true);

                    $hstsValue = "max-age={$maxAge}";
                    if ($includeSubDomains) {
                        $hstsValue .= '; includeSubDomains';
                    }
                    if ($preload) {
                        $hstsValue .= '; preload';
                    }

                    $response->headers->set('Strict-Transport-Security', $hstsValue);
                }

                // Add other security headers
                $response->headers->set('X-Content-Type-Options', 'nosniff');
                $response->headers->set('X-XSS-Protection', '1; mode=block');
                $response->headers->set('X-Frame-Options', 'SAMEORIGIN');
                $response->headers->set('Referrer-Policy', 'strict-origin-when-cross-origin');
            }

            return $response;
        });
    }
}
