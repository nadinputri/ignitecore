<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TelegramBotController;
use App\Http\Controllers\Admin\TelegramBotController as AdminTelegramBotController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\UserDashboardController;
use App\Http\Controllers\WalletController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\SupportTicketController;
use App\Http\Controllers\NotificationPreferencesController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Admin\ServiceController as AdminServiceController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\Admin\ActivityLogController;
use App\Http\Controllers\Admin\TerminalController;
use App\Http\Controllers\Admin\LlmSettingController;
use App\Http\Controllers\Auth\TwoFactorController;
use App\Http\Controllers\Auth\PasswordChangeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Public routes
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/services', [ServiceController::class, 'index'])->name('services.index');
Route::get('/services/{service}', [ServiceController::class, 'show'])->name('services.show');
Route::get('/contact', [ContactController::class, 'show'])->name('contact.show');
Route::post('/contact', [ContactController::class, 'submit'])->name('contact.submit');

// Authentication routes
Auth::routes(['verify' => true]);

// Two-Factor Authentication
Route::get('/two-factor/setup', [TwoFactorController::class, 'setup'])->name('two-factor.setup');
Route::post('/two-factor/enable', [TwoFactorController::class, 'enable'])->name('two-factor.enable');
Route::get('/two-factor/challenge', [TwoFactorController::class, 'challenge'])->name('two-factor.challenge');
Route::post('/two-factor/verify', [TwoFactorController::class, 'verify'])->name('two-factor.verify');

// Password change routes
Route::get('/password/change', [PasswordChangeController::class, 'showChangeForm'])->name('password.change');
Route::post('/password/change', [PasswordChangeController::class, 'change'])->name('password.update');

// Telegram Bot Webhook Routes
Route::prefix('telegram')->name('telegram.')->group(function () {
    Route::post('webhook/{token}', [TelegramBotController::class, 'webhook'])->name('webhook');
    Route::post('webhook/{token}/set', [TelegramBotController::class, 'setWebhook'])->name('webhook.set');
    Route::post('webhook/{token}/remove', [TelegramBotController::class, 'removeWebhook'])->name('webhook.remove');
});

// User dashboard routes
Route::middleware(['auth', 'verified', 'password.expires'])->group(function () {
    Route::get('/dashboard', [UserDashboardController::class, 'index'])->name('dashboard');
    Route::get('/orders/{order}', [UserDashboardController::class, 'showOrder'])->name('orders.show');

    // Wallet routes
    Route::get('/wallet', [WalletController::class, 'index'])->name('wallet.index');
    Route::post('/wallet/topup', [WalletController::class, 'topUp'])->name('wallet.topup');
    Route::get('/wallet/transactions', [WalletController::class, 'transactions'])->name('wallet.transactions');
    Route::get('/wallet/transactions/{transaction}', [WalletController::class, 'show'])->name('wallet.transaction.show');

    // Support Ticket routes
    Route::prefix('support')->group(function () {
        Route::get('/', [SupportTicketController::class, 'index'])->name('support-tickets.index');
        Route::get('/create', [SupportTicketController::class, 'create'])->name('support-tickets.create');
        Route::post('/', [SupportTicketController::class, 'store'])->name('support-tickets.store');
        Route::get('/{ticket}', [SupportTicketController::class, 'show'])->name('support-tickets.show');
        Route::post('/{ticket}/reply', [SupportTicketController::class, 'reply'])->name('support-tickets.reply');
        Route::post('/{ticket}/close', [SupportTicketController::class, 'close'])->name('support-tickets.close');
        Route::post('/{ticket}/reopen', [SupportTicketController::class, 'reopen'])->name('support-tickets.reopen');
        Route::get('/attachments/{attachment}/download', [SupportTicketController::class, 'downloadAttachment'])
            ->name('support-tickets.attachments.download');
    });

    // Order routes
    Route::prefix('orders')->group(function () {
        Route::get('/', [OrderController::class, 'index'])->name('orders.index');
        Route::get('/create/{service}', [OrderController::class, 'create'])->name('orders.create');
        Route::post('/create/{service}', [OrderController::class, 'store'])->name('orders.store');
        Route::get('/{order}', [OrderController::class, 'show'])->name('orders.show');
        Route::post('/{order}/counter-offer', [OrderController::class, 'counterOffer'])->name('orders.counter-offer');
        Route::post('/{order}/accept-price', [OrderController::class, 'acceptPrice'])->name('orders.accept-price');
        Route::post('/{order}/cancel', [OrderController::class, 'cancel'])->name('orders.cancel');
    });

    // Telegram Bot Routes
    Route::prefix('telegram-bots')->name('user.telegram-bots.')->group(function () {
        Route::get('/', [TelegramBotController::class, 'index'])->name('index');
        Route::get('/create', [TelegramBotController::class, 'create'])->name('create');
        Route::post('/', [TelegramBotController::class, 'store'])->name('store');
        Route::get('/{bot}', [TelegramBotController::class, 'show'])->name('show');
        Route::get('/{bot}/edit', [TelegramBotController::class, 'edit'])->name('edit');
        Route::put('/{bot}', [TelegramBotController::class, 'update'])->name('update');
        Route::delete('/{bot}', [TelegramBotController::class, 'destroy'])->name('destroy');
        Route::patch('/{bot}/toggle-status', [TelegramBotController::class, 'toggleStatus'])->name('toggle-status');
        Route::get('/{bot}/credits', [TelegramBotController::class, 'creditHistory'])->name('credit-history');
    });

    // Notification routes
    Route::prefix('notifications')->group(function () {
        Route::get('/', [NotificationPreferencesController::class, 'index'])
            ->name('notification-preferences.index');
        Route::get('/preferences', [NotificationPreferencesController::class, 'edit'])
            ->name('notification-preferences.edit');
        Route::post('/preferences', [NotificationPreferencesController::class, 'update'])
            ->name('notification-preferences.update');
        Route::post('/mark-all-read', [NotificationPreferencesController::class, 'markAllAsRead'])
            ->name('notification-preferences.mark-all-read');
        Route::post('/{id}/mark-read', [NotificationPreferencesController::class, 'markAsRead'])
            ->name('notification-preferences.mark-read');
        Route::delete('/{id}', [NotificationPreferencesController::class, 'destroy'])
            ->name('notification-preferences.destroy');
        Route::post('/clear-all', [NotificationPreferencesController::class, 'clearAll'])
            ->name('notification-preferences.clear-all');
        Route::get('/{id}', [NotificationPreferencesController::class, 'show'])
            ->name('notification-preferences.show');
    });
});

// Admin routes
Route::prefix('admin')->middleware(['admin', 'secure.session', 'api.security'])->name('admin.')->group(function () {
    // Dashboard
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/system-info', [DashboardController::class, 'systemInfo'])->name('system-info');

    // Services management
    Route::resource('services', AdminServiceController::class);
    Route::post('/services/{service}/toggle-active', [AdminServiceController::class, 'toggleActive'])
        ->name('services.toggle-active');

    // Orders management
    Route::resource('orders', AdminOrderController::class);
    Route::post('/orders/{order}/update-status', [AdminOrderController::class, 'updateStatus'])
        ->name('orders.update-status');

    // Settings
    Route::get('/settings', [SettingController::class, 'index'])->name('settings.index');
    Route::post('/settings', [SettingController::class, 'update'])->name('settings.update');
    Route::post('/settings/clear-cache', [SettingController::class, 'clearCache'])
        ->name('settings.clear-cache');

    // Activity Logs
    Route::get('/activity-logs', [ActivityLogController::class, 'index'])->name('activity-logs.index');
    Route::get('/activity-logs/{log}', [ActivityLogController::class, 'show'])->name('activity-logs.show');
    Route::post('/activity-logs/clear', [ActivityLogController::class, 'clear'])->name('activity-logs.clear');
    Route::get('/activity-logs/export', [ActivityLogController::class, 'export'])->name('activity-logs.export');

    // Telegram Bot Management
    Route::prefix('telegram-bots')->name('telegram-bots.')->group(function () {
        Route::get('/', [AdminTelegramBotController::class, 'index'])->name('index');
        Route::get('/settings', [AdminTelegramBotController::class, 'settings'])->name('settings');
        Route::put('/settings', [AdminTelegramBotController::class, 'updateSettings'])->name('update-settings');
        Route::post('/settings/reset', [AdminTelegramBotController::class, 'resetSettings'])->name('reset-settings');
        Route::post('/disable-all', [AdminTelegramBotController::class, 'disableAll'])->name('disable-all');
        Route::get('/{bot}', [AdminTelegramBotController::class, 'show'])->name('show');
        Route::get('/{bot}/edit', [AdminTelegramBotController::class, 'edit'])->name('edit');
        Route::put('/{bot}', [AdminTelegramBotController::class, 'update'])->name('update');
        Route::delete('/{bot}', [AdminTelegramBotController::class, 'destroy'])->name('destroy');
        Route::get('/{bot}/credits', [AdminTelegramBotController::class, 'creditHistory'])->name('credit-history');
    });

    // Terminal
    Route::get('/terminal', [TerminalController::class, 'index'])->name('terminal.index');
    Route::post('/terminal/execute', [TerminalController::class, 'execute'])->name('terminal.execute');

    // LLM Settings
    Route::prefix('llm-settings')->name('llm-settings.')->group(function () {
        Route::get('/', [LlmSettingController::class, 'index'])->name('index');
        Route::put('/', [LlmSettingController::class, 'update'])->name('update');
        Route::post('/download', [LlmSettingController::class, 'download'])->name('download');
        Route::get('/download-status', [LlmSettingController::class, 'downloadStatus'])->name('download-status');
        Route::post('/cancel-download', [LlmSettingController::class, 'cancelDownload'])->name('cancel-download');
        Route::get('/test', [LlmSettingController::class, 'test'])->name('test');
        Route::get('/logs', [LlmSettingController::class, 'logs'])->name('logs');
        Route::post('/clear-logs', [LlmSettingController::class, 'clearLogs'])->name('clear-logs');
    });
});

// Payment routes
Route::middleware(['auth', 'verified'])->group(function () {
    Route::post('/payments/process', [PaymentController::class, 'process'])->name('payments.process');
    Route::get('/payments/callback', [PaymentController::class, 'callback'])->name('payments.callback');
    Route::get('/payments/success', [PaymentController::class, 'success'])->name('payments.success');
    Route::get('/payments/cancel', [PaymentController::class, 'cancel'])->name('payments.cancel');
});

// Fallback route for handling 404s
Route::fallback(function () {
    return response()->view('errors.404', [], 404);
});
