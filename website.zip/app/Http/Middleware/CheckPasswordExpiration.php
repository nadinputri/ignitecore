<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class CheckPasswordExpiration
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $user = Auth::user();
        
        if (!$user) {
            return $next($request);
        }
        
        // Skip password check for password reset routes
        if ($this->isPasswordResetRoute($request)) {
            return $next($request);
        }
        
        // Check if user is forced to change password
        if ($user->force_password_change) {
            return redirect()->route('password.change')
                ->with('warning', 'You must change your password before continuing.');
        }
        
        // Check if password has expired
        $maxPasswordAge = config('security.passwords.max_age_days', 90);
        
        if ($maxPasswordAge > 0 && $user->password_changed_at) {
            $expiresAt = Carbon::parse($user->password_changed_at)->addDays($maxPasswordAge);
            
            if (Carbon::now()->gt($expiresAt)) {
                // Password has expired
                $user->force_password_change = true;
                $user->save();
                
                return redirect()->route('password.change')
                    ->with('warning', 'Your password has expired. Please change it to continue.');
            }
            
            // Password will expire soon (within 7 days)
            if (Carbon::now()->addDays(7)->gt($expiresAt)) {
                // Add a flash message about password expiration
                $daysLeft = Carbon::now()->diffInDays($expiresAt);
                session()->flash('password_expiring', 
                    "Your password will expire in {$daysLeft} " . 
                    ($daysLeft == 1 ? 'day' : 'days') . 
                    ". Please change it soon."
                );
            }
        }
        
        return $next($request);
    }
    
    /**
     * Determine if the request is for a password reset route.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return bool
     */
    protected function isPasswordResetRoute(Request $request)
    {
        $passwordRoutes = [
            'password.request',
            'password.email',
            'password.reset',
            'password.update',
            'password.change',
            'password.confirm',
        ];
        
        foreach ($passwordRoutes as $route) {
            if ($request->routeIs($route)) {
                return true;
            }
        }
        
        return false;
    }
}
