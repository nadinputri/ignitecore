<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class ActivityLogSettingsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $settings = [
            [
                'key' => 'activity_log_retention_days',
                'value' => '90',
                'type' => 'integer',
                'group' => 'system',
                'label' => 'Activity Log Retention Period',
                'description' => 'Number of days to keep activity logs before automatic cleanup',
                'is_public' => false,
                'is_system' => true,
                'validation_rules' => json_encode(['required', 'integer', 'min:1', 'max:365']),
                'sort_order' => 10,
            ],
            [
                'key' => 'max_activity_logs',
                'value' => '1000000',
                'type' => 'integer',
                'group' => 'system',
                'label' => 'Maximum Activity Logs',
                'description' => 'Maximum number of activity logs to keep before triggering cleanup',
                'is_public' => false,
                'is_system' => true,
                'validation_rules' => json_encode(['required', 'integer', 'min:1000', 'max:10000000']),
                'sort_order' => 11,
            ],
            [
                'key' => 'activity_log_enabled',
                'value' => '1',
                'type' => 'boolean',
                'group' => 'system',
                'label' => 'Enable Activity Logging',
                'description' => 'Enable or disable activity logging system-wide',
                'is_public' => false,
                'is_system' => true,
                'validation_rules' => json_encode(['boolean']),
                'sort_order' => 12,
            ],
            [
                'key' => 'activity_log_backup_enabled',
                'value' => '1',
                'type' => 'boolean',
                'group' => 'system',
                'label' => 'Enable Activity Log Backup',
                'description' => 'Enable or disable automatic backup before cleanup',
                'is_public' => false,
                'is_system' => true,
                'validation_rules' => json_encode(['boolean']),
                'sort_order' => 13,
            ],
            [
                'key' => 'activity_log_notify_admin',
                'value' => '1',
                'type' => 'boolean',
                'group' => 'system',
                'label' => 'Notify Admin on Critical Activities',
                'description' => 'Send notifications to admin for critical activity logs',
                'is_public' => false,
                'is_system' => true,
                'validation_rules' => json_encode(['boolean']),
                'sort_order' => 14,
            ],
        ];

        foreach ($settings as $setting) {
            Setting::firstOrCreate(['key' => $setting['key']], $setting);
        }
    }
}
