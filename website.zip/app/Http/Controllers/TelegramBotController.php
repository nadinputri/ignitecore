<?php

namespace App\Http\Controllers;

use App\Models\TelegramBot;
use App\Models\TelegramBotCredit;
use App\Services\LlmService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Telegram\Bot\Api;
use Telegram\Bot\Objects\Update;

class TelegramBotController extends Controller
{
    protected $llmService;

    public function __construct(LlmService $llmService)
    {
        $this->llmService = $llmService;
    }

    public function webhook(Request $request, $token)
    {
        try {
            $bot = TelegramBot::where('token', $token)->firstOrFail();
            
            if (!$bot->is_active) {
                return response()->json(['message' => 'Bot is inactive'], 404);
            }

            $telegram = new Api($token);
            $update = $telegram->getWebhookUpdate();
            
            // Process the update
            $this->processUpdate($bot, $telegram, $update);

            return response()->json(['message' => 'OK']);

        } catch (\Exception $e) {
            Log::error('Telegram webhook error: ' . $e->getMessage());
            return response()->json(['error' => 'Internal error'], 500);
        }
    }

    protected function processUpdate(TelegramBot $bot, Api $telegram, Update $update)
    {
        // Only process text messages
        if (!$update->getMessage() || !$update->getMessage()->has('text')) {
            return;
        }

        $message = $update->getMessage();
        $chatId = $message->getChat()->getId();
        $text = $message->getText();

        // Check credits
        if (!$this->checkCredits($bot)) {
            $telegram->sendMessage([
                'chat_id' => $chatId,
                'text' => '❌ Bot has run out of credits. Please contact the administrator.'
            ]);
            return;
        }

        try {
            // Send typing action
            $telegram->sendChatAction([
                'chat_id' => $chatId,
                'action' => 'typing'
            ]);

            // Generate response using local LLM
            $response = $this->llmService->generateResponse($text, [
                'max_tokens' => $bot->settings['max_tokens'] ?? 2048,
                'temperature' => $bot->settings['temperature'] ?? 0.7,
                'stream' => true
            ], function($token) use ($telegram, $chatId, &$message) {
                // Accumulate tokens and update message periodically
                static $buffer = '';
                static $lastUpdate = 0;
                
                $buffer .= $token;
                $now = time();

                // Update message every 2 seconds or when buffer reaches 100 chars
                if ($now - $lastUpdate >= 2 || strlen($buffer) >= 100) {
                    if ($message) {
                        $message = $telegram->editMessageText([
                            'chat_id' => $chatId,
                            'message_id' => $message->getMessageId(),
                            'text' => $buffer,
                            'parse_mode' => 'Markdown'
                        ]);
                    } else {
                        $message = $telegram->sendMessage([
                            'chat_id' => $chatId,
                            'text' => $buffer,
                            'parse_mode' => 'Markdown'
                        ]);
                    }
                    $lastUpdate = $now;
                }
            });

            // Send final message if needed
            if (!empty($buffer)) {
                if ($message) {
                    $telegram->editMessageText([
                        'chat_id' => $chatId,
                        'message_id' => $message->getMessageId(),
                        'text' => $response,
                        'parse_mode' => 'Markdown'
                    ]);
                } else {
                    $telegram->sendMessage([
                        'chat_id' => $chatId,
                        'text' => $response,
                        'parse_mode' => 'Markdown'
                    ]);
                }
            }

            // Log credit usage
            $this->logCreditUsage($bot, $text, $response);

        } catch (\Exception $e) {
            Log::error('LLM generation error: ' . $e->getMessage());
            
            $telegram->sendMessage([
                'chat_id' => $chatId,
                'text' => '❌ Sorry, I encountered an error while processing your request.'
            ]);
        }
    }

    protected function checkCredits(TelegramBot $bot)
    {
        $credits = TelegramBotCredit::where('bot_id', $bot->id)
            ->where('expires_at', '>', now())
            ->sum('remaining_credits');

        return $credits > 0;
    }

    protected function logCreditUsage(TelegramBot $bot, $prompt, $response)
    {
        // Find active credit package
        $credit = TelegramBotCredit::where('bot_id', $bot->id)
            ->where('expires_at', '>', now())
            ->where('remaining_credits', '>', 0)
            ->orderBy('expires_at')
            ->first();

        if ($credit) {
            // Calculate token usage
            $promptTokens = str_word_count($prompt);
            $responseTokens = str_word_count($response);
            $totalTokens = $promptTokens + $responseTokens;

            // Convert tokens to credits (1 credit = 1000 tokens)
            $creditsUsed = ceil($totalTokens / 1000);

            // Update remaining credits
            $credit->remaining_credits = max(0, $credit->remaining_credits - $creditsUsed);
            $credit->save();

            // Log usage
            activity()
                ->performedOn($bot)
                ->withProperties([
                    'prompt_tokens' => $promptTokens,
                    'response_tokens' => $responseTokens,
                    'credits_used' => $creditsUsed,
                    'remaining_credits' => $credit->remaining_credits
                ])
                ->log('credit_usage');
        }
    }

    public function setWebhook(Request $request, $token)
    {
        try {
            $bot = TelegramBot::where('token', $token)->firstOrFail();
            
            $telegram = new Api($token);
            
            $url = route('telegram.webhook', ['token' => $token]);
            $result = $telegram->setWebhook(['url' => $url]);

            if ($result) {
                return response()->json(['message' => 'Webhook set successfully']);
            }

            return response()->json(['error' => 'Failed to set webhook'], 500);

        } catch (\Exception $e) {
            Log::error('Set webhook error: ' . $e->getMessage());
            return response()->json(['error' => 'Internal error'], 500);
        }
    }

    public function removeWebhook(Request $request, $token)
    {
        try {
            $bot = TelegramBot::where('token', $token)->firstOrFail();
            
            $telegram = new Api($token);
            $result = $telegram->removeWebhook();

            if ($result) {
                return response()->json(['message' => 'Webhook removed successfully']);
            }

            return response()->json(['error' => 'Failed to remove webhook'], 500);

        } catch (\Exception $e) {
            Log::error('Remove webhook error: ' . $e->getMessage());
            return response()->json(['error' => 'Internal error'], 500);
        }
    }
}
