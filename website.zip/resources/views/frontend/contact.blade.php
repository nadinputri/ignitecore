@extends('layouts.app')

@section('styles')
<style>
.contact-header {
    padding: 6rem 0;
    position: relative;
    overflow: hidden;
    background: linear-gradient(45deg, var(--background-dark), var(--background-light));
}

.contact-grid {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: 
        linear-gradient(90deg, var(--grid-color) 1px, transparent 1px),
        linear-gradient(var(--grid-color) 1px, transparent 1px);
    background-size: 30px 30px;
    transform: perspective(500px) rotateX(60deg);
    animation: grid-move 20s linear infinite;
}

.contact-form-container {
    position: relative;
    z-index: 1;
    margin-top: -100px;
}

.contact-card {
    background: linear-gradient(45deg, var(--background-dark), var(--background-light));
    border: 2px solid var(--primary-color);
    padding: 2rem;
    position: relative;
    overflow: hidden;
}

.contact-card::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: linear-gradient(
        45deg,
        transparent,
        rgba(0, 255, 0, 0.1),
        transparent
    );
    transform: rotate(45deg);
    animation: shine 3s infinite;
}

@keyframes shine {
    0% { transform: translateX(-100%) rotate(45deg); }
    100% { transform: translateX(100%) rotate(45deg); }
}

.form-group {
    margin-bottom: 1.5rem;
    position: relative;
}

.form-label {
    font-family: 'Press Start 2P', cursive;
    font-size: 0.8rem;
    margin-bottom: 0.5rem;
    color: var(--primary-color);
}

.form-control {
    background: transparent;
    border: 2px solid var(--primary-color);
    color: var(--text-color);
    padding: 1rem;
    font-family: 'VT323', monospace;
    font-size: 1.2rem;
    transition: all 0.3s ease;
}

.form-control:focus {
    outline: none;
    border-color: var(--accent-color);
    box-shadow: 0 0 15px var(--accent-color);
}

.form-control::placeholder {
    color: rgba(255, 255, 255, 0.5);
}

textarea.form-control {
    min-height: 150px;
    resize: vertical;
}

.contact-info {
    margin-top: 4rem;
}

.contact-item {
    display: flex;
    align-items: center;
    margin-bottom: 2rem;
    padding: 1.5rem;
    border: 2px solid var(--accent-color);
    transition: all 0.3s ease;
    cursor: pointer;
}

.contact-item:hover {
    transform: translateY(-5px);
    border-color: var(--secondary-color);
    box-shadow: 0 0 20px var(--secondary-color);
}

.contact-icon {
    font-size: 2rem;
    color: var(--accent-color);
    margin-right: 1.5rem;
    transition: all 0.3s ease;
}

.contact-item:hover .contact-icon {
    color: var(--secondary-color);
    transform: scale(1.2);
}

.contact-text h3 {
    font-size: 1.2rem;
    margin-bottom: 0.5rem;
}

.social-links {
    display: flex;
    gap: 1rem;
    margin-top: 2rem;
}

.social-link {
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid var(--primary-color);
    color: var(--primary-color);
    font-size: 1.5rem;
    transition: all 0.3s ease;
}

.social-link:hover {
    background-color: var(--primary-color);
    color: var(--background-dark);
    transform: translateY(-5px);
    box-shadow: 0 0 15px var(--primary-color);
}

/* Loading animation */
.submit-btn {
    position: relative;
    overflow: hidden;
}

.submit-btn.loading {
    pointer-events: none;
}

.submit-btn.loading::after {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(
        90deg,
        transparent,
        rgba(255, 255, 255, 0.2),
        transparent
    );
    animation: loading 1s infinite;
}

@keyframes loading {
    0% { transform: translateX(-100%); }
    100% { transform: translateX(100%); }
}

/* Success message animation */
.success-message {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: var(--background-dark);
    border: 2px solid var(--primary-color);
    padding: 2rem;
    text-align: center;
    z-index: 1000;
    animation: success-appear 0.5s ease;
}

@keyframes success-appear {
    from { 
        opacity: 0;
        transform: translate(-50%, -60%);
    }
    to {
        opacity: 1;
        transform: translate(-50%, -50%);
    }
}

/* Map section */
.map-section {
    position: relative;
    height: 400px;
    margin-top: 4rem;
    border: 2px solid var(--primary-color);
    overflow: hidden;
}

.map-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(
        45deg,
        rgba(0, 255, 0, 0.1),
        transparent
    );
    pointer-events: none;
}

/* Responsive design */
@media (max-width: 768px) {
    .contact-header {
        padding: 4rem 0;
    }

    .contact-form-container {
        margin-top: -50px;
    }

    .contact-item {
        flex-direction: column;
        text-align: center;
        padding: 1rem;
    }

    .contact-icon {
        margin: 0 0 1rem 0;
    }

    .map-section {
        height: 300px;
    }
}
</style>
@endsection

@section('content')
<section class="contact-header">
    <div class="contact-grid"></div>
    <div class="container">
        <h1 class="text-center mb-4 glitch" data-text="Contact Us">Contact Us</h1>
        <p class="text-center text-light mb-5">Get in touch with our team for any inquiries or support</p>
    </div>
</section>

<div class="container">
    <div class="contact-form-container">
        <div class="row">
            <div class="col-lg-8">
                <div class="contact-card">
                    <form id="contactForm" action="{{ route('contact.submit') }}" method="POST">
                        @csrf
                        <div class="form-group">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" required placeholder="Enter your name">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" required placeholder="Enter your email">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Subject</label>
                            <input type="text" class="form-control" name="subject" required placeholder="Enter subject">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Message</label>
                            <textarea class="form-control" name="message" required placeholder="Enter your message"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary submit-btn">
                            Send Message
                        </button>
                    </form>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="contact-info">
                    <div class="contact-item">
                        <i class="fas fa-map-marker-alt contact-icon"></i>
                        <div class="contact-text">
                            <h3>Location</h3>
                            <p>123 Digital Street, Tech City, TC 12345</p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-phone contact-icon"></i>
                        <div class="contact-text">
                            <h3>Phone</h3>
                            <p>+1 (555) 123-4567</p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-envelope contact-icon"></i>
                        <div class="contact-text">
                            <h3>Email</h3>
                            <p>contact@ignitehub.com</p>
                        </div>
                    </div>
                    <div class="social-links">
                        <a href="#" class="social-link"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-linkedin"></i></a>
                        <a href="#" class="social-link"><i class="fab fa-github"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="map-section">
        <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.305935303!2d-74.25986548248684!3d40.69714941932609!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2s!4v1647043087261!5m2!1sen!2s"
            width="100%"
            height="100%"
            style="border:0;"
            allowfullscreen=""
            loading="lazy">
        </iframe>
        <div class="map-overlay"></div>
    </div>
</div>

<div class="success-message" id="successMessage">
    <i class="fas fa-check-circle" style="font-size: 3rem; color: var(--primary-color); margin-bottom: 1rem;"></i>
    <h3>Message Sent!</h3>
    <p>We'll get back to you soon.</p>
</div>
@endsection

@section('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('contactForm');
    const successMessage = document.getElementById('successMessage');

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        const submitBtn = form.querySelector('.submit-btn');
        submitBtn.classList.add('loading');

        // Simulate form submission (replace with actual AJAX call)
        setTimeout(() => {
            submitBtn.classList.remove('loading');
            form.reset();
            successMessage.style.display = 'block';
            setTimeout(() => {
                successMessage.style.display = 'none';
            }, 3000);
        }, 1500);
    });

    // Animate contact items on scroll
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    });

    document.querySelectorAll('.contact-item').forEach(item => {
        item.style.opacity = '0';
        item.style.transform = 'translateY(20px)';
        item.style.transition = 'all 0.5s ease';
        observer.observe(item);
    });
});
</script>
@endsection
