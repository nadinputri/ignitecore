#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored messages
print_message() {
    echo -e "${2}${1}${NC}"
}

# Function to check command status
check_status() {
    if [ $? -eq 0 ]; then
        print_message "✓ $1" "$GREEN"
    else
        print_message "✗ $1" "$RED"
        exit 1
    fi
}

# Check if script is run with sudo
if [ "$EUID" -ne 0 ]; then
    print_message "Please run this script with sudo privileges" "$RED"
    exit 1
fi

print_message "Starting MemeBot Trading System Installation..." "$YELLOW"

# Update system packages
print_message "\nUpdating system packages..." "$YELLOW"
apt-get update && apt-get upgrade -y
check_status "System packages updated"

# Install system dependencies
print_message "\nInstalling system dependencies..." "$YELLOW"
apt-get install -y \
    build-essential \
    python3 \
    python3-pip \
    python3-dev \
    python3-venv \
    git \
    curl \
    wget \
    nvidia-cuda-toolkit \
    nvidia-cuda-toolkit-gcc
check_status "System dependencies installed"

# Check CUDA installation
print_message "\nChecking CUDA installation..." "$YELLOW"
if command -v nvcc &> /dev/null; then
    CUDA_VERSION=$(nvcc --version | grep "release" | awk '{print $6}' | cut -c2-)
    print_message "CUDA version $CUDA_VERSION detected" "$GREEN"
else
    print_message "CUDA not found. Please install CUDA toolkit first" "$RED"
    exit 1
fi

# Create virtual environment
print_message "\nSetting up Python virtual environment..." "$YELLOW"
python3 -m venv venv
source venv/bin/activate
check_status "Virtual environment created"

# Upgrade pip
print_message "\nUpgrading pip..." "$YELLOW"
pip install --upgrade pip
check_status "Pip upgraded"

# Install Python dependencies
print_message "\nInstalling Python dependencies..." "$YELLOW"
pip install -r requirements.txt
check_status "Python dependencies installed"

# Create configuration directory
print_message "\nSetting up configuration..." "$YELLOW"
mkdir -p config
if [ ! -f config/api_config.json ]; then
    cat > config/api_config.json << EOF
{
    "base_urls": {
        "binance": "https://api.binance.com",
        "coingecko": "https://api.coingecko.com/api/v3"
    },
    "api_keys": {
        "binance": "",
        "binance_secret": ""
    },
    "rate_limits": {
        "binance": {"requests": 1200, "period": 60},
        "coingecko": {"requests": 50, "period": 60}
    }
}
EOF
fi

if [ ! -f config/bot_config.json ]; then
    cat > config/bot_config.json << EOF
{
    "risk_level": "medium",
    "monitoring_interval": 300,
    "alert_threshold": 0.7,
    "max_position_size": 0.1,
    "stop_loss_pct": 0.05,
    "take_profit_pct": 0.15
}
EOF
fi

if [ ! -f config/telegram.json ]; then
    cat > config/telegram.json << EOF
{
    "bot_token": "",
    "api_id": "",
    "api_hash": "",
    "alert_chat_ids": []
}
EOF
fi
check_status "Configuration files created"

# Create log directory
print_message "\nSetting up logging..." "$YELLOW"
mkdir -p logs
touch logs/trading_bot.log
touch logs/api_server.log
check_status "Log files created"

# Set up environment variables
print_message "\nSetting up environment variables..." "$YELLOW"
if [ ! -f .env ]; then
    cat > .env << EOF
# API Credentials
API_USERNAME=admin
API_PASSWORD=changeme

# Telegram Bot
TELEGRAM_BOT_TOKEN=
TELEGRAM_API_ID=
TELEGRAM_API_HASH=

# Exchange API Keys
BINANCE_API_KEY=
BINANCE_SECRET_KEY=

# Security
JWT_SECRET=changeme
EOF
fi
check_status "Environment file created"

# Set permissions
print_message "\nSetting file permissions..." "$YELLOW"
chmod +x main.py
chmod +x api_server.py
chmod 600 .env
chmod 600 config/*.json
check_status "Permissions set"

# Create systemd service for API server
print_message "\nSetting up systemd service..." "$YELLOW"
cat > /etc/systemd/system/memebot-api.service << EOF
[Unit]
Description=MemeBot Trading API Server
After=network.target

[Service]
User=$SUDO_USER
WorkingDirectory=$(pwd)
Environment="PATH=$(pwd)/venv/bin:$PATH"
ExecStart=$(pwd)/venv/bin/python api_server.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable memebot-api.service
check_status "Systemd service created"

print_message "\nInstallation completed successfully!" "$GREEN"
print_message "\nNext steps:" "$YELLOW"
print_message "1. Edit .env file with your API credentials" "$YELLOW"
print_message "2. Edit config/*.json files with your settings" "$YELLOW"
print_message "3. Start the API server: sudo systemctl start memebot-api" "$YELLOW"
print_message "4. Start the trading bot: ./main.py" "$YELLOW"
print_message "\nFor more information, see README.md" "$YELLOW"
