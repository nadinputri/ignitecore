<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('service_id')->constrained();
            $table->enum('status', [
                'pending',
                'price_offered',
                'price_countered',
                'accepted',
                'in_progress',
                'completed',
                'cancelled',
                'refunded'
            ])->default('pending');
            $table->text('requirements');
            $table->decimal('initial_price', 10, 2)->nullable();
            $table->decimal('counter_price', 10, 2)->nullable();
            $table->decimal('final_price', 10, 2)->nullable();
            $table->text('admin_notes')->nullable();
            $table->timestamp('price_offered_at')->nullable();
            $table->timestamp('price_countered_at')->nullable();
            $table->timestamp('accepted_at')->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamp('cancelled_at')->nullable();
            $table->timestamp('refunded_at')->nullable();
            $table->text('refund_reason')->nullable();
            $table->timestamps();

            // Indexes for common queries
            $table->index('status');
            $table->index('created_at');
            $table->index(['user_id', 'status']);
            $table->index(['service_id', 'status']);
        });

        // Create order_transactions table for tracking order-related wallet transactions
        Schema::create('order_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained()->onDelete('cascade');
            $table->foreignId('wallet_transaction_id')->constrained('wallet_transactions')->onDelete('cascade');
            $table->enum('type', ['payment', 'refund']);
            $table->timestamps();

            // Indexes
            $table->index(['order_id', 'type']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('order_transactions');
        Schema::dropIfExists('orders');
    }
};
