#!/usr/bin/env python3
import argparse
import json
import logging
import os
import sys
import torch
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
    TextIteratorStreamer,
    GenerationConfig
)
from threading import Thread
from typing import Dict, Optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def parse_args():
    parser = argparse.ArgumentParser(description='Generate text using a local LLM')
    parser.add_argument('--model', type=str, required=True, help='Path to model directory')
    parser.add_argument('--prompt', type=str, required=True, help='Input prompt')
    parser.add_argument('--max-tokens', type=int, default=2048, help='Maximum tokens to generate')
    parser.add_argument('--temperature', type=float, default=0.7, help='Sampling temperature')
    parser.add_argument('--batch-size', type=int, default=32, help='Batch size for generation')
    parser.add_argument('--threads', type=int, default=4, help='Number of CPU threads')
    parser.add_argument('--gpu-layers', type=int, default=-1, help='Number of layers to offload to GPU')
    parser.add_argument('--ctx-size', type=int, default=4096, help='Context window size')
    parser.add_argument('--stream', action='store_true', help='Stream output tokens')
    return parser.parse_args()

def load_model_info(model_path: str) -> Dict:
    """Load model information from model_info.json"""
    info_path = os.path.join(model_path, 'model_info.json')
    if os.path.exists(info_path):
        with open(info_path, 'r') as f:
            return json.load(f)
    return {}

def setup_gpu_offload(gpu_layers: int, model_info: Dict) -> Optional[Dict]:
    """Configure GPU offloading based on model info and available hardware"""
    if not torch.cuda.is_available():
        logger.warning('CUDA not available, using CPU only')
        return None

    if gpu_layers == 0:
        return None

    total_layers = model_info.get('num_hidden_layers', 32)
    if gpu_layers == -1:
        gpu_layers = total_layers

    gpu_layers = min(gpu_layers, total_layers)
    logger.info(f'Offloading {gpu_layers} layers to GPU')

    return {
        'device_map': 'auto',
        'max_memory': {0: '80%', 'cpu': '80%'},
        'offload_folder': 'offload',
        'offload_state_dict': True,
        'torch_dtype': torch.float16
    }

def setup_quantization(model_info: Dict) -> Optional[BitsAndBytesConfig]:
    """Configure model quantization based on model info"""
    quantization = model_info.get('quantization', '4-bit')
    if quantization == 'none':
        return None

    return BitsAndBytesConfig(
        load_in_4bit=(quantization == '4-bit'),
        load_in_8bit=(quantization == '8-bit'),
        bnb_4bit_compute_dtype=torch.float16 if quantization == '4-bit' else None,
        bnb_4bit_use_double_quant=True,
        bnb_4bit_quant_type='nf4'
    )

def create_generation_config(args) -> GenerationConfig:
    """Create generation configuration"""
    return GenerationConfig(
        max_new_tokens=args.max_tokens,
        temperature=args.temperature,
        top_p=0.95,
        top_k=50,
        repetition_penalty=1.1,
        do_sample=True,
        pad_token_id=0,
        eos_token_id=2,
        bos_token_id=1
    )

def generate_response(model, tokenizer, prompt: str, gen_config: GenerationConfig, stream: bool = False):
    """Generate response from the model"""
    inputs = tokenizer(prompt, return_tensors='pt', padding=True)
    if torch.cuda.is_available():
        inputs = inputs.to('cuda')

    if stream:
        streamer = TextIteratorStreamer(tokenizer, skip_prompt=True)
        generation_kwargs = dict(
            **inputs,
            streamer=streamer,
            generation_config=gen_config
        )

        thread = Thread(target=model.generate, kwargs=generation_kwargs)
        thread.start()

        for text in streamer:
            print(text, end='', flush=True)
        thread.join()
    else:
        outputs = model.generate(
            **inputs,
            generation_config=gen_config
        )
        response = tokenizer.decode(outputs[0], skip_special_tokens=True)
        print(response[len(prompt):].strip())

def main():
    args = parse_args()
    torch.set_num_threads(args.threads)

    try:
        # Load model info
        model_info = load_model_info(args.model)
        logger.info(f'Loading model from {args.model}')

        # Setup configurations
        gpu_config = setup_gpu_offload(args.gpu_layers, model_info)
        quant_config = setup_quantization(model_info)
        gen_config = create_generation_config(args)

        # Load model and tokenizer
        tokenizer = AutoTokenizer.from_pretrained(
            args.model,
            trust_remote_code=True,
            use_fast=True
        )

        model = AutoModelForCausalLM.from_pretrained(
            args.model,
            trust_remote_code=True,
            quantization_config=quant_config,
            **(gpu_config or {}),
            low_cpu_mem_usage=True,
            device_map='auto' if torch.cuda.is_available() else None
        )

        # Generate response
        generate_response(model, tokenizer, args.prompt, gen_config, args.stream)

    except Exception as e:
        logger.error(f'Error generating response: {str(e)}')
        sys.exit(1)

if __name__ == '__main__':
    main()
