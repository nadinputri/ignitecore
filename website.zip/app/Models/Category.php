<?php

namespace App\Models;

use App\Traits\LogsActivity;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Category extends Model
{
    use HasFactory, SoftDeletes, LogsActivity;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'slug',
        'description',
        'active',
        'sort_order',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'active' => 'boolean',
        'sort_order' => 'integer',
        'deleted_at' => 'datetime',
    ];

    /**
     * Boot the model.
     */
    protected static function boot()
    {
        parent::boot();

        // Auto-generate slug from name when creating/updating
        static::saving(function ($category) {
            if ($category->isDirty('name')) {
                $category->slug = static::generateUniqueSlug($category->name);
            }
        });
    }

    /**
     * Get the services for the category.
     */
    public function services()
    {
        return $this->hasMany(Service::class);
    }

    /**
     * Get active services for the category.
     */
    public function activeServices()
    {
        return $this->services()->where('active', true);
    }

    /**
     * Scope a query to only include active categories.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where('active', true);
    }

    /**
     * Scope a query to order by sort_order.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeOrdered($query)
    {
        return $query->orderBy('sort_order')->orderBy('name');
    }

    /**
     * Get the category's status label.
     *
     * @return string
     */
    public function getStatusLabelAttribute()
    {
        return $this->active ? 'Active' : 'Inactive';
    }

    /**
     * Get the category's status class for UI.
     *
     * @return string
     */
    public function getStatusClassAttribute()
    {
        return $this->active ? 'success' : 'danger';
    }

    /**
     * Check if the category can be deleted.
     *
     * @return bool
     */
    public function canBeDeleted()
    {
        return $this->services()->count() === 0;
    }

    /**
     * Generate a unique slug from the given name.
     *
     * @param string $name
     * @return string
     */
    protected static function generateUniqueSlug($name)
    {
        $slug = Str::slug($name);
        $count = static::where('slug', 'LIKE', "{$slug}%")
            ->where('id', '!=', static::id())
            ->count();

        return $count ? "{$slug}-{$count}" : $slug;
    }

    /**
     * Get the route key for the model.
     *
     * @return string
     */
    public function getRouteKeyName()
    {
        return 'slug';
    }

    /**
     * Get the number of active services in this category.
     *
     * @return int
     */
    public function getActiveServicesCountAttribute()
    {
        return $this->activeServices()->count();
    }

    /**
     * Move the category up in sort order.
     *
     * @return bool
     */
    public function moveUp()
    {
        $previousCategory = static::where('sort_order', '<', $this->sort_order)
            ->orderBy('sort_order', 'desc')
            ->first();

        if ($previousCategory) {
            $currentOrder = $this->sort_order;
            $this->sort_order = $previousCategory->sort_order;
            $previousCategory->sort_order = $currentOrder;

            return $this->save() && $previousCategory->save();
        }

        return false;
    }

    /**
     * Move the category down in sort order.
     *
     * @return bool
     */
    public function moveDown()
    {
        $nextCategory = static::where('sort_order', '>', $this->sort_order)
            ->orderBy('sort_order')
            ->first();

        if ($nextCategory) {
            $currentOrder = $this->sort_order;
            $this->sort_order = $nextCategory->sort_order;
            $nextCategory->sort_order = $currentOrder;

            return $this->save() && $nextCategory->save();
        }

        return false;
    }

    /**
     * Get the activity description for the category.
     * Override the default description from LogsActivity trait.
     *
     * @param string $event
     * @return string
     */
    protected function getActivityDescription(string $event): string
    {
        return match ($event) {
            'created' => "Category '{$this->name}' was created",
            'updated' => "Category '{$this->name}' was updated",
            'deleted' => "Category '{$this->name}' was deleted",
            'restored' => "Category '{$this->name}' was restored from trash",
            default => parent::getActivityDescription($event),
        };
    }

    /**
     * Get the properties to be logged.
     * Override the default properties from LogsActivity trait.
     *
     * @return array
     */
    protected function getActivityProperties(): array
    {
        $properties = $this->getAttributes();
        
        // Remove unnecessary timestamps
        unset($properties['created_at'], $properties['updated_at'], $properties['deleted_at']);
        
        // Add additional information
        $properties['status'] = $this->status_label;
        $properties['services_count'] = $this->services()->count();
        $properties['active_services_count'] = $this->activeServices()->count();

        return $properties;
    }

    /**
     * Determine if the model should log activity.
     * Override the default condition from LogsActivity trait.
     *
     * @return bool
     */
    protected function shouldLogActivity(): bool
    {
        // Always log category changes as they affect service organization
        return true;
    }
}
