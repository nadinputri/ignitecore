<?php

namespace App\Traits;

use App\Models\ActivityLog;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

trait LogsActivity
{
    /**
     * Boot the trait.
     */
    protected static function bootLogsActivity()
    {
        static::created(function (Model $model) {
            $model->logActivity('created');
        });

        static::updated(function (Model $model) {
            // Only log if actual changes were made
            if ($model->wasChanged()) {
                $model->logActivity('updated', [
                    'old' => $model->getOriginal(),
                    'new' => $model->getAttributes(),
                    'changed' => $model->getChanges(),
                ]);
            }
        });

        static::deleted(function (Model $model) {
            $model->logActivity('deleted', [
                'old' => $model->getAttributes(),
            ]);
        });

        if (method_exists(static::class, 'restored')) {
            static::restored(function (Model $model) {
                $model->logActivity('restored');
            });
        }
    }

    /**
     * Log an activity for this model.
     *
     * @param string $event
     * @param array|null $properties
     * @return ActivityLog
     */
    public function logActivity(string $event, ?array $properties = null)
    {
        // Get the authenticated user
        $user = Auth::user();

        // Create description
        $description = $this->getActivityDescription($event);

        return ActivityLog::create([
            'user_id' => $user?->id,
            'event' => $event,
            'model_type' => get_class($this),
            'model_id' => $this->getKey(),
            'description' => $description,
            'properties' => $properties,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
        ]);
    }

    /**
     * Get the description for the activity.
     *
     * @param string $event
     * @return string
     */
    protected function getActivityDescription(string $event): string
    {
        $modelName = class_basename($this);

        // Check if model has a name or title attribute
        $identifier = $this->name ?? $this->title ?? $this->id;

        return match ($event) {
            'created' => "{$modelName} '{$identifier}' was created",
            'updated' => "{$modelName} '{$identifier}' was updated",
            'deleted' => "{$modelName} '{$identifier}' was deleted",
            'restored' => "{$modelName} '{$identifier}' was restored",
            default => "{$modelName} '{$identifier}' was {$event}",
        };
    }

    /**
     * Get all activity logs for this model.
     */
    public function activities()
    {
        return $this->morphMany(ActivityLog::class, 'subject', 'model_type', 'model_id');
    }

    /**
     * Get the latest activity for this model.
     */
    public function latestActivity()
    {
        return $this->morphOne(ActivityLog::class, 'subject', 'model_type', 'model_id')
            ->latest();
    }

    /**
     * Determine if the model should log activity.
     * Can be overridden in the model to add conditions.
     *
     * @return bool
     */
    protected function shouldLogActivity(): bool
    {
        return true;
    }

    /**
     * Get the properties to be logged.
     * Can be overridden in the model to customize logged properties.
     *
     * @return array
     */
    protected function getActivityProperties(): array
    {
        return $this->getAttributes();
    }
}
