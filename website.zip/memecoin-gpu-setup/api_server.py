"""
API Server for handling requests from the admin panel
"""

import os
import sys
import logging
import asyncio
import json
from datetime import datetime
from typing import Dict, List, Optional
from fastapi import FastAPI, HTTPException, Depends, Security, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from pydantic import BaseModel

from trading_modules import (
    MarketAnalyzer,
    PumpDumpDetector,
    TradingStrategy,
    TelegramBot
)
from api_integration import APIIntegration

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("api_server.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="MemeBot API",
    description="API for managing memecoin trading bot",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBasic()

def get_current_username(credentials: HTTPBasicCredentials = Depends(security)):
    """Validate API credentials"""
    correct_username = os.getenv("API_USERNAME")
    correct_password = os.getenv("API_PASSWORD")
    
    if not (credentials.username == correct_username and 
            credentials.password == correct_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid credentials",
            headers={"WWW-Authenticate": "Basic"},
        )
    return credentials.username

# Request/Response Models
class TokenAnalysisRequest(BaseModel):
    token_symbol: str
    timeframe: str = "1h"
    limit: int = 100

class TradeRequest(BaseModel):
    token_symbol: str
    side: str
    quantity: float
    price: Optional[float] = None

class AlertSettingsRequest(BaseModel):
    risk_threshold: float
    volume_threshold: float
    price_threshold: float
    monitoring_interval: int

# Initialize components
market_analyzer = MarketAnalyzer()
pump_detector = PumpDumpDetector()
trading_strategy = TradingStrategy()
telegram_bot = TelegramBot()
api_integration = APIIntegration()

@app.on_event("startup")
async def startup_event():
    """Initialize components on startup"""
    try:
        await api_integration.start()
        await telegram_bot.start()
        logger.info("API server started successfully")
    except Exception as e:
        logger.error(f"Error starting API server: {str(e)}")
        sys.exit(1)

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    try:
        await api_integration.stop()
        await telegram_bot.stop()
        logger.info("API server shut down successfully")
    except Exception as e:
        logger.error(f"Error shutting down API server: {str(e)}")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}

@app.post("/analyze")
async def analyze_token(
    request: TokenAnalysisRequest,
    username: str = Depends(get_current_username)
):
    """Analyze token for trading opportunities"""
    try:
        # Get market data
        market_data = await api_integration.get_historical_data(
            request.token_symbol,
            request.timeframe,
            request.limit
        )
        
        if not market_data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Market data not found"
            )
            
        # Perform analysis
        analysis = trading_strategy.analyze_opportunity(market_data)
        if not analysis:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Analysis failed"
            )
            
        return analysis
        
    except Exception as e:
        logger.error(f"Error analyzing token: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@app.post("/trade")
async def execute_trade(
    request: TradeRequest,
    username: str = Depends(get_current_username)
):
    """Execute a trade"""
    try:
        result = await api_integration.execute_trade(
            request.token_symbol,
            request.side,
            request.quantity,
            request.price
        )
        
        if not result:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Trade execution failed"
            )
            
        return result
        
    except Exception as e:
        logger.error(f"Error executing trade: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@app.get("/market-data/{token_symbol}")
async def get_market_data(
    token_symbol: str,
    timeframe: str = "1h",
    limit: int = 100,
    username: str = Depends(get_current_username)
):
    """Get market data for a token"""
    try:
        data = await api_integration.get_historical_data(
            token_symbol,
            timeframe,
            limit
        )
        
        if data is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Market data not found"
            )
            
        return data.to_dict(orient='records')
        
    except Exception as e:
        logger.error(f"Error getting market data: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@app.get("/token-info/{token_symbol}")
async def get_token_info(
    token_symbol: str,
    username: str = Depends(get_current_username)
):
    """Get detailed token information"""
    try:
        info = await api_integration.get_token_info(token_symbol)
        if info is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Token info not found"
            )
        return info
        
    except Exception as e:
        logger.error(f"Error getting token info: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@app.post("/alert-settings")
async def update_alert_settings(
    settings: AlertSettingsRequest,
    username: str = Depends(get_current_username)
):
    """Update alert settings"""
    try:
        # Update pump detector settings
        pump_detector.volume_threshold = settings.volume_threshold
        pump_detector.price_threshold = settings.price_threshold
        
        # Update trading strategy settings
        trading_strategy.risk_threshold = settings.risk_threshold
        
        return {
            "status": "success",
            "message": "Alert settings updated successfully"
        }
        
    except Exception as e:
        logger.error(f"Error updating alert settings: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@app.get("/monitoring-status")
async def get_monitoring_status(
    username: str = Depends(get_current_username)
):
    """Get current monitoring status"""
    try:
        return {
            "monitoring_active": telegram_bot.monitoring_active,
            "subscribers": len(telegram_bot.alert_channels),
            "last_update": datetime.now().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error getting monitoring status: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

@app.post("/monitoring/{action}")
async def control_monitoring(
    action: str,
    username: str = Depends(get_current_username)
):
    """Control monitoring system"""
    try:
        if action == "start":
            await telegram_bot.start_monitoring()
            message = "Monitoring started"
        elif action == "stop":
            await telegram_bot.stop_monitoring()
            message = "Monitoring stopped"
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid action"
            )
            
        return {"status": "success", "message": message}
        
    except Exception as e:
        logger.error(f"Error controlling monitoring: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(e)
        )

def main():
    """Main entry point"""
    try:
        uvicorn.run(
            "api_server:app",
            host="0.0.0.0",
            port=8000,
            reload=True
        )
    except Exception as e:
        logger.error(f"Error running API server: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
