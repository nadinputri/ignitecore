<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        Commands\SecurityAudit::class,
        Commands\CleanActivityLogs::class,
        Commands\CleanInactiveUsers::class,
        Commands\CleanNotifications::class,
        Commands\MonitorLlm::class,
        Commands\LlmGenerate::class,
        Commands\LlmManage::class,
        Commands\MonitorTokens::class,
    ];

    /**
     * Define the application's command schedule.
     */
    protected function schedule(Schedule $schedule): void
    {
        // Security related tasks
        $schedule->command('security:audit --notify')
            ->daily()
            ->at('02:00')
            ->appendOutputTo(storage_path('logs/security-audit.log'));

        $schedule->command('activity-logs:clean')
            ->daily()
            ->at('03:00')
            ->appendOutputTo(storage_path('logs/activity-logs-cleanup.log'));

        $schedule->command('users:clean-inactive')
            ->daily()
            ->at('04:00')
            ->appendOutputTo(storage_path('logs/inactive-users-cleanup.log'));

        $schedule->command('notifications:clean')
            ->daily()
            ->at('05:00')
            ->appendOutputTo(storage_path('logs/notifications-cleanup.log'));

        // Monitor system resources
        $schedule->command('monitor:llm')
            ->everyFiveMinutes()
            ->appendOutputTo(storage_path('logs/llm-monitor.log'));

        // Token monitoring and analysis
        $schedule->command('monitor:tokens')
            ->everyMinute()
            ->appendOutputTo(storage_path('logs/token-monitor.log'));

        // Database maintenance
        $schedule->command('db:backup')
            ->dailyAt('01:00')
            ->appendOutputTo(storage_path('logs/backup.log'));

        // Clear expired sessions
        $schedule->command('session:gc')
            ->daily()
            ->at('00:00');

        // Check for security updates
        $schedule->command('composer audit --format=json')
            ->daily()
            ->at('06:00')
            ->appendOutputTo(storage_path('logs/security-updates.log'));

        // Monitor file permissions
        $schedule->call(function () {
            $criticalPaths = [
                base_path('.env'),
                storage_path('logs'),
                storage_path('framework/sessions'),
                storage_path('app/private'),
            ];

            foreach ($criticalPaths as $path) {
                if (file_exists($path)) {
                    $perms = fileperms($path);
                    if (($perms & 0x0002) || ($perms & 0x0020)) {
                        \Log::warning("Insecure permissions detected on: {$path}");
                    }
                }
            }
        })->daily()->at('07:00');

        // Check SSL certificate expiration
        if (app()->environment('production')) {
            $schedule->call(function () {
                $domain = config('app.url');
                $cert = openssl_x509_parse(openssl_x509_read(
                    stream_context_get_params(
                        stream_context_create(['ssl' => ['capture_peer_cert' => true]])
                    )['options']['ssl']['peer_certificate']
                ));
                
                $expiryDate = $cert['validTo_time_t'];
                $daysUntilExpiry = ceil(($expiryDate - time()) / 86400);
                
                if ($daysUntilExpiry <= 30) {
                    \Log::warning("SSL certificate expires in {$daysUntilExpiry} days");
                }
            })->weekly();
        }

        // Clean temporary files
        $schedule->call(function () {
            $tempPath = storage_path('app/temp');
            if (is_dir($tempPath)) {
                foreach (glob("{$tempPath}/*") as $file) {
                    if (filemtime($file) < time() - 86400) {
                        unlink($file);
                    }
                }
            }
        })->daily();

        // Verify file integrity
        $schedule->call(function () {
            $integrityFile = storage_path('integrity.json');
            if (!file_exists($integrityFile)) {
                $this->generateIntegrityFile($integrityFile);
            }

            $checksums = json_decode(file_get_contents($integrityFile), true);
            foreach ($checksums as $file => $hash) {
                if (file_exists($file)) {
                    $currentHash = md5_file($file);
                    if ($currentHash !== $hash) {
                        \Log::alert("File integrity violation detected: {$file}");
                    }
                }
            }
        })->daily();
    }

    /**
     * Register the commands for the application.
     */
    protected function commands(): void
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }

    /**
     * Generate integrity file for critical system files
     */
    protected function generateIntegrityFile($integrityFile): void
    {
        $criticalFiles = [
            app_path('Http/Kernel.php'),
            app_path('Providers/AppServiceProvider.php'),
            app_path('Http/Middleware/SecurityHeaders.php'),
            app_path('Http/Middleware/ApiSecurity.php'),
            app_path('Services/SecurityService.php'),
            config_path('security.php'),
        ];

        $checksums = [];
        foreach ($criticalFiles as $file) {
            if (file_exists($file)) {
                $checksums[$file] = md5_file($file);
            }
        }

        file_put_contents($integrityFile, json_encode($checksums, JSON_PRETTY_PRINT));
    }
}
