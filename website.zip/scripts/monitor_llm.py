#!/usr/bin/env python3
import argparse
import json
import logging
import os
import sys
import time
from datetime import datetime
from pathlib import Path
import psutil
import torch
import GPUtil

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def parse_args():
    parser = argparse.ArgumentParser(description='Monitor LLM system resources')
    parser.add_argument('--model-dir', type=str, required=True, help='Model directory')
    parser.add_argument('--log-dir', type=str, required=True, help='Log directory')
    parser.add_argument('--watch', action='store_true', help='Continuously monitor')
    parser.add_argument('--interval', type=int, default=300, help='Monitoring interval in seconds')
    return parser.parse_args()

def get_system_metrics():
    """Get system resource metrics"""
    metrics = {
        'cpu': {
            'percent': psutil.cpu_percent(interval=1),
            'count': psutil.cpu_count(),
            'frequency': psutil.cpu_freq()._asdict() if psutil.cpu_freq() else None
        },
        'memory': {
            'total': psutil.virtual_memory().total,
            'available': psutil.virtual_memory().available,
            'percent': psutil.virtual_memory().percent,
            'used': psutil.virtual_memory().used,
            'swap_total': psutil.swap_memory().total,
            'swap_used': psutil.swap_memory().used,
            'swap_percent': psutil.swap_memory().percent
        },
        'disk': {
            'total': psutil.disk_usage('/').total,
            'used': psutil.disk_usage('/').used,
            'free': psutil.disk_usage('/').free,
            'percent': psutil.disk_usage('/').percent
        },
        'network': {
            'bytes_sent': psutil.net_io_counters().bytes_sent,
            'bytes_recv': psutil.net_io_counters().bytes_recv,
            'packets_sent': psutil.net_io_counters().packets_sent,
            'packets_recv': psutil.net_io_counters().packets_recv
        },
        'gpu': None
    }

    # Get GPU metrics if available
    try:
        if torch.cuda.is_available():
            gpus = []
            for i in range(torch.cuda.device_count()):
                gpu = {
                    'id': i,
                    'name': torch.cuda.get_device_name(i),
                    'memory_total': torch.cuda.get_device_properties(i).total_memory,
                    'memory_used': torch.cuda.memory_allocated(i),
                    'memory_free': torch.cuda.memory_reserved(i) - torch.cuda.memory_allocated(i),
                    'utilization': None
                }
                gpus.append(gpu)

            # Get GPU utilization using GPUtil
            for gpu in GPUtil.getGPUs():
                if gpu.id < len(gpus):
                    gpus[gpu.id]['utilization'] = gpu.load * 100

            metrics['gpu'] = gpus
    except Exception as e:
        logger.warning(f'Failed to get GPU metrics: {e}')

    return metrics

def analyze_metrics(metrics, model_dir):
    """Analyze metrics and generate warnings/recommendations"""
    analysis = {
        'warnings': [],
        'recommendations': [],
        'health_checks': []
    }

    # CPU checks
    if metrics['cpu']['percent'] > 90:
        analysis['warnings'].append('CPU usage is critically high')
        analysis['recommendations'].append('Consider reducing batch size or number of threads')
    elif metrics['cpu']['percent'] > 75:
        analysis['warnings'].append('CPU usage is high')

    # Memory checks
    if metrics['memory']['percent'] > 90:
        analysis['warnings'].append('System memory usage is critically high')
        analysis['recommendations'].append('Consider using model quantization or a smaller model')
    elif metrics['memory']['percent'] > 75:
        analysis['warnings'].append('System memory usage is high')

    # Disk checks
    if metrics['disk']['percent'] > 90:
        analysis['warnings'].append('Disk usage is critically high')
        analysis['recommendations'].append('Clean up old model files and logs')
    elif metrics['disk']['percent'] > 75:
        analysis['warnings'].append('Disk usage is high')

    # GPU checks
    if metrics['gpu']:
        for gpu in metrics['gpu']:
            memory_used_gb = gpu['memory_used'] / (1024**3)
            memory_total_gb = gpu['memory_total'] / (1024**3)
            memory_percent = (memory_used_gb / memory_total_gb) * 100

            if memory_percent > 90:
                analysis['warnings'].append(f'GPU {gpu["id"]} memory usage is critically high')
                analysis['recommendations'].append('Consider using fewer GPU layers or more quantization')
            elif memory_percent > 75:
                analysis['warnings'].append(f'GPU {gpu["id"]} memory usage is high')

            if gpu['utilization'] and gpu['utilization'] > 90:
                analysis['warnings'].append(f'GPU {gpu["id"]} utilization is very high')
            
            analysis['health_checks'].append({
                'component': f'GPU {gpu["id"]}',
                'name': gpu['name'],
                'status': 'warning' if memory_percent > 75 else 'healthy',
                'memory_used_gb': round(memory_used_gb, 2),
                'memory_total_gb': round(memory_total_gb, 2),
                'utilization': gpu['utilization']
            })
    else:
        analysis['recommendations'].append('Consider using GPU acceleration for better performance')

    # Model checks
    model_size = sum(f.stat().st_size for f in Path(model_dir).glob('**/*') if f.is_file())
    model_size_gb = model_size / (1024**3)

    if model_size_gb > 50:
        analysis['recommendations'].append('Consider using a smaller model or quantization')

    analysis['health_checks'].append({
        'component': 'Model',
        'size_gb': round(model_size_gb, 2),
        'status': 'healthy'
    })

    return analysis

def write_metrics(metrics, analysis, log_dir):
    """Write metrics and analysis to log files"""
    timestamp = datetime.now().isoformat()
    data = {
        'timestamp': timestamp,
        'metrics': metrics,
        'analysis': analysis
    }

    # Write to JSON log file
    log_file = Path(log_dir) / 'metrics.jsonl'
    with open(log_file, 'a') as f:
        f.write(json.dumps(data) + '\n')

    # Write latest metrics
    latest_file = Path(log_dir) / 'latest.json'
    with open(latest_file, 'w') as f:
        json.dump(data, f, indent=2)

    # Write warnings to separate log if any
    if analysis['warnings']:
        warning_file = Path(log_dir) / 'warnings.log'
        with open(warning_file, 'a') as f:
            f.write(f"\n[{timestamp}]\n")
            for warning in analysis['warnings']:
                f.write(f"- {warning}\n")

def monitor(args):
    """Monitor system resources"""
    try:
        # Create log directory if it doesn't exist
        Path(args.log_dir).mkdir(parents=True, exist_ok=True)

        while True:
            # Get metrics
            metrics = get_system_metrics()
            
            # Analyze metrics
            analysis = analyze_metrics(metrics, args.model_dir)
            
            # Write to logs
            write_metrics(metrics, analysis, args.log_dir)

            # Print current status
            print(json.dumps({'metrics': metrics, 'analysis': analysis}, indent=2))

            if not args.watch:
                break

            time.sleep(args.interval)

    except KeyboardInterrupt:
        logger.info('Monitoring stopped')
    except Exception as e:
        logger.error(f'Monitoring failed: {e}')
        sys.exit(1)

if __name__ == '__main__':
    args = parse_args()
    monitor(args)
