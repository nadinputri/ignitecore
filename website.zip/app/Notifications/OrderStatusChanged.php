<?php

namespace App\Notifications;

use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class OrderStatusChanged extends Notification implements ShouldQueue
{
    use Queueable;

    protected $order;
    protected $previousStatus;
    protected $newStatus;
    protected $additionalMessage;

    /**
     * Create a new notification instance.
     */
    public function __construct(Order $order, string $previousStatus, string $newStatus, ?string $additionalMessage = null)
    {
        $this->order = $order;
        $this->previousStatus = $previousStatus;
        $this->newStatus = $newStatus;
        $this->additionalMessage = $additionalMessage;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail', 'database'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail(object $notifiable): MailMessage
    {
        $message = (new MailMessage)
            ->subject("Order #{$this->order->id} Status Update")
            ->greeting("Hello {$notifiable->name},")
            ->line("Your order #{$this->order->id} status has been updated from **{$this->getStatusLabel($this->previousStatus)}** to **{$this->getStatusLabel($this->newStatus)}**.");

        // Add status-specific information
        switch ($this->newStatus) {
            case 'price_offered':
                $message->line("We've offered a price of $" . number_format($this->order->initial_price, 2) . " for your order.")
                    ->line("You can:")
                    ->line("1. Accept the offered price to proceed with the order")
                    ->line("2. Make a counter offer if you'd like to negotiate")
                    ->line("3. Cancel the order if you're not interested")
                    ->action('Review Price Offer', route('orders.show', $this->order));
                break;

            case 'accepted':
                $message->line("Your payment of $" . number_format($this->order->final_price, 2) . " has been processed successfully.")
                    ->line("We'll start working on your order soon.")
                    ->action('View Order Details', route('orders.show', $this->order));
                break;

            case 'in_progress':
                $message->line("Work has begun on your order.")
                    ->line("We'll keep you updated on the progress.")
                    ->action('View Order Progress', route('orders.show', $this->order));
                break;

            case 'completed':
                $message->line("Your order has been completed!")
                    ->line("Please review the deliverables and let us know if you need any adjustments.")
                    ->action('View Completed Order', route('orders.show', $this->order));
                break;

            case 'cancelled':
                $message->line("Your order has been cancelled. No payment has been processed.");
                break;

            case 'refunded':
                $message->line("A refund of $" . number_format($this->order->final_price, 2) . " has been processed to your wallet.")
                    ->line("The refund amount is now available in your wallet balance.");
                break;
        }

        if ($this->additionalMessage) {
            $message->line($this->additionalMessage);
        }

        $message->line("If you have any questions, please don't hesitate to contact our support team.");

        return $message;
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            'order_id' => $this->order->id,
            'previous_status' => $this->previousStatus,
            'new_status' => $this->newStatus,
            'message' => $this->additionalMessage,
            'price' => $this->order->getCurrentPrice(),
            'service' => $this->order->service->name,
        ];
    }

    /**
     * Get a human-readable status label.
     */
    protected function getStatusLabel(string $status): string
    {
        return ucfirst(str_replace('_', ' ', $status));
    }
}
