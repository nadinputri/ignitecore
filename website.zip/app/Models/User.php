<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use App\Traits\LogsActivity;
use Illuminate\Support\Facades\Hash;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, LogsActivity;

    protected $fillable = [
        'name',
        'email',
        'password',
        'is_admin',
        'status',
        'suspended_until',
        'last_active_at',
        'login_attempts',
        'locked_until',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
        'suspended_until' => 'datetime',
        'last_active_at' => 'datetime',
        'locked_until' => 'datetime',
        'login_attempts' => 'integer',
    ];

    protected static $logAttributes = [
        'email',
        'is_admin',
        'status',
        'suspended_until',
        'last_active_at',
        'login_attempts',
        'locked_until',
    ];

    /**
     * Get the wallet associated with the user.
     */
    public function wallet()
    {
        return $this->hasOne(Wallet::class);
    }

    /**
     * Check if the user account is locked due to too many failed login attempts
     *
     * @return bool
     */
    public function isLocked()
    {
        return $this->locked_until && now()->lt($this->locked_until);
    }

    /**
     * Increment the failed login attempts counter
     *
     * @return void
     */
    public function incrementLoginAttempts()
    {
        $maxAttempts = config('users.security.max_login_attempts', 5);
        $lockoutDuration = config('users.security.lockout_duration', 15);
        
        $this->login_attempts++;
        
        if ($this->login_attempts >= $maxAttempts) {
            $this->locked_until = now()->addMinutes($lockoutDuration);
        }
        
        $this->save();
    }

    /**
     * Reset the failed login attempts counter
     *
     * @return void
     */
    public function resetLoginAttempts()
    {
        $this->login_attempts = 0;
        $this->locked_until = null;
        $this->save();
    }

    /**
     * Set a secure password for the user
     *
     * @param string $password
     * @return void
     */
    public function setSecurePassword($password)
    {
        $this->password = Hash::make($password);
        $this->save();
    }

    /**
     * Check if the password meets security requirements
     *
     * @param string $password
     * @return bool
     */
    public static function isPasswordSecure($password)
    {
        // At least 8 characters
        if (strlen($password) < 8) {
            return false;
        }
        
        // Check for complexity: at least one uppercase, one lowercase, one number, and one special character
        return preg_match('/[A-Z]/', $password) && 
               preg_match('/[a-z]/', $password) && 
               preg_match('/[0-9]/', $password) && 
               preg_match('/[^A-Za-z0-9]/', $password);
    }

    /**
     * Get the last active time in a human-readable format.
     *
     * @return string
     */
    public function getLastActiveAttribute()
    {
        return $this->last_active_at ? $this->last_active_at->diffForHumans() : 'Never';
    }
}
