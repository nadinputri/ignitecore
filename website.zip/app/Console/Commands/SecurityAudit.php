<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Models\User;
use App\Models\ActivityLog;

class SecurityAudit extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'security:audit {--notify : Send notification email with results}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Perform a security audit of the application';

    /**
     * Security issues found during audit
     *
     * @var array
     */
    protected $issues = [];

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $this->info('Starting security audit...');

        // Check file permissions
        if (config('security.audit.check_file_permissions', true)) {
            $this->checkFilePermissions();
        }

        // Check PHP version
        if (config('security.audit.check_php_version', true)) {
            $this->checkPhpVersion();
        }

        // Check for suspicious activity
        $this->checkSuspiciousActivity();

        // Check database security
        $this->checkDatabaseSecurity();

        // Check user security
        $this->checkUserSecurity();

        // Check file upload directory
        $this->checkFileUploadDirectory();

        // Check environment file
        $this->checkEnvironmentFile();

        // Check composer dependencies
        if (config('security.audit.check_composer_dependencies', true)) {
            $this->checkComposerDependencies();
        }

        // Report findings
        $this->reportFindings();

        return 0;
    }

    /**
     * Check file permissions
     */
    protected function checkFilePermissions()
    {
        $criticalFiles = [
            base_path('.env'),
            base_path('config/security.php'),
            storage_path('logs'),
            storage_path('framework/sessions'),
        ];

        foreach ($criticalFiles as $file) {
            if (file_exists($file)) {
                $perms = fileperms($file);
                $worldWritable = $perms & 0x0002;
                
                if ($worldWritable) {
                    $this->issues[] = "Security Risk: {$file} is world-writable";
                }
            }
        }
    }

    /**
     * Check PHP version security
     */
    protected function checkPhpVersion()
    {
        $currentVersion = PHP_VERSION;
        $minimumVersion = '8.1.0';
        
        if (version_compare($currentVersion, $minimumVersion, '<')) {
            $this->issues[] = "Security Risk: PHP version {$currentVersion} is below recommended minimum {$minimumVersion}";
        }
    }

    /**
     * Check for suspicious activity
     */
    protected function checkSuspiciousActivity()
    {
        // Check failed login attempts
        $failedLogins = ActivityLog::where('event', 'login_failed')
            ->where('created_at', '>', now()->subDay())
            ->count();

        if ($failedLogins > config('security.ip_security.max_login_attempts', 10)) {
            $this->issues[] = "Security Alert: High number of failed login attempts in the last 24 hours ({$failedLogins})";
        }

        // Check for multiple password resets
        $passwordResets = ActivityLog::where('event', 'password_reset')
            ->where('created_at', '>', now()->subDay())
            ->count();

        if ($passwordResets > 5) {
            $this->issues[] = "Security Alert: High number of password resets in the last 24 hours ({$passwordResets})";
        }
    }

    /**
     * Check database security
     */
    protected function checkDatabaseSecurity()
    {
        try {
            // Check if default users exist
            $defaultUsers = User::whereIn('email', [
                'admin@admin.com',
                'test@test.com',
                'demo@demo.com'
            ])->count();

            if ($defaultUsers > 0) {
                $this->issues[] = "Security Risk: Default/test user accounts found";
            }

            // Check for users without 2FA if required
            if (config('security.two_factor.enforce_for_admins', true)) {
                $adminsWithout2FA = User::where('is_admin', true)
                    ->whereNull('two_factor_secret')
                    ->count();

                if ($adminsWithout2FA > 0) {
                    $this->issues[] = "Security Risk: {$adminsWithout2FA} admin users without 2FA enabled";
                }
            }
        } catch (\Exception $e) {
            $this->issues[] = "Database check failed: " . $e->getMessage();
        }
    }

    /**
     * Check user security
     */
    protected function checkUserSecurity()
    {
        // Check for expired passwords
        $passwordExpiryDays = config('security.passwords.expire_days', 90);
        $expiredPasswords = User::where('password_changed_at', '<', now()->subDays($passwordExpiryDays))
            ->count();

        if ($expiredPasswords > 0) {
            $this->issues[] = "Security Alert: {$expiredPasswords} users with expired passwords";
        }

        // Check for inactive users
        $inactiveUsers = User::where('last_active_at', '<', now()->subDays(30))
            ->where('is_active', true)
            ->count();

        if ($inactiveUsers > 0) {
            $this->issues[] = "Security Notice: {$inactiveUsers} users inactive for more than 30 days";
        }
    }

    /**
     * Check file upload directory
     */
    protected function checkFileUploadDirectory()
    {
        $uploadPath = storage_path('app/public/uploads');

        if (file_exists($uploadPath)) {
            // Check directory permissions
            $perms = fileperms($uploadPath);
            if (($perms & 0x0002) || ($perms & 0x0020)) {
                $this->issues[] = "Security Risk: Upload directory has unsafe permissions";
            }

            // Check for potentially dangerous files
            $dangerousExtensions = ['php', 'phtml', 'php3', 'php4', 'php5', 'phps'];
            
            foreach (File::allFiles($uploadPath) as $file) {
                if (in_array($file->getExtension(), $dangerousExtensions)) {
                    $this->issues[] = "Security Risk: Potentially dangerous file found in uploads: " . $file->getFilename();
                }
            }
        }
    }

    /**
     * Check environment file security
     */
    protected function checkEnvironmentFile()
    {
        $envPath = base_path('.env');
        
        if (file_exists($envPath)) {
            $perms = fileperms($envPath);
            
            // Check if .env is readable/writable by others
            if (($perms & 0x0004) || ($perms & 0x0002)) {
                $this->issues[] = "Critical Security Risk: .env file has unsafe permissions";
            }

            // Check for debug mode
            if (config('app.debug')) {
                $this->issues[] = "Security Risk: Application is in debug mode";
            }
        } else {
            $this->issues[] = "Security Risk: .env file not found";
        }
    }

    /**
     * Check composer dependencies
     */
    protected function checkComposerDependencies()
    {
        if (file_exists(base_path('composer.lock'))) {
            $output = shell_exec('composer audit --format=json');
            $audit = json_decode($output, true);

            if (!empty($audit['advisories'])) {
                foreach ($audit['advisories'] as $advisory) {
                    $this->issues[] = "Security Vulnerability: {$advisory['package']} - {$advisory['title']}";
                }
            }
        }
    }

    /**
     * Report findings
     */
    protected function reportFindings()
    {
        if (empty($this->issues)) {
            $this->info('No security issues found.');
            return;
        }

        $this->error('Security issues found:');
        foreach ($this->issues as $issue) {
            $this->warn("- {$issue}");
        }

        // Log issues
        Log::channel('security')->warning('Security audit findings', [
            'issues' => $this->issues,
            'timestamp' => now(),
        ]);

        // Send notification if requested
        if ($this->option('notify') && config('security.audit.notify_email')) {
            $this->sendNotification();
        }
    }

    /**
     * Send notification email
     */
    protected function sendNotification()
    {
        $email = config('security.audit.notify_email');
        
        if ($email) {
            Mail::raw("Security Audit Results:\n\n" . implode("\n", $this->issues), function ($message) use ($email) {
                $message->to($email)
                    ->subject('Security Audit Report - ' . config('app.name'));
            });
        }
    }
}
