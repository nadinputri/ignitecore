@extends('layouts.admin')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Create New Order</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="{{ route('admin.orders.index') }}" class="btn btn-outline-secondary">
                Back to Orders
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('admin.orders.store') }}" method="POST">
                        @csrf

                        <!-- User Selection -->
                        <div class="mb-4">
                            <label for="user_id" class="form-label">Select User</label>
                            <select class="form-select @error('user_id') is-invalid @enderror" 
                                    id="user_id" 
                                    name="user_id" 
                                    required>
                                <option value="">Select a user...</option>
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}" 
                                            {{ old('user_id') == $user->id ? 'selected' : '' }}
                                            data-wallet-balance="{{ $user->wallet->balance }}">
                                        {{ $user->name }} ({{ $user->email }})
                                    </option>
                                @endforeach
                            </select>
                            @error('user_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div id="walletInfo" class="form-text mt-2" style="display: none;">
                                User's Wallet Balance: <span class="text-primary" id="walletBalance">$0.00</span>
                            </div>
                        </div>

                        <!-- Service Selection -->
                        <div class="mb-4">
                            <label for="service_id" class="form-label">Select Service</label>
                            <select class="form-select @error('service_id') is-invalid @enderror" 
                                    id="service_id" 
                                    name="service_id" 
                                    required>
                                <option value="">Select a service...</option>
                                @foreach($services as $service)
                                    <option value="{{ $service->id }}" 
                                            {{ old('service_id') == $service->id ? 'selected' : '' }}
                                            data-base-price="{{ $service->price }}"
                                            data-description="{{ $service->description }}">
                                        {{ $service->name }} (Base Price: ${{ number_format($service->price, 2) }})
                                    </option>
                                @endforeach
                            </select>
                            @error('service_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div id="serviceInfo" class="form-text mt-2" style="display: none;">
                                <strong>Description:</strong>
                                <p id="serviceDescription"></p>
                            </div>
                        </div>

                        <!-- Initial Price -->
                        <div class="mb-4">
                            <label for="initial_price" class="form-label">Initial Price Offer</label>
                            <div class="input-group">
                                <span class="input-group-text">$</span>
                                <input type="number" 
                                       class="form-control @error('initial_price') is-invalid @enderror" 
                                       id="initial_price" 
                                       name="initial_price" 
                                       step="0.01" 
                                       min="0" 
                                       value="{{ old('initial_price') }}"
                                       required>
                            </div>
                            @error('initial_price')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div class="form-text">
                                This is the initial price you'll offer to the client.
                            </div>
                        </div>

                        <!-- Requirements -->
                        <div class="mb-4">
                            <label for="requirements" class="form-label">Project Requirements</label>
                            <textarea class="form-control @error('requirements') is-invalid @enderror" 
                                      id="requirements" 
                                      name="requirements" 
                                      rows="6" 
                                      required>{{ old('requirements') }}</textarea>
                            @error('requirements')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div class="form-text">
                                Provide detailed requirements for the project.
                            </div>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">
                                Create Order
                            </button>
                            <a href="{{ route('admin.orders.index') }}" class="btn btn-outline-secondary">
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Info Panel -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Order Creation Guide</h5>
                    <div class="alert alert-info">
                        <h6 class="alert-heading">Important Notes:</h6>
                        <ul class="mb-0">
                            <li>Select a user who will own this order</li>
                            <li>Choose the appropriate service</li>
                            <li>Set an initial price offer</li>
                            <li>Provide clear project requirements</li>
                        </ul>
                    </div>
                    <p class="text-muted">
                        Once created, the order will be set to "price_offered" status and the client will be notified.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const userSelect = document.getElementById('user_id');
    const serviceSelect = document.getElementById('service_id');
    const walletInfo = document.getElementById('walletInfo');
    const walletBalance = document.getElementById('walletBalance');
    const serviceInfo = document.getElementById('serviceInfo');
    const serviceDescription = document.getElementById('serviceDescription');
    const initialPriceInput = document.getElementById('initial_price');

    userSelect.addEventListener('change', function() {
        const option = this.options[this.selectedIndex];
        if (option.value) {
            const balance = parseFloat(option.dataset.walletBalance);
            walletBalance.textContent = `$${balance.toFixed(2)}`;
            walletInfo.style.display = 'block';
        } else {
            walletInfo.style.display = 'none';
        }
    });

    serviceSelect.addEventListener('change', function() {
        const option = this.options[this.selectedIndex];
        if (option.value) {
            const basePrice = parseFloat(option.dataset.basePrice);
            serviceDescription.textContent = option.dataset.description;
            serviceInfo.style.display = 'block';
            initialPriceInput.value = basePrice.toFixed(2);
        } else {
            serviceInfo.style.display = 'none';
            initialPriceInput.value = '';
        }
    });

    // Trigger change events if values are pre-selected
    if (userSelect.value) {
        userSelect.dispatchEvent(new Event('change'));
    }
    if (serviceSelect.value) {
        serviceSelect.dispatchEvent(new Event('change'));
    }
});
</script>
@endpush
@endsection
