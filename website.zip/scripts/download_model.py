#!/usr/bin/env python3
import argparse
import json
import logging
import os
import sys
from pathlib import Path
from huggingface_hub import snapshot_download, hf_hub_download
from transformers import AutoConfig
import torch

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def parse_args():
    parser = argparse.ArgumentParser(description='Download LLM model from Hugging Face')
    parser.add_argument('--model', type=str, required=True, help='Model name (llama2 or mistral)')
    parser.add_argument('--size', type=str, required=True, help='Model size (7B, 13B, 70B)')
    parser.add_argument('--variant', type=str, required=True, help='Model variant (chat, instruct, base)')
    parser.add_argument('--quantize', type=str, default='4-bit', help='Quantization level (4-bit, 8-bit, none)')
    parser.add_argument('--output', type=str, required=True, help='Output directory')
    parser.add_argument('--force', action='store_true', help='Force re-download if model exists')
    return parser.parse_args()

def get_repo_id(model: str, size: str, variant: str) -> str:
    """Get the Hugging Face repository ID for the model"""
    repo_map = {
        'llama2': {
            'base': f'meta-llama/Llama-2-{size}-hf',
            'chat': f'meta-llama/Llama-2-{size}-chat-hf',
            'instruct': f'meta-llama/Llama-2-{size}-instruct-hf'
        },
        'mistral': {
            'base': f'mistralai/Mistral-{size}B-v0.1',
            'instruct': f'mistralai/Mistral-{size}B-instruct-v0.1'
        }
    }

    try:
        return repo_map[model][variant]
    except KeyError:
        raise ValueError(f'Invalid model configuration: {model}/{size}/{variant}')

def check_requirements(size: str) -> bool:
    """Check if system meets the model's requirements"""
    ram_gb = os.sysconf('SC_PAGE_SIZE') * os.sysconf('SC_PHYS_PAGES') / (1024.**3)
    
    min_ram = {
        '7B': 16,
        '13B': 32,
        '70B': 64
    }

    if ram_gb < min_ram[size]:
        logger.warning(f'Insufficient RAM: {ram_gb:.1f}GB available, {min_ram[size]}GB recommended')
        return False

    if torch.cuda.is_available():
        vram_gb = torch.cuda.get_device_properties(0).total_memory / (1024.**3)
        min_vram = {'7B': 8, '13B': 16, '70B': 32}
        
        if vram_gb < min_vram[size]:
            logger.warning(f'Insufficient VRAM: {vram_gb:.1f}GB available, {min_vram[size]}GB recommended')
            return False
    else:
        logger.warning('No GPU detected, inference will be slow')

    return True

def setup_quantization(output_dir: Path, level: str):
    """Configure model quantization"""
    if level == 'none':
        return None

    config = {
        'load_in_4bit': level == '4-bit',
        'load_in_8bit': level == '8-bit',
        'bnb_4bit_compute_dtype': 'float16' if level == '4-bit' else None,
        'bnb_4bit_use_double_quant': True,
        'bnb_4bit_quant_type': 'nf4'
    }

    config_path = output_dir / 'quantization_config.json'
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)

    return config

def save_model_info(output_dir: Path, args, repo_id: str):
    """Save model information"""
    info = {
        'name': args.model,
        'size': args.size,
        'variant': args.variant,
        'repo_id': repo_id,
        'quantization': args.quantize,
        'num_parameters': f"{args.size}000000000",
        'context_window': 4096,
        'architecture': 'Transformer',
        'last_modified': None,
        'download_date': None,
        'license': 'Llama 2 Community License' if args.model == 'llama2' else 'Apache 2.0'
    }

    # Get model config
    try:
        config = AutoConfig.from_pretrained(repo_id)
        info.update({
            'vocab_size': config.vocab_size,
            'hidden_size': config.hidden_size,
            'num_attention_heads': config.num_attention_heads,
            'num_hidden_layers': config.num_hidden_layers,
            'context_window': config.max_position_embeddings
        })
    except Exception as e:
        logger.warning(f'Failed to load model config: {e}')

    info_path = output_dir / 'model_info.json'
    with open(info_path, 'w') as f:
        json.dump(info, f, indent=2)

def download_model(args):
    """Download model from Hugging Face"""
    output_dir = Path(args.output) / f"{args.model}-{args.size}-{args.variant}"
    output_dir.mkdir(parents=True, exist_ok=True)

    # Check if model already exists
    if not args.force and (output_dir / 'pytorch_model.bin').exists():
        logger.info(f'Model already exists at {output_dir}')
        return

    # Get repository ID
    repo_id = get_repo_id(args.model, args.size, args.variant)
    logger.info(f'Downloading {repo_id} to {output_dir}')

    # Check system requirements
    if not check_requirements(args.size):
        if not input('Continue anyway? [y/N] ').lower().startswith('y'):
            sys.exit(1)

    try:
        # Setup quantization
        quant_config = setup_quantization(output_dir, args.quantize)

        # Download model
        snapshot_download(
            repo_id=repo_id,
            local_dir=output_dir,
            local_dir_use_symlinks=False,
            resume_download=True,
            token=os.environ.get('HUGGINGFACE_TOKEN')
        )

        # Save model info
        save_model_info(output_dir, args, repo_id)

        logger.info(f'Successfully downloaded model to {output_dir}')

    except Exception as e:
        logger.error(f'Failed to download model: {e}')
        if output_dir.exists():
            import shutil
            shutil.rmtree(output_dir)
        sys.exit(1)

if __name__ == '__main__':
    args = parse_args()
    download_model(args)
