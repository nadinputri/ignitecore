<?php

namespace App\Policies;

use App\Models\User;
use Illuminate\Notifications\DatabaseNotification;
use Illuminate\Auth\Access\HandlesAuthorization;

class NotificationPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any notifications.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function viewAny(User $user)
    {
        return true; // Users can view their own notifications
    }

    /**
     * Determine whether the user can view the notification.
     *
     * @param  \App\Models\User  $user
     * @param  \Illuminate\Notifications\DatabaseNotification  $notification
     * @return bool
     */
    public function view(User $user, DatabaseNotification $notification)
    {
        return $notification->notifiable_id === $user->id;
    }

    /**
     * Determine whether the user can mark the notification as read.
     *
     * @param  \App\Models\User  $user
     * @param  \Illuminate\Notifications\DatabaseNotification  $notification
     * @return bool
     */
    public function markAsRead(User $user, DatabaseNotification $notification)
    {
        return $notification->notifiable_id === $user->id;
    }

    /**
     * Determine whether the user can mark all notifications as read.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function markAllAsRead(User $user)
    {
        return true; // Users can mark all their notifications as read
    }

    /**
     * Determine whether the user can delete the notification.
     *
     * @param  \App\Models\User  $user
     * @param  \Illuminate\Notifications\DatabaseNotification  $notification
     * @return bool
     */
    public function delete(User $user, DatabaseNotification $notification)
    {
        return $notification->notifiable_id === $user->id;
    }

    /**
     * Determine whether the user can delete all notifications.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function deleteAll(User $user)
    {
        return true; // Users can delete all their notifications
    }

    /**
     * Determine whether the user can update notification preferences.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function updatePreferences(User $user)
    {
        return true; // Users can update their notification preferences
    }

    /**
     * Determine whether the user can view notification preferences.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function viewPreferences(User $user)
    {
        return true; // Users can view their notification preferences
    }
}
