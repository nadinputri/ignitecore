<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Services\UserService;
use Symfony\Component\HttpFoundation\Response;

class CheckUserStatus
{
    /**
     * The user service instance.
     *
     * @var \App\Services\UserService
     */
    protected $userService;

    /**
     * Create a new middleware instance.
     *
     * @param  \App\Services\UserService  $userService
     * @return void
     */
    public function __construct(UserService $userService)
    {
        $this->userService = $userService;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle(Request $request, Closure $next, $guard = null)
    {
        $user = Auth::guard($guard)->user();

        if (!$user) {
            return redirect()->route('login');
        }

        // Skip status checks for certain routes
        if ($this->shouldSkipCheck($request)) {
            return $next($request);
        }

        // Check if user is banned
        if ($user->isBanned()) {
            Auth::logout();
            
            return redirect()->route('login')->with('error', 
                'Your account has been banned. Please contact support for assistance.'
            );
        }

        // Check if user is suspended
        if ($user->isSuspended()) {
            Auth::logout();
            
            return redirect()->route('login')->with('error', 
                'Your account is suspended until ' . $user->suspended_until->format('M d, Y H:i') . 
                '. Please contact support for assistance.'
            );
        }

        // Check if user status is active
        if ($user->status !== config('users.status.default')) {
            Auth::logout();
            
            return redirect()->route('login')->with('error', 
                'Your account is currently ' . $user->status . 
                '. Please contact support for assistance.'
            );
        }

        // Update user's last activity timestamp
        if (!$request->is('logout')) {
            $this->userService->updateLastActivity($user);
        }

        // Add user status to view data
        if ($request->isMethod('get')) {
            view()->share('userStatus', [
                'is_online' => $user->isOnline(),
                'last_active' => $user->getLastActivityForHumans(),
                'status' => $user->status,
                'is_suspended' => $user->isSuspended(),
                'suspended_until' => $user->suspended_until?->format('M d, Y H:i'),
            ]);
        }

        return $next($request);
    }

    /**
     * Determine if the status check should be skipped for the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return bool
     */
    protected function shouldSkipCheck(Request $request): bool
    {
        $skipPaths = [
            'support/*',           // Allow access to support routes
            'support-tickets/*',   // Allow access to support tickets
            'notifications/*',     // Allow access to notifications
            'logout',             // Always allow logout
            '_debugbar/*',        // Skip debug routes
            '_ignition/*',        // Skip error handling routes
            'sanctum/*',          // Skip API token routes
            'livewire/*',         // Skip Livewire routes
        ];

        foreach ($skipPaths as $path) {
            if ($request->is($path)) {
                return true;
            }
        }

        // Allow suspended users to access support-related routes
        if ($request->user()->isSuspended() && 
            config('users.support.allow_suspended_tickets', true)) {
            return $request->is('support*', 'support-tickets*');
        }

        return false;
    }
}
