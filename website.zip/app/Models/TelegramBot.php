<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Traits\LogsActivity;

class TelegramBot extends Model
{
    use HasFactory, LogsActivity;

    protected $fillable = [
        'user_id',
        'name',
        'bot_token',
        'status',
        'settings'
    ];

    protected $casts = [
        'settings' => 'array'
    ];

    protected static $logAttributes = [
        'name',
        'status',
        'settings'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function credits()
    {
        return $this->hasMany(TelegramBotCredit::class);
    }

    public function getTotalCreditsUsedAttribute()
    {
        return $this->credits()->sum('credits_used');
    }

    public function isActive()
    {
        return $this->status === 'active';
    }

    public function activate()
    {
        $this->update(['status' => 'active']);
    }

    public function deactivate()
    {
        $this->update(['status' => 'inactive']);
    }
}
