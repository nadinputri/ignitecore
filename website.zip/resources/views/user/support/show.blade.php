@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-0">Ticket #{{ $ticket->ticket_number }}</h5>
                        <p class="text-muted mb-0">{{ $ticket->subject }}</p>
                    </div>
                    <div>
                        <a href="{{ route('support-tickets.index') }}" class="btn btn-outline-secondary btn-sm">
                            Back to Tickets
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <!-- Ticket Status and Controls -->
                    <div class="row mb-4">
                        <div class="col-md-8">
                            <span class="badge bg-{{ 
                                $ticket->status === 'open' ? 'warning' : 
                                ($ticket->status === 'in_progress' ? 'info' : 
                                ($ticket->status === 'resolved' ? 'success' : 'secondary'))
                            }} me-2">
                                {{ ucfirst(str_replace('_', ' ', $ticket->status)) }}
                            </span>
                            <span class="badge bg-{{ 
                                $ticket->priority === 'high' ? 'danger' : 
                                ($ticket->priority === 'medium' ? 'warning' : 'info')
                            }}">
                                Priority: {{ ucfirst($ticket->priority) }}
                            </span>
                            <span class="ms-3 text-muted">
                                Created {{ $ticket->created_at->diffForHumans() }}
                            </span>
                        </div>
                        <div class="col-md-4 text-end">
                            @if(in_array($ticket->status, ['resolved', 'closed']))
                                <form action="{{ route('support-tickets.reopen', $ticket) }}" method="POST" class="d-inline">
                                    @csrf
                                    <button type="submit" class="btn btn-success btn-sm">Reopen Ticket</button>
                                </form>
                            @elseif(!in_array($ticket->status, ['resolved', 'closed']))
                                <form action="{{ route('support-tickets.close', $ticket) }}" method="POST" class="d-inline">
                                    @csrf
                                    <button type="submit" class="btn btn-danger btn-sm">Close Ticket</button>
                                </form>
                            @endif
                        </div>
                    </div>

                    <!-- Original Ticket -->
                    <div class="ticket-message mb-4">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <div class="avatar">
                                    {{ substr($ticket->user->name, 0, 1) }}
                                </div>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <div class="mb-1">
                                    <strong>{{ $ticket->user->name }}</strong>
                                    <small class="text-muted ms-2">{{ $ticket->created_at->format('M d, Y H:i') }}</small>
                                </div>
                                <div class="message-content">
                                    {!! nl2br(e($ticket->description)) !!}
                                </div>
                                @if($ticket->attachments->count() > 0)
                                    <div class="attachments mt-3">
                                        <h6>Attachments:</h6>
                                        <div class="list-group">
                                            @foreach($ticket->attachments as $attachment)
                                                <a href="{{ route('support-tickets.attachments.download', $attachment) }}" 
                                                   class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <i class="fas fa-{{ $attachment->getIconClass() }} me-2"></i>
                                                        {{ $attachment->filename }}
                                                    </div>
                                                    <span class="badge bg-primary rounded-pill">
                                                        {{ $attachment->getFormattedSize() }}
                                                    </span>
                                                </a>
                                            @endforeach
                                        </div>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>

                    <!-- Replies -->
                    @foreach($ticket->replies as $reply)
                        <div class="ticket-reply mb-4 {{ $reply->is_admin_reply ? 'admin-reply' : '' }}">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <div class="avatar {{ $reply->is_admin_reply ? 'admin-avatar' : '' }}">
                                        {{ substr($reply->user->name, 0, 1) }}
                                    </div>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <div class="mb-1">
                                        <strong>{{ $reply->user->name }}</strong>
                                        @if($reply->is_admin_reply)
                                            <span class="badge bg-info ms-1">Staff</span>
                                        @endif
                                        <small class="text-muted ms-2">{{ $reply->created_at->format('M d, Y H:i') }}</small>
                                    </div>
                                    <div class="message-content">
                                        {!! nl2br(e($reply->message)) !!}
                                    </div>
                                    @if($reply->attachments->count() > 0)
                                        <div class="attachments mt-3">
                                            <h6>Attachments:</h6>
                                            <div class="list-group">
                                                @foreach($reply->attachments as $attachment)
                                                    <a href="{{ route('support-tickets.attachments.download', $attachment) }}" 
                                                       class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                                        <div>
                                                            <i class="fas fa-{{ $attachment->getIconClass() }} me-2"></i>
                                                            {{ $attachment->filename }}
                                                        </div>
                                                        <span class="badge bg-primary rounded-pill">
                                                            {{ $attachment->getFormattedSize() }}
                                                        </span>
                                                    </a>
                                                @endforeach
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    @endforeach

                    <!-- Reply Form -->
                    @if(!in_array($ticket->status, ['resolved', 'closed']))
                        <div class="reply-form mt-4">
                            <h5>Add Reply</h5>
                            <form action="{{ route('support-tickets.reply', $ticket) }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="mb-3">
                                    <textarea class="form-control @error('message') is-invalid @enderror" 
                                              name="message" 
                                              rows="4" 
                                              required>{{ old('message') }}</textarea>
                                    @error('message')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="attachments" class="form-label">Attachments (Optional)</label>
                                    <input type="file" 
                                           class="form-control @error('attachments.*') is-invalid @enderror" 
                                           id="attachments" 
                                           name="attachments[]" 
                                           multiple>
                                    @error('attachments.*')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                    <div class="form-text">
                                        You can upload multiple files (max 10MB each).
                                    </div>
                                </div>

                                <div class="mb-3" id="attachment-preview">
                                    <!-- Preview selected files here via JavaScript -->
                                </div>

                                <button type="submit" class="btn btn-primary">
                                    Send Reply
                                </button>
                            </form>
                        </div>
                    @else
                        <div class="alert alert-info">
                            This ticket is {{ $ticket->status }}. You cannot add new replies.
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@push('styles')
<style>
.avatar {
    width: 40px;
    height: 40px;
    background-color: #007bff;
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

.admin-avatar {
    background-color: #28a745;
}

.admin-reply {
    background-color: #f8f9fa;
    padding: 1rem;
    border-radius: 0.25rem;
}

.message-content {
    white-space: pre-wrap;
}
</style>
@endpush

@push('scripts')
<script>
document.getElementById('attachments')?.addEventListener('change', function(e) {
    const preview = document.getElementById('attachment-preview');
    preview.innerHTML = '';

    if (this.files.length > 0) {
        const list = document.createElement('div');
        list.className = 'list-group mt-2';

        Array.from(this.files).forEach(file => {
            const item = document.createElement('div');
            item.className = 'list-group-item d-flex justify-content-between align-items-center';
            
            const name = document.createElement('span');
            name.textContent = file.name;
            
            const size = document.createElement('span');
            size.className = 'badge bg-primary rounded-pill';
            size.textContent = Math.round(file.size / 1024) + ' KB';
            
            item.appendChild(name);
            item.appendChild(size);
            list.appendChild(item);
        });

        preview.appendChild(list);
    }
});
</script>
@endpush
@endsection
