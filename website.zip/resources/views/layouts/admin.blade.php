<!DOCTYPE html>
<html lang="en" class="dark-mode">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="IgniteHub Admin Dashboard" />
    <meta name="author" content="IgniteHub" />
    <title>{{ config('app.name') }} - Admin</title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
    
    <!-- Styles -->
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    @vite(['resources/css/theme.css'])
    @yield('styles')
    
    <style>
        /* Admin Theme Overrides */
        body {
            background-color: var(--background-dark);
            font-family: 'Space Mono', monospace;
        }

        /* Retro Scanlines Effect */
        body::after {
            content: '';
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: repeating-linear-gradient(
                0deg,
                rgba(0, 0, 0, 0.1) 0px,
                rgba(0, 0, 0, 0.1) 1px,
                transparent 1px,
                transparent 2px
            );
            pointer-events: none;
            z-index: 9999;
            opacity: 0.5;
        }

        /* Glowing Elements */
        .nav-link:hover .sb-nav-link-icon i,
        .nav-link.active .sb-nav-link-icon i {
            animation: glow 2s ease-in-out infinite alternate;
        }

        @keyframes glow {
            from {
                text-shadow: 0 0 5px var(--primary),
                           0 0 10px var(--primary),
                           0 0 15px var(--primary);
            }
            to {
                text-shadow: 0 0 10px var(--primary),
                           0 0 20px var(--primary),
                           0 0 30px var(--primary);
            }
        }

        /* Smooth Transitions */
        .nav-link,
        .dropdown-item,
        .btn,
        .alert {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* Card Styling */
        .card {
            background-color: var(--background-light);
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .card-header {
            background-color: rgba(0, 0, 0, 0.2);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* Button Styling */
        .btn {
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
            padding: 0.5rem 1.5rem;
        }

        .btn-primary {
            background: linear-gradient(45deg, var(--primary), var(--secondary));
            border: none;
            position: relative;
            overflow: hidden;
        }

        .btn-primary::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                rgba(255, 255, 255, 0.2),
                transparent
            );
            transform: rotate(45deg);
            transition: 0.5s;
            opacity: 0;
        }

        .btn-primary:hover::after {
            opacity: 1;
        }

        /* Table Styling */
        .table {
            border-collapse: separate;
            border-spacing: 0;
        }

        .table th {
            background-color: var(--background-light);
            border-bottom: 2px solid var(--primary);
            color: var(--primary);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .table td {
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* Form Controls */
        .form-control {
            background-color: var(--background-light);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: var(--text-primary);
        }

        .form-control:focus {
            background-color: var(--background-light);
            border-color: var(--primary);
            box-shadow: 0 0 0 0.2rem rgba(0, 255, 157, 0.25);
        }
        
        .sb-sidenav {
            background-color: var(--background-light);
            border-right: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sb-sidenav-dark {
            background-color: var(--background-light);
            color: var(--text-secondary);
        }
        
        .sb-sidenav-menu .nav-link {
            color: var(--text-secondary);
            transition: all var(--transition-speed) var(--transition-ease);
        }
        
        .sb-sidenav-menu .nav-link:hover {
            color: var(--primary);
            text-shadow: var(--accent-glow);
        }
        
        .sb-sidenav-menu .nav-link.active {
            background-color: rgba(0, 255, 157, 0.1);
            color: var(--primary);
            border-right: 2px solid var(--primary);
        }
        
        .sb-sidenav-menu-heading {
            color: var(--primary);
            text-transform: uppercase;
            letter-spacing: 1px;
            font-size: 0.8rem;
            padding: 1.5rem 1rem 0.5rem;
        }
        
        .sb-nav-link-icon {
            color: var(--text-secondary);
        }
        
        .nav-link.active .sb-nav-link-icon {
            color: var(--primary);
        }
        
        .terminal-nav-icon {
            color: var(--primary);
        }
        
        .sb-sidenav-footer {
            background-color: var(--background-light);
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding: 1rem;
        }
        
        .sb-topnav {
            background-color: var(--background-light);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .navbar-brand {
            color: var(--primary) !important;
            font-weight: 700;
            letter-spacing: 1px;
        }
        
        #layoutSidenav_content {
            background-color: var(--background-dark);
            color: var(--text-primary);
        }
        
        footer {
            background-color: var(--background-light) !important;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        footer .text-muted {
            color: var(--text-secondary) !important;
        }
        
        footer a {
            color: var(--primary);
            text-decoration: none;
            transition: all var(--transition-speed) var(--transition-ease);
        }
        
        footer a:hover {
            color: var(--primary);
            text-shadow: var(--accent-glow);
        }
        
        .alert {
            border: none;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: rgba(0, 255, 157, 0.1);
            color: var(--success);
        }
        
        .alert-danger {
            background-color: rgba(255, 68, 68, 0.1);
            color: var(--danger);
        }
        
        .dropdown-menu {
            background-color: var(--background-light);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .dropdown-item {
            color: var(--text-secondary);
        }
        
        .dropdown-item:hover {
            background-color: rgba(0, 255, 157, 0.1);
            color: var(--primary);
        }
        
        .dropdown-divider {
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
    </style>
</head>
<body class="sb-nav-fixed" onload="initTheme()">
    <nav class="sb-topnav navbar navbar-expand">
        <a class="navbar-brand ps-3" href="{{ route('admin.dashboard') }}">
            <i class="fas fa-cube me-2"></i>{{ config('app.name') }}
        </a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!">
            <i class="fas fa-bars"></i>
        </button>
        <div class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0"></div>
        <ul class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-user-shield fa-fw"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li>
                        <a class="dropdown-item" href="{{ route('admin.settings.index') }}">
                            <i class="fas fa-cogs me-2"></i>Settings
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="{{ route('activity-logs.index') }}">
                            <i class="fas fa-history me-2"></i>Activity Log
                        </a>
                    </li>
                    <li><hr class="dropdown-divider" /></li>
                    <li>
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <button type="submit" class="dropdown-item text-danger">
                                <i class="fas fa-sign-out-alt me-2"></i>Logout
                            </button>
                        </form>
                    </li>
                </ul>
            </li>
        </ul>
    </nav>
    
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">
                            <i class="fas fa-rocket me-2"></i>Core
                        </div>
                        <a class="nav-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}" href="{{ route('admin.dashboard') }}">
                            <div class="sb-nav-link-icon">
                                <i class="fas fa-tachometer-alt"></i>
                            </div>
                            <span>Dashboard</span>
                            <div class="ms-auto">
                                <i class="fas fa-chevron-right opacity-50"></i>
                            </div>
                        </a>

                        <div class="sb-sidenav-menu-heading">
                            <i class="fas fa-tasks me-2"></i>Management
                        </div>
                        <a class="nav-link {{ request()->routeIs('admin.services.*') ? 'active' : '' }}" href="{{ route('admin.services.index') }}">
                            <div class="sb-nav-link-icon">
                                <i class="fas fa-cube"></i>
                            </div>
                            <span>Services</span>
                            <div class="ms-auto">
                                <i class="fas fa-chevron-right opacity-50"></i>
                            </div>
                        </a>
                        <a class="nav-link {{ request()->routeIs('admin.orders.*') ? 'active' : '' }}" href="{{ route('admin.orders.index') }}">
                            <div class="sb-nav-link-icon">
                                <i class="fas fa-shopping-cart"></i>
                            </div>
                            <span>Orders</span>
                            <div class="ms-auto">
                                <i class="fas fa-chevron-right opacity-50"></i>
                            </div>
                        </a>

                        <div class="sb-sidenav-menu-heading">
                            <i class="fas fa-cog me-2"></i>System
                        </div>
                        <a class="nav-link {{ request()->routeIs('admin.settings.*') ? 'active' : '' }}" href="{{ route('admin.settings.index') }}">
                            <div class="sb-nav-link-icon">
                                <i class="fas fa-cogs"></i>
                            </div>
                            <span>Settings</span>
                            <div class="ms-auto">
                                <i class="fas fa-chevron-right opacity-50"></i>
                            </div>
                        </a>
                        <a class="nav-link {{ request()->routeIs('admin.activity-logs.*') ? 'active' : '' }}" href="{{ route('admin.activity-logs.index') }}">
                            <div class="sb-nav-link-icon">
                                <i class="fas fa-history"></i>
                            </div>
                            <span>Activity Logs</span>
                            <div class="ms-auto">
                                <i class="fas fa-chevron-right opacity-50"></i>
                            </div>
                        </a>
                        <a class="nav-link {{ request()->routeIs('admin.terminal.*') ? 'active' : '' }}" href="{{ route('admin.terminal.index') }}">
                            <div class="sb-nav-link-icon">
                                <i class="fas fa-terminal terminal-nav-icon"></i>
                            </div>
                            <span>Terminal</span>
                            <div class="ms-auto">
                                <i class="fas fa-chevron-right opacity-50"></i>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="d-flex align-items-center p-3">
                        <div class="sb-nav-link-icon me-3">
                            <i class="fas fa-user-circle fa-2x text-primary"></i>
                        </div>
                        <div>
                            <div class="small text-primary">Logged in as:</div>
                            <div class="text-secondary">{{ auth()->user()->name }}</div>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show m-4 border-glow" role="alert">
                        <i class="fas fa-check-circle me-2"></i>
                        {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                @if(session('error'))
                    <div class="alert alert-danger alert-dismissible fade show m-4 border-glow" role="alert">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        {{ session('error') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                @endif

                @yield('content')
            </main>
            <footer class="py-4 mt-auto">
                <div class="container-fluid px-4">
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-secondary">
                            <i class="fas fa-code me-2"></i>Copyright &copy; {{ config('app.name') }} {{ date('Y') }}
                        </div>
                        <div>
                            <a href="#" class="me-3"><i class="fas fa-shield-alt me-1"></i>Privacy Policy</a>
                            <a href="#"><i class="fas fa-file-contract me-1"></i>Terms &amp; Conditions</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest"></script>
    <script>
        // Toggle sidebar
        window.addEventListener('DOMContentLoaded', event => {
            const sidebarToggle = document.body.querySelector('#sidebarToggle');
            if (sidebarToggle) {
                sidebarToggle.addEventListener('click', event => {
                    event.preventDefault();
                    document.body.classList.toggle('sb-sidenav-toggled');
                    localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
                });
            }
        });
    </script>
    @yield('scripts')
</body>
</html>
