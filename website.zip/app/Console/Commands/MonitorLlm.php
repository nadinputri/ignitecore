<?php

namespace App\Console\Commands;

use App\Models\LlmSetting;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Process;
use Illuminate\Support\Facades\Storage;

class MonitorLlm extends Command
{
    protected $signature = 'llm:monitor
        {--watch : Continuously monitor the LLM}
        {--interval=300 : Monitoring interval in seconds}';

    protected $description = 'Monitor LLM system resources and performance';

    protected $settings;

    public function __construct()
    {
        parent::__construct();
        $this->settings = LlmSetting::getConfig();
    }

    public function handle()
    {
        if (!$this->settings->monitoring_enabled) {
            $this->warn('LLM monitoring is disabled in settings');
            return 1;
        }

        try {
            $watch = $this->option('watch');
            $interval = $this->option('interval');

            do {
                $this->monitorSystem();
                
                if ($watch) {
                    $this->info("\nWaiting {$interval} seconds before next check...");
                    sleep($interval);
                }
            } while ($watch);

            return 0;

        } catch (\Exception $e) {
            Log::error('LLM monitoring failed: ' . $e->getMessage());
            $this->error('Monitoring failed: ' . $e->getMessage());
            return 1;
        }
    }

    protected function monitorSystem()
    {
        $this->info('Checking LLM system status...');

        try {
            // Check if model is installed
            if (!$this->settings->model_path || !file_exists($this->settings->model_path)) {
                $this->warn('No model installed');
                return;
            }

            // Run monitoring script
            $pythonPath = config('llm.python.path');
            $scriptsPath = config('llm.python.scripts_dir');

            $process = Process::run(implode(' ', [
                $pythonPath,
                "{$scriptsPath}/monitor_llm.py",
                "--model-dir={$this->settings->model_path}",
                "--log-dir=" . storage_path('logs/llm')
            ]));

            if (!$process->successful()) {
                throw new \Exception('Failed to get system metrics: ' . $process->errorOutput());
            }

            $data = json_decode($process->output(), true);
            $metrics = $data['metrics'];
            $analysis = $data['analysis'];

            // Update settings with latest metrics
            $this->settings->update([
                'last_health_check' => now(),
                'health_status' => $this->determineHealthStatus($metrics),
                'system_metrics' => $metrics
            ]);

            // Cache metrics for real-time monitoring
            Cache::put('llm.metrics', $metrics, now()->addMinutes(5));

            // Display current status
            $this->displayStatus($metrics, $analysis);

            // Log warnings if any
            if (!empty($analysis['warnings'])) {
                foreach ($analysis['warnings'] as $warning) {
                    Log::warning("LLM Warning: {$warning}");
                }
            }

            // Send notifications if needed
            $this->handleNotifications($metrics, $analysis);

        } catch (\Exception $e) {
            throw $e;
        }
    }

    protected function determineHealthStatus($metrics)
    {
        if ($metrics['cpu']['percent'] > 90 || 
            $metrics['memory']['percent'] > 90 ||
            $metrics['disk']['percent'] > 90) {
            return 'critical';
        }

        if ($metrics['cpu']['percent'] > 75 || 
            $metrics['memory']['percent'] > 75 ||
            $metrics['disk']['percent'] > 75) {
            return 'warning';
        }

        if (isset($metrics['gpu'])) {
            foreach ($metrics['gpu'] as $gpu) {
                if ($gpu['utilization'] > 90) {
                    return 'warning';
                }
            }
        }

        return 'healthy';
    }

    protected function displayStatus($metrics, $analysis)
    {
        // System Metrics
        $this->info("\nSystem Metrics:");
        $this->table(['Metric', 'Value'], [
            ['CPU Usage', $metrics['cpu']['percent'] . '%'],
            ['Memory Usage', $metrics['memory']['percent'] . '%'],
            ['Disk Usage', $metrics['disk']['percent'] . '%'],
            ['Network TX', format_bytes($metrics['network']['bytes_sent'])],
            ['Network RX', format_bytes($metrics['network']['bytes_recv'])]
        ]);

        // GPU Metrics
        if (isset($metrics['gpu'])) {
            $this->info("\nGPU Metrics:");
            $gpuData = [];
            foreach ($metrics['gpu'] as $gpu) {
                $gpuData[] = [
                    $gpu['id'],
                    $gpu['name'],
                    format_bytes($gpu['memory_used']),
                    format_bytes($gpu['memory_total']),
                    $gpu['utilization'] ? $gpu['utilization'] . '%' : 'N/A'
                ];
            }
            $this->table(['ID', 'Name', 'Memory Used', 'Memory Total', 'Utilization'], $gpuData);
        }

        // Health Checks
        $this->info("\nHealth Checks:");
        $healthData = [];
        foreach ($analysis['health_checks'] as $check) {
            $healthData[] = [
                $check['component'],
                $check['status'],
                $check['status'] === 'healthy' ? '✓' : '⚠'
            ];
        }
        $this->table(['Component', 'Status', 'Indicator'], $healthData);

        // Warnings
        if (!empty($analysis['warnings'])) {
            $this->warn("\nWarnings:");
            foreach ($analysis['warnings'] as $warning) {
                $this->warn("- {$warning}");
            }
        }

        // Recommendations
        if (!empty($analysis['recommendations'])) {
            $this->info("\nRecommendations:");
            foreach ($analysis['recommendations'] as $recommendation) {
                $this->line("- {$recommendation}");
            }
        }
    }

    protected function handleNotifications($metrics, $analysis)
    {
        $status = $this->determineHealthStatus($metrics);

        // Critical alerts
        if ($status === 'critical') {
            // Log critical status
            Log::critical('LLM System Critical: ' . implode(', ', $analysis['warnings']));

            // Cache the alert to prevent spam
            $alertKey = 'llm.critical_alert';
            if (!Cache::has($alertKey)) {
                // TODO: Send notification to admin
                // You could implement email/Slack notifications here

                // Cache the alert for 1 hour
                Cache::put($alertKey, true, now()->addHour());
            }
        }

        // Warning alerts
        if ($status === 'warning') {
            $alertKey = 'llm.warning_alert';
            if (!Cache::has($alertKey)) {
                Log::warning('LLM System Warning: ' . implode(', ', $analysis['warnings']));
                // Cache the alert for 3 hours
                Cache::put($alertKey, true, now()->addHours(3));
            }
        }

        // Performance degradation
        if (isset($metrics['gpu']) && empty($metrics['gpu'])) {
            Log::warning('LLM running without GPU acceleration');
        }

        // Resource thresholds
        if ($metrics['memory']['percent'] > 85) {
            Log::warning('LLM high memory usage: ' . $metrics['memory']['percent'] . '%');
        }

        if ($metrics['disk']['percent'] > 85) {
            Log::warning('LLM high disk usage: ' . $metrics['disk']['percent'] . '%');
        }
    }
}
