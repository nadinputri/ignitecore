@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Create New Order</h5>
                    <a href="{{ route('services.show', $service) }}" class="btn btn-outline-secondary btn-sm">
                        Back to Service
                    </a>
                </div>

                <div class="card-body">
                    <!-- Service Details -->
                    <div class="mb-4">
                        <div class="card bg-light">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-3">
                                        @if($service->image)
                                            <img src="{{ asset($service->image) }}" 
                                                 class="img-fluid rounded" 
                                                 alt="{{ $service->name }}">
                                        @endif
                                    </div>
                                    <div class="col-md-9">
                                        <h5>{{ $service->name }}</h5>
                                        <p>{{ $service->description }}</p>
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span class="text-muted">
                                                Base Price: ${{ number_format($service->price, 2) }}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Order Form -->
                    <form action="{{ route('orders.store', $service) }}" method="POST">
                        @csrf

                        <div class="mb-4">
                            <label for="requirements" class="form-label">Project Requirements</label>
                            <textarea class="form-control @error('requirements') is-invalid @enderror" 
                                      id="requirements" 
                                      name="requirements" 
                                      rows="6" 
                                      required>{{ old('requirements') }}</textarea>
                            @error('requirements')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div class="form-text">
                                Please provide detailed requirements for your project. The more specific you are, 
                                the better we can understand your needs and provide an accurate quote.
                            </div>
                        </div>

                        <div class="alert alert-info">
                            <h6 class="alert-heading">How it works:</h6>
                            <ol class="mb-0">
                                <li>Submit your order with detailed requirements</li>
                                <li>We'll review your requirements and provide a price quote</li>
                                <li>You can accept the quote or make a counter offer</li>
                                <li>Once the price is agreed, you can pay from your wallet</li>
                                <li>We'll start working on your order right away</li>
                            </ol>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">
                                Submit Order
                            </button>
                            <a href="{{ route('services.show', $service) }}" 
                               class="btn btn-outline-secondary">
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Wallet Balance Card -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Wallet Balance</h5>
                    <h3 class="text-primary">${{ number_format(Auth::user()->wallet->balance, 2) }}</h3>
                    <p class="card-text text-muted">
                        You can top up your wallet anytime to ensure smooth order processing.
                    </p>
                    <a href="{{ route('wallet.index') }}" class="btn btn-primary">
                        Manage Wallet
                    </a>
                </div>
            </div>

            <!-- Recent Orders -->
            <div class="card mt-4">
                <div class="card-body">
                    <h5 class="card-title">Recent Orders</h5>
                    @if(Auth::user()->orders()->count() > 0)
                        <div class="list-group list-group-flush">
                            @foreach(Auth::user()->orders()->latest()->take(3)->get() as $recentOrder)
                                <a href="{{ route('orders.show', $recentOrder) }}" 
                                   class="list-group-item list-group-item-action">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1">{{ $recentOrder->service->name }}</h6>
                                        <small>{{ $recentOrder->created_at->diffForHumans() }}</small>
                                    </div>
                                    <p class="mb-1">
                                        <span class="badge bg-{{ 
                                            $recentOrder->status === 'pending' ? 'warning' : 
                                            ($recentOrder->status === 'in_progress' ? 'info' : 
                                            ($recentOrder->status === 'completed' ? 'success' : 'secondary'))
                                        }}">
                                            {{ ucfirst(str_replace('_', ' ', $recentOrder->status)) }}
                                        </span>
                                    </p>
                                </a>
                            @endforeach
                        </div>
                        <div class="mt-3">
                            <a href="{{ route('orders.index') }}" class="btn btn-outline-primary btn-sm">
                                View All Orders
                            </a>
                        </div>
                    @else
                        <p class="text-muted mb-0">No orders yet.</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
