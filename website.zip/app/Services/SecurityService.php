<?php

namespace App\Services;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;
use App\Models\ActivityLog;
use App\Models\User;

class SecurityService
{
    /**
     * Log a security event
     *
     * @param string $event The security event type
     * @param string $description Description of the event
     * @param array $properties Additional properties to log
     * @return void
     */
    public function logSecurityEvent($event, $description, array $properties = [])
    {
        $userId = Auth::id();
        $ipAddress = Request::ip();
        $userAgent = Request::header('User-Agent');
        
        // Add security-specific data
        $properties['ip_address'] = $ipAddress;
        $properties['user_agent'] = $userAgent;
        $properties['timestamp'] = now()->toIso8601String();
        
        // Create activity log entry
        ActivityLog::create([
            'user_id' => $userId,
            'event' => $event,
            'description' => $description,
            'properties' => $properties,
            'ip_address' => $ipAddress,
            'user_agent' => $userAgent,
        ]);
        
        // Also log to the application log for critical events
        if (in_array($event, ['login_failed', 'password_reset', 'suspicious_activity', 'admin_login'])) {
            Log::channel('security')->info("Security event: {$event}", [
                'user_id' => $userId,
                'description' => $description,
                'ip' => $ipAddress,
            ]);
        }
    }
    
    /**
     * Check if an IP address is suspicious
     *
     * @param string $ipAddress The IP address to check
     * @return bool
     */
    public function isSuspiciousIp($ipAddress)
    {
        // Check if IP has had multiple failed login attempts
        $failedAttempts = ActivityLog::where('event', 'login_failed')
            ->where('ip_address', $ipAddress)
            ->where('created_at', '>', now()->subHours(24))
            ->count();
            
        if ($failedAttempts >= 10) {
            return true;
        }
        
        // Check if IP has accessed multiple user accounts
        $uniqueUsers = ActivityLog::where('ip_address', $ipAddress)
            ->where('created_at', '>', now()->subHours(24))
            ->distinct('user_id')
            ->count('user_id');
            
        if ($uniqueUsers >= 5) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Check for suspicious activity on a user account
     *
     * @param User $user The user to check
     * @return bool
     */
    public function detectSuspiciousActivity(User $user)
    {
        // Get user's common IP addresses
        $commonIps = ActivityLog::where('user_id', $user->id)
            ->where('created_at', '>', now()->subDays(30))
            ->groupBy('ip_address')
            ->selectRaw('ip_address, count(*) as count')
            ->orderByDesc('count')
            ->limit(5)
            ->pluck('ip_address')
            ->toArray();
            
        // Check if current IP is not in common IPs
        $currentIp = Request::ip();
        if (!in_array($currentIp, $commonIps) && !empty($commonIps)) {
            // Log the suspicious login from new location
            $this->logSecurityEvent(
                'suspicious_login',
                'Login from unusual location',
                ['ip_address' => $currentIp, 'common_ips' => $commonIps]
            );
            
            return true;
        }
        
        return false;
    }
    
    /**
     * Sanitize user input to prevent XSS
     *
     * @param string $input The input to sanitize
     * @return string
     */
    public function sanitizeInput($input)
    {
        if (!is_string($input)) {
            return $input;
        }
        
        // Remove potentially malicious content
        $sanitized = htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        // Remove script tags and their content
        $sanitized = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $sanitized);
        
        // Remove on* attributes
        $sanitized = preg_replace('/\bon\w+\s*=\s*"[^"]*"/i', '', $sanitized);
        $sanitized = preg_replace("/\bon\w+\s*=\s*'[^']*'/i", '', $sanitized);
        $sanitized = preg_replace('/\bon\w+\s*=[^\s>]*/i', '', $sanitized);
        
        return $sanitized;
    }
    
    /**
     * Generate a secure random token
     *
     * @param int $length Length of the token
     * @return string
     */
    public function generateSecureToken($length = 32)
    {
        return bin2hex(random_bytes($length / 2));
    }
}
