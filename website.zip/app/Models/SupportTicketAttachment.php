<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Traits\LogsActivity;
use Illuminate\Support\Facades\Storage;

class SupportTicketAttachment extends Model
{
    use HasFactory, LogsActivity;

    protected $fillable = [
        'ticket_id',
        'reply_id',
        'filename',
        'path',
        'mime_type',
        'size'
    ];

    protected static $logAttributes = [
        'filename',
        'path',
        'mime_type',
        'size'
    ];

    protected static function booted()
    {
        // Delete the file from storage when the attachment record is deleted
        static::deleting(function ($attachment) {
            Storage::delete($attachment->path);
        });
    }

    public function ticket()
    {
        return $this->belongsTo(SupportTicket::class);
    }

    public function reply()
    {
        return $this->belongsTo(SupportTicketReply::class);
    }

    public function getFormattedSizeAttribute()
    {
        $units = ['B', 'KB', 'MB', 'GB'];
        $size = $this->size;
        $unit = 0;

        while ($size >= 1024 && $unit < count($units) - 1) {
            $size /= 1024;
            $unit++;
        }

        return round($size, 2) . ' ' . $units[$unit];
    }

    public function getDownloadUrlAttribute()
    {
        return route('support-tickets.attachments.download', $this->id);
    }

    public function isImage()
    {
        return str_starts_with($this->mime_type, 'image/');
    }

    public function isPdf()
    {
        return $this->mime_type === 'application/pdf';
    }

    public function getIconClass()
    {
        if ($this->isImage()) {
            return 'fa-image';
        } elseif ($this->isPdf()) {
            return 'fa-file-pdf';
        } else {
            return 'fa-file';
        }
    }
}
