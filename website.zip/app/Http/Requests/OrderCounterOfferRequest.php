<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Order;

class OrderCounterOfferRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        $order = $this->route('order');
        return $this->user()->can('counterOffer', $order);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        $order = $this->route('order');

        return [
            'counter_price' => [
                'required',
                'numeric',
                'min:0',
                'max:' . ($order->initial_price * 2), // Prevent unreasonable counter offers
                function ($attribute, $value, $fail) use ($order) {
                    if ($value >= $order->initial_price) {
                        $fail('Counter offer must be lower than the initial price.');
                    }
                },
            ],
        ];
    }

    /**
     * Get custom messages for validator errors.
     *
     * @return array
     */
    public function messages()
    {
        return [
            'counter_price.required' => 'Please provide your counter offer price.',
            'counter_price.numeric' => 'The counter offer must be a valid number.',
            'counter_price.min' => 'The counter offer cannot be negative.',
            'counter_price.max' => 'The counter offer is unreasonably high.',
        ];
    }

    /**
     * Get custom attributes for validator errors.
     *
     * @return array
     */
    public function attributes()
    {
        return [
            'counter_price' => 'counter offer',
        ];
    }

    /**
     * Prepare the data for validation.
     *
     * @return void
     */
    protected function prepareForValidation()
    {
        if ($this->has('counter_price')) {
            $this->merge([
                'counter_price' => filter_var(
                    $this->counter_price,
                    FILTER_SANITIZE_NUMBER_FLOAT,
                    FILTER_FLAG_ALLOW_FRACTION
                ),
            ]);
        }
    }
}
