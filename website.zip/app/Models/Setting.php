<?php

namespace App\Models;

use App\Traits\LogsActivity;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class Setting extends Model
{
    use HasFactory, LogsActivity;

    /**
     * Cache key for all settings
     */
    const CACHE_KEY = 'app_settings';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'key',
        'value',
        'type',
        'group',
        'label',
        'description',
        'is_public',
        'is_system',
        'validation_rules',
        'sort_order',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'is_public' => 'boolean',
        'is_system' => 'boolean',
        'validation_rules' => 'json',
        'sort_order' => 'integer',
    ];

    /**
     * Boot the model.
     */
    protected static function boot()
    {
        parent::boot();

        // Clear cache when settings are modified
        static::saved(function () {
            static::clearCache();
        });

        static::deleted(function () {
            static::clearCache();
        });
    }

    /**
     * Get a setting value by key.
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public static function get($key, $default = null)
    {
        $settings = static::getAllSettings();
        $setting = $settings->firstWhere('key', $key);

        if (!$setting) {
            return $default;
        }

        return static::castValue($setting->value, $setting->type);
    }

    /**
     * Set a setting value.
     *
     * @param string $key
     * @param mixed $value
     * @return bool
     */
    public static function set($key, $value)
    {
        $setting = static::where('key', $key)->first();

        if (!$setting) {
            return false;
        }

        $setting->value = $value;
        return $setting->save();
    }

    /**
     * Get all settings, grouped by their group.
     *
     * @param bool $publicOnly
     * @return \Illuminate\Support\Collection
     */
    public static function getAllGrouped($publicOnly = false)
    {
        $settings = static::getAllSettings();

        if ($publicOnly) {
            $settings = $settings->where('is_public', true);
        }

        return $settings->groupBy('group');
    }

    /**
     * Get all settings from cache or database.
     *
     * @return \Illuminate\Support\Collection
     */
    protected static function getAllSettings()
    {
        return Cache::rememberForever(static::CACHE_KEY, function () {
            return static::orderBy('group')
                ->orderBy('sort_order')
                ->orderBy('label')
                ->get();
        });
    }

    /**
     * Clear the settings cache.
     *
     * @return void
     */
    public static function clearCache()
    {
        Cache::forget(static::CACHE_KEY);
    }

    /**
     * Cast a value to its proper type.
     *
     * @param mixed $value
     * @param string $type
     * @return mixed
     */
    protected static function castValue($value, $type)
    {
        switch ($type) {
            case 'boolean':
                return filter_var($value, FILTER_VALIDATE_BOOLEAN);
            case 'integer':
                return (int) $value;
            case 'float':
                return (float) $value;
            case 'json':
                return json_decode($value, true);
            case 'array':
                return is_array($value) ? $value : explode(',', $value);
            default:
                return $value;
        }
    }

    /**
     * Get validation rules for the setting.
     *
     * @return array
     */
    public function getValidationRules()
    {
        return $this->validation_rules ?? [];
    }

    /**
     * Check if the setting can be deleted.
     *
     * @return bool
     */
    public function canBeDeleted()
    {
        return !$this->is_system;
    }

    /**
     * Get settings by group.
     *
     * @param string $group
     * @param bool $publicOnly
     * @return \Illuminate\Support\Collection
     */
    public static function getByGroup($group, $publicOnly = false)
    {
        $query = static::where('group', $group)
            ->orderBy('sort_order')
            ->orderBy('label');

        if ($publicOnly) {
            $query->where('is_public', true);
        }

        return $query->get();
    }

    /**
     * Get the activity description for the setting.
     * Override the default description from LogsActivity trait.
     *
     * @param string $event
     * @return string
     */
    protected function getActivityDescription(string $event): string
    {
        $settingName = $this->label ?? $this->key;
        
        return match ($event) {
            'created' => "Setting '{$settingName}' was created in group '{$this->group}'",
            'updated' => "Setting '{$settingName}' was updated from '{$this->getOriginal('value')}' to '{$this->value}'",
            'deleted' => "Setting '{$settingName}' was deleted",
            default => parent::getActivityDescription($event),
        };
    }

    /**
     * Get the properties to be logged.
     * Override the default properties from LogsActivity trait.
     *
     * @return array
     */
    protected function getActivityProperties(): array
    {
        $properties = $this->getAttributes();
        
        // Remove unnecessary timestamps
        unset($properties['created_at'], $properties['updated_at']);
        
        // Add formatted values
        if ($this->type === 'boolean') {
            $properties['formatted_value'] = $this->value ? 'Yes' : 'No';
        }

        return $properties;
    }

    /**
     * Determine if the model should log activity.
     * Override the default condition from LogsActivity trait.
     *
     * @return bool
     */
    protected function shouldLogActivity(): bool
    {
        // Only log changes to system settings or when value changes
        return $this->is_system || $this->isDirty('value');
    }
}
