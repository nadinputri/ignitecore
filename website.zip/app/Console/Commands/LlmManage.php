<?php

namespace App\Console\Commands;

use App\Models\LlmSetting;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Process;
use Illuminate\Support\Facades\Storage;

class LlmManage extends Command
{
    protected $signature = 'llm:manage 
        {action : Action to perform (install, update, status, cleanup)}
        {--model=llama2 : Model to use (llama2, mistral)}
        {--size=7B : Model size (7B, 13B, 70B)}
        {--variant=chat : Model variant (chat, instruct, base)}
        {--quantize=4-bit : Quantization level (4-bit, 8-bit, none)}
        {--force : Force action even if conditions are not met}';

    protected $description = 'Manage local LLM installation and configuration';

    protected $settings;

    public function __construct()
    {
        parent::__construct();
        $this->settings = LlmSetting::getConfig();
    }

    public function handle()
    {
        $action = $this->argument('action');

        switch ($action) {
            case 'install':
                return $this->installModel();
            case 'update':
                return $this->updateModel();
            case 'status':
                return $this->checkStatus();
            case 'cleanup':
                return $this->cleanup();
            default:
                $this->error("Unknown action: {$action}");
                return 1;
        }
    }

    protected function installModel()
    {
        $this->info('Installing LLM model...');

        try {
            // Check if Python environment is ready
            if (!$this->checkPythonEnvironment()) {
                $this->error('Python environment is not properly set up. Run setup_llm.sh first.');
                return 1;
            }

            // Get model parameters
            $model = $this->option('model');
            $size = $this->option('size');
            $variant = $this->option('variant');
            $quantize = $this->option('quantize');

            // Validate model configuration
            if (!$this->validateModelConfig($model, $size, $variant)) {
                return 1;
            }

            // Check system requirements
            if (!$this->checkSystemRequirements($size) && !$this->option('force')) {
                $this->error('System requirements not met. Use --force to override.');
                return 1;
            }

            // Download model
            $pythonPath = config('llm.python.path');
            $scriptsPath = config('llm.python.scripts_dir');
            $modelPath = config('llm.defaults.model_path');

            $command = [
                $pythonPath,
                "{$scriptsPath}/download_model.py",
                "--model={$model}",
                "--size={$size}",
                "--variant={$variant}",
                "--quantize={$quantize}",
                "--output={$modelPath}"
            ];

            if ($this->option('force')) {
                $command[] = '--force';
            }

            $this->info('Starting model download...');
            $process = Process::timeout(3600)->run(implode(' ', $command));

            if (!$process->successful()) {
                $this->error('Model download failed: ' . $process->errorOutput());
                return 1;
            }

            // Update settings
            $this->settings->update([
                'model_name' => $model,
                'model_size' => $size,
                'model_variant' => $variant,
                'quantization' => $quantize,
                'model_path' => $modelPath . "/{$model}-{$size}-{$variant}",
                'last_health_check' => now(),
                'health_status' => 'healthy'
            ]);

            $this->info('Model installed successfully!');
            return 0;

        } catch (\Exception $e) {
            Log::error('Model installation failed: ' . $e->getMessage());
            $this->error('Installation failed: ' . $e->getMessage());
            return 1;
        }
    }

    protected function updateModel()
    {
        $this->info('Updating LLM model...');

        try {
            // Check if model is installed
            if (!$this->settings->model_path || !file_exists($this->settings->model_path)) {
                $this->error('No model installed. Use install command first.');
                return 1;
            }

            // Backup current model info
            $modelInfo = json_decode(file_get_contents($this->settings->model_path . '/model_info.json'), true);
            Storage::put('backups/llm/model_info.json', json_encode($modelInfo, JSON_PRETTY_PRINT));

            // Download updated model
            $result = $this->installModel();
            if ($result !== 0) {
                // Restore backup
                if (Storage::exists('backups/llm/model_info.json')) {
                    $backup = Storage::get('backups/llm/model_info.json');
                    file_put_contents($this->settings->model_path . '/model_info.json', $backup);
                }
                return $result;
            }

            $this->info('Model updated successfully!');
            return 0;

        } catch (\Exception $e) {
            Log::error('Model update failed: ' . $e->getMessage());
            $this->error('Update failed: ' . $e->getMessage());
            return 1;
        }
    }

    protected function checkStatus()
    {
        $this->info('Checking LLM status...');

        try {
            // Check model installation
            if (!$this->settings->model_path || !file_exists($this->settings->model_path)) {
                $this->warn('No model installed');
                return 1;
            }

            // Get model info
            $modelInfo = json_decode(file_get_contents($this->settings->model_path . '/model_info.json'), true);
            
            // Get system metrics
            $pythonPath = config('llm.python.path');
            $scriptsPath = config('llm.python.scripts_dir');

            $process = Process::run(implode(' ', [
                $pythonPath,
                "{$scriptsPath}/monitor_llm.py",
                "--model-dir={$this->settings->model_path}",
                "--log-dir=" . storage_path('logs/llm')
            ]));

            if (!$process->successful()) {
                $this->error('Failed to get system metrics: ' . $process->errorOutput());
                return 1;
            }

            $metrics = json_decode($process->output(), true);

            // Update settings with latest metrics
            $this->settings->update([
                'last_health_check' => now(),
                'health_status' => $this->determineHealthStatus($metrics),
                'system_metrics' => $metrics['metrics']
            ]);

            // Display status
            $this->table(['Setting', 'Value'], [
                ['Model', $modelInfo['name']],
                ['Size', $modelInfo['size']],
                ['Variant', $modelInfo['variant']],
                ['Quantization', $modelInfo['quantization']],
                ['Status', $this->settings->health_status],
                ['Last Check', $this->settings->last_health_check->diffForHumans()],
                ['CPU Usage', $metrics['metrics']['cpu']['percent'] . '%'],
                ['Memory Usage', $metrics['metrics']['memory']['percent'] . '%'],
                ['GPU Available', isset($metrics['metrics']['gpu']) ? 'Yes' : 'No']
            ]);

            // Display warnings
            if (!empty($metrics['analysis']['warnings'])) {
                $this->warn('Warnings:');
                foreach ($metrics['analysis']['warnings'] as $warning) {
                    $this->warn("- {$warning}");
                }
            }

            // Display recommendations
            if (!empty($metrics['analysis']['recommendations'])) {
                $this->info('Recommendations:');
                foreach ($metrics['analysis']['recommendations'] as $recommendation) {
                    $this->info("- {$recommendation}");
                }
            }

            return 0;

        } catch (\Exception $e) {
            Log::error('Status check failed: ' . $e->getMessage());
            $this->error('Status check failed: ' . $e->getMessage());
            return 1;
        }
    }

    protected function cleanup()
    {
        $this->info('Cleaning up LLM files...');

        try {
            // Clear caches
            Cache::tags(['llm'])->flush();
            
            // Clear model caches
            $cacheDir = $this->settings->model_path . '/.cache';
            if (file_exists($cacheDir)) {
                array_map('unlink', glob($cacheDir . '/*'));
            }

            // Clean old logs
            $logFiles = Storage::files('logs/llm');
            foreach ($logFiles as $file) {
                $lastModified = Storage::lastModified($file);
                if (now()->timestamp - $lastModified > 14 * 24 * 60 * 60) { // 14 days
                    Storage::delete($file);
                }
            }

            // Clean temporary files
            Storage::deleteDirectory('temp/llm');

            $this->info('Cleanup completed successfully!');
            return 0;

        } catch (\Exception $e) {
            Log::error('Cleanup failed: ' . $e->getMessage());
            $this->error('Cleanup failed: ' . $e->getMessage());
            return 1;
        }
    }

    protected function checkPythonEnvironment()
    {
        $pythonPath = config('llm.python.path');
        
        // Check Python executable
        if (!file_exists($pythonPath)) {
            return false;
        }

        // Check required packages
        $process = Process::run("{$pythonPath} -c 'import torch, transformers, bitsandbytes'");
        return $process->successful();
    }

    protected function validateModelConfig($model, $size, $variant)
    {
        $validModels = ['llama2', 'mistral'];
        $validSizes = ['7B', '13B', '70B'];
        $validVariants = ['chat', 'instruct', 'base'];

        if (!in_array($model, $validModels)) {
            $this->error("Invalid model: {$model}. Valid models: " . implode(', ', $validModels));
            return false;
        }

        if (!in_array($size, $validSizes)) {
            $this->error("Invalid size: {$size}. Valid sizes: " . implode(', ', $validSizes));
            return false;
        }

        if (!in_array($variant, $validVariants)) {
            $this->error("Invalid variant: {$variant}. Valid variants: " . implode(', ', $validVariants));
            return false;
        }

        // Model-specific validations
        if ($model === 'mistral' && $size !== '7B') {
            $this->error('Mistral only supports 7B size');
            return false;
        }

        if ($model === 'mistral' && $variant === 'chat') {
            $this->error('Mistral does not support chat variant');
            return false;
        }

        return true;
    }

    protected function checkSystemRequirements($size)
    {
        $minRam = [
            '7B' => 16,
            '13B' => 32,
            '70B' => 64
        ];

        // Check RAM
        $totalRam = memory_get_total() / (1024 * 1024 * 1024); // Convert to GB
        if ($totalRam < $minRam[$size]) {
            $this->warn("Insufficient RAM: {$totalRam}GB available, {$minRam[$size]}GB recommended");
            return false;
        }

        // Check disk space
        $modelPath = config('llm.defaults.model_path');
        $diskFree = disk_free_space($modelPath) / (1024 * 1024 * 1024); // Convert to GB
        $requiredSpace = $size === '70B' ? 100 : ($size === '13B' ? 50 : 25);
        
        if ($diskFree < $requiredSpace) {
            $this->warn("Insufficient disk space: {$diskFree}GB available, {$requiredSpace}GB required");
            return false;
        }

        return true;
    }

    protected function determineHealthStatus($metrics)
    {
        if ($metrics['metrics']['cpu']['percent'] > 90 || 
            $metrics['metrics']['memory']['percent'] > 90 ||
            $metrics['metrics']['disk']['percent'] > 90) {
            return 'critical';
        }

        if ($metrics['metrics']['cpu']['percent'] > 75 || 
            $metrics['metrics']['memory']['percent'] > 75 ||
            $metrics['metrics']['disk']['percent'] > 75) {
            return 'warning';
        }

        if (isset($metrics['metrics']['gpu'])) {
            foreach ($metrics['metrics']['gpu'] as $gpu) {
                if ($gpu['utilization'] > 90) {
                    return 'warning';
                }
            }
        }

        return 'healthy';
    }
}
