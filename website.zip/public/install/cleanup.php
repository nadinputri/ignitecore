<?php

function removeDirectory($dir) {
    if (!file_exists($dir)) {
        return true;
    }

    if (!is_dir($dir)) {
        return unlink($dir);
    }

    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }

        if (!removeDirectory($dir . DIRECTORY_SEPARATOR . $item)) {
            return false;
        }
    }

    return rmdir($dir);
}

// Only allow cleanup if installation is complete
if (file_exists('../.env') && file_exists('../storage/installed')) {
    // Directories to remove
    $directories = [
        '../install',
        '../installer',
        '../public/install'
    ];

    // Files to remove
    $files = [
        '../install.php',
        '../artisan-package.php',
        '../build-package.php',
        '../manual-package.sh',
        '../verify-package.php',
        '../package-instructions.sh'
    ];

    // Remove directories
    foreach ($directories as $dir) {
        if (file_exists($dir)) {
            removeDirectory($dir);
        }
    }

    // Remove files
    foreach ($files as $file) {
        if (file_exists($file)) {
            unlink($file);
        }
    }

    echo json_encode([
        'success' => true,
        'message' => 'Installation files cleaned up successfully'
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Installation not complete. Cannot cleanup files.'
    ]);
}
