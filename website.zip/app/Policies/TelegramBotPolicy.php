<?php

namespace App\Policies;

use App\Models\User;
use App\Models\TelegramBot;
use Illuminate\Auth\Access\HandlesAuthorization;

class TelegramBotPolicy
{
    use HandlesAuthorization;

    /**
     * Determine if the user can bypass all policies.
     */
    public function before(User $user, $ability)
    {
        if ($user->isAdmin()) {
            return true;
        }
    }

    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user)
    {
        return true;
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, TelegramBot $bot)
    {
        return $user->id === $bot->user_id;
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user)
    {
        $maxBots = setting('telegram_bot_max_bots_per_user', 5);
        $currentBots = $user->telegramBots()->count();
        
        return $currentBots < $maxBots;
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, TelegramBot $bot)
    {
        return $user->id === $bot->user_id;
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, TelegramBot $bot)
    {
        return $user->id === $bot->user_id;
    }

    /**
     * Determine whether the user can manage credits for the model.
     */
    public function manageCredits(User $user, TelegramBot $bot)
    {
        return $user->id === $bot->user_id && $user->wallet->balance > 0;
    }
}
