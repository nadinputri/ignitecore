<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Services\UserService;

class UserDashboardController extends Controller
{
    /**
     * The user service instance.
     *
     * @var \App\Services\UserService
     */
    protected $userService;

    /**
     * Create a new controller instance.
     *
     * @param  \App\Services\UserService  $userService
     * @return void
     */
    public function __construct(UserService $userService)
    {
        $this->middleware(['auth', 'verified', 'active']);
        $this->userService = $userService;
    }

    /**
     * Display the user's dashboard.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $user = Auth::user();

        // Update user's last activity
        $this->userService->updateLastActivity($user);

        // Load relationships for dashboard data
        $user->load([
            'wallet',
            'activeOrders.service',
            'supportTickets' => function ($query) {
                $query->latest()->take(5);
            },
            'notifications' => function ($query) {
                $query->latest()->take(5);
            }
        ]);

        // Get statistics
        $stats = [
            'total_orders' => $user->orders()->count(),
            'active_orders' => $user->activeOrders()->count(),
            'completed_orders' => $user->completedOrders()->count(),
            'total_spent' => $user->getTotalSpent(),
            'open_tickets' => $user->supportTickets()
                ->whereIn('status', ['open', 'in_progress'])
                ->count(),
            'unread_notifications' => $user->unreadNotifications()->count(),
        ];

        // Check if user needs any warnings
        if ($this->userService->needsInactivityWarning($user)) {
            $inactiveDays = config('users.activity.inactive_after');
            $warningDays = config('users.activity.notify_days_before', 7);
            
            $request->session()->flash('warning', 
                "Your account will be marked as inactive in {$warningDays} days due to inactivity. " .
                "Please log in and perform an action to keep your account active."
            );
        }

        return view('user.dashboard', compact('user', 'stats'));
    }

    /**
     * Display the user's activity log.
     *
     * @return \Illuminate\View\View
     */
    public function activity()
    {
        $user = Auth::user();
        
        $activities = $user->activities()
            ->with('causer', 'subject')
            ->latest()
            ->paginate(15);

        return view('user.activity', compact('activities'));
    }

    /**
     * Display the user's account settings.
     *
     * @return \Illuminate\View\View
     */
    public function settings()
    {
        $user = Auth::user();
        
        return view('user.settings', [
            'user' => $user,
            'preferences' => $user->getNotificationPreferences(),
            'requires2fa' => config('users.security.require_2fa', false),
            'allowsMultipleSessions' => config('users.security.allow_multiple_sessions', true),
        ]);
    }

    /**
     * Update the user's account settings.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateSettings(Request $request)
    {
        $user = Auth::user();

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email,' . $user->id],
            'notification_preferences' => ['sometimes', 'array'],
            'notification_preferences.*' => ['boolean'],
        ]);

        $user->update([
            'name' => $validated['name'],
            'email' => $validated['email'],
        ]);

        if (isset($validated['notification_preferences'])) {
            $user->updateNotificationPreferences($validated['notification_preferences']);
        }

        return redirect()
            ->route('user.settings')
            ->with('success', 'Account settings updated successfully.');
    }
}
