@extends('layouts.admin')

@section('title', 'LLM Logs')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">LLM Logs</h3>
                    <div class="card-tools">
                        <form action="{{ route('admin.llm-settings.clear-logs') }}" method="POST" class="d-inline">
                            @csrf
                            <input type="hidden" name="type" value="{{ $type }}">
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to clear these logs?')">
                                <i class="fas fa-trash"></i> Clear Logs
                            </button>
                        </form>
                        <a href="{{ route('admin.llm-settings.index') }}" class="btn btn-sm btn-secondary">
                            <i class="fas fa-arrow-left"></i> Back to Settings
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Filters -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="btn-group">
                                <a href="{{ route('admin.llm-settings.logs', ['type' => 'requests', 'date' => $date]) }}" 
                                   class="btn btn-{{ $type === 'requests' ? 'primary' : 'default' }}">
                                    Requests
                                </a>
                                <a href="{{ route('admin.llm-settings.logs', ['type' => 'errors', 'date' => $date]) }}"
                                   class="btn btn-{{ $type === 'errors' ? 'primary' : 'default' }}">
                                    Errors
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <form class="form-inline float-right">
                                <input type="date" name="date" value="{{ $date }}" class="form-control form-control-sm mr-2">
                                <button type="submit" class="btn btn-sm btn-primary">Filter</button>
                            </form>
                        </div>
                    </div>

                    @if($type === 'requests')
                        <!-- Request Logs -->
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Prompt</th>
                                        <th>Response</th>
                                        <th>Options</th>
                                        <th>Metrics</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($logs as $log)
                                        <tr>
                                            <td>{{ \Carbon\Carbon::parse($log['datetime'])->format('H:i:s') }}</td>
                                            <td>
                                                <div class="text-truncate" style="max-width: 200px;" title="{{ $log['context']['prompt'] }}">
                                                    {{ $log['context']['prompt'] }}
                                                </div>
                                            </td>
                                            <td>
                                                <div class="text-truncate" style="max-width: 300px;" title="{{ $log['context']['response'] }}">
                                                    {{ $log['context']['response'] }}
                                                </div>
                                            </td>
                                            <td>
                                                <small>
                                                    Max Tokens: {{ $log['context']['options']['max_tokens'] }}<br>
                                                    Temperature: {{ $log['context']['options']['temperature'] }}
                                                </small>
                                            </td>
                                            <td>
                                                <small>
                                                    Memory: {{ format_bytes($log['context']['metrics']['memory_usage']) }}<br>
                                                    CPU: {{ round($log['context']['metrics']['cpu_usage'], 2) }}%
                                                    @if(isset($log['context']['metrics']['gpu_info']))
                                                        <br>GPU: {{ $log['context']['metrics']['gpu_info'][0]['utilization'] }}%
                                                    @endif
                                                </small>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="5" class="text-center">No request logs found for this date.</td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    @else
                        <!-- Error Logs -->
                        <div class="table-responsive">
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Error</th>
                                        <th>Context</th>
                                        <th>Stack Trace</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($logs as $log)
                                        <tr>
                                            <td>{{ \Carbon\Carbon::parse($log['datetime'])->format('H:i:s') }}</td>
                                            <td>{{ $log['message'] }}</td>
                                            <td>
                                                @if(isset($log['context']))
                                                    <pre class="mb-0"><code>{{ json_encode($log['context'], JSON_PRETTY_PRINT) }}</code></pre>
                                                @endif
                                            </td>
                                            <td>
                                                @if(isset($log['stack_trace']))
                                                    <pre class="mb-0"><code>{{ $log['stack_trace'] }}</code></pre>
                                                @endif
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="4" class="text-center">No error logs found for this date.</td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
    pre {
        background-color: #f8f9fa;
        padding: 0.5rem;
        border-radius: 0.25rem;
        max-height: 200px;
        overflow-y: auto;
    }
    
    .text-truncate {
        cursor: pointer;
    }
    
    .text-truncate:hover {
        white-space: normal;
        overflow: visible;
    }
</style>
@endpush

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-refresh logs every 30 seconds if viewing today's logs
    @if($date === now()->format('Y-m-d'))
        setInterval(function() {
            window.location.reload();
        }, 30000);
    @endif
});
</script>
@endpush
