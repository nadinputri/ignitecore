<?php

namespace App\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Log;
use App\Services\SecurityService;
use Config;

class FileUploadService
{
    /**
     * Allowed file extensions and their corresponding MIME types
     */
    protected $defaultAllowedTypes = [
        // Images
        'jpg' => ['image/jpeg'],
        'jpeg' => ['image/jpeg'],
        'png' => ['image/png'],
        'gif' => ['image/gif'],
        
        // Documents
        'pdf' => ['application/pdf'],
        'doc' => ['application/msword'],
        'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
        'xls' => ['application/vnd.ms-excel'],
        'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
        'txt' => ['text/plain'],
        
        // Archives
        'zip' => ['application/zip', 'application/x-zip-compressed'],
    ];

    /**
     * Current allowed file types
     */
    protected $allowedTypes;

    /**
     * Maximum file size in bytes (default: 10MB)
     */
    protected $maxFileSize;

    /**
     * Security service instance
     */
    protected $securityService;

    /**
     * Constructor
     */
    public function __construct(SecurityService $securityService)
    {
        $this->securityService = $securityService;
        $this->allowedTypes = $this->defaultAllowedTypes;
        $this->maxFileSize = config('security.file_uploads.max_size', 10485760); // 10MB
    }

    /**
     * Securely store an uploaded file
     *
     * @param UploadedFile $file The uploaded file
     * @param string $directory The directory to store the file in
     * @param array $allowedExtensions Specific allowed extensions for this upload
     * @return array|false File information or false on failure
     */
    public function store(UploadedFile $file, string $directory, array $allowedExtensions = [])
    {
        try {
            // Validate the file
            if (!$this->validateFile($file, $allowedExtensions)) {
                Log::warning('File validation failed', [
                    'filename' => $file->getClientOriginalName(),
                    'mime_type' => $file->getMimeType(),
                    'size' => $file->getSize()
                ]);
                return false;
            }

            // Generate a secure random filename with original extension
            $extension = strtolower($file->getClientOriginalExtension());
            $filename = Str::uuid() . '.' . $extension;

            // Ensure directory exists and has correct permissions
            $fullPath = Storage::disk('private')->path($directory);
            if (!file_exists($fullPath)) {
                mkdir($fullPath, 0755, true);
            }

            // Store the file in a secure location
            $path = $file->storeAs($directory, $filename, 'private');

            // Scan file for malware if configured
            if (config('security.file_uploads.scan_uploads', false)) {
                if (!$this->scanFile($file)) {
                    Storage::disk('private')->delete($path);
                    return false;
                }
            }

            // For images, verify and optimize
            if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])) {
                if (!$this->processImage($path)) {
                    Storage::disk('private')->delete($path);
                    return false;
                }
            }

            // Log successful upload
            Log::info('File uploaded successfully', [
                'original_name' => $file->getClientOriginalName(),
                'stored_name' => $filename,
                'mime_type' => $file->getMimeType(),
                'size' => $file->getSize(),
                'path' => $path
            ]);

            return [
                'path' => $path,
                'filename' => $filename,
                'original_name' => $file->getClientOriginalName(),
                'mime_type' => $file->getMimeType(),
                'size' => $file->getSize(),
                'extension' => $extension,
            ];
        } catch (\Exception $e) {
            Log::error('File upload failed: ' . $e->getMessage(), [
                'original_name' => $file->getClientOriginalName(),
                'mime_type' => $file->getMimeType(),
                'size' => $file->getSize(),
                'trace' => $e->getTraceAsString()
            ]);

            return false;
        }
    }

    /**
     * Validate an uploaded file for security
     *
     * @param UploadedFile $file The uploaded file
     * @param array $allowedExtensions Specific allowed extensions for this upload
     * @return bool Whether the file is valid
     */
    protected function validateFile(UploadedFile $file, array $allowedExtensions = [])
    {
        try {
            // Check if the file was uploaded successfully
            if (!$file->isValid()) {
                return false;
            }

            // Check file size
            if ($file->getSize() > $this->maxFileSize) {
                return false;
            }

            // Get the file extension and mime type
            $extension = strtolower($file->getClientOriginalExtension());
            $mimeType = $file->getMimeType();

            // If specific extensions are provided, use those instead of the default list
            $validExtensions = !empty($allowedExtensions) ? $allowedExtensions : array_keys($this->allowedTypes);

            // Check if the extension is allowed
            if (!in_array($extension, $validExtensions)) {
                return false;
            }

            // Verify the MIME type matches the extension
            if (isset($this->allowedTypes[$extension]) && !in_array($mimeType, $this->allowedTypes[$extension])) {
                return false;
            }

            // Additional security checks for specific file types
            if ($extension === 'pdf') {
                return $this->validatePdf($file);
            }

            // For image files, verify they are actually images
            if (in_array($extension, ['jpg', 'jpeg', 'png', 'gif'])) {
                return $this->validateImage($file);
            }

            return true;
        } catch (\Exception $e) {
            Log::error('File validation failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Validate a PDF file
     *
     * @param UploadedFile $file
     * @return bool
     */
    protected function validatePdf(UploadedFile $file)
    {
        $content = file_get_contents($file->getRealPath());
        
        // Check for potentially malicious content
        $dangerousPatterns = [
            '/\/JS\s*\(/i',          // JavaScript
            '/\/JavaScript/i',        // JavaScript
            '/\/Action\s*\(/i',      // Actions
            '/\/Launch\s*\(/i',      // Launch commands
            '/\/SubmitForm/i',       // Form submission
            '/\/RichMedia/i',        // Rich media
            '/\/OpenAction/i',       // Auto-execute actions
        ];

        foreach ($dangerousPatterns as $pattern) {
            if (preg_match($pattern, $content)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Validate an image file
     *
     * @param UploadedFile $file
     * @return bool
     */
    protected function validateImage(UploadedFile $file)
    {
        // Verify it's actually an image
        $imageInfo = @getimagesize($file->getRealPath());
        if ($imageInfo === false) {
            return false;
        }

        // Check for reasonable dimensions
        list($width, $height) = $imageInfo;
        if ($width <= 0 || $height <= 0 || $width > 8000 || $height > 8000) {
            return false;
        }

        return true;
    }

    /**
     * Process and optimize image files
     *
     * @param string $path
     * @return bool
     */
    protected function processImage($path)
    {
        try {
            $fullPath = Storage::disk('private')->path($path);
            
            // Load image
            $image = imagecreatefromstring(file_get_contents($fullPath));
            if (!$image) {
                return false;
            }

            // Get image info
            $info = getimagesize($fullPath);
            if (!$info) {
                return false;
            }

            // Save processed image
            switch ($info[2]) {
                case IMAGETYPE_JPEG:
                    imagejpeg($image, $fullPath, 85);
                    break;
                case IMAGETYPE_PNG:
                    imagepng($image, $fullPath, 8);
                    break;
                case IMAGETYPE_GIF:
                    imagegif($image, $fullPath);
                    break;
                default:
                    return false;
            }

            imagedestroy($image);
            return true;
        } catch (\Exception $e) {
            Log::error('Image processing failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Scan file for malware
     *
     * @param UploadedFile $file
     * @return bool
     */
    protected function scanFile(UploadedFile $file)
    {
        try {
            $scanCommand = config('security.file_uploads.scan_command');
            if (!$scanCommand) {
                return true; // Skip if no scan command configured
            }

            $filePath = $file->getRealPath();
            $output = shell_exec(escapeshellcmd($scanCommand) . ' ' . escapeshellarg($filePath));

            // Log the scan result
            Log::info('File scan result', [
                'file' => $file->getClientOriginalName(),
                'result' => $output
            ]);

            // Return false if the scan detected threats
            return strpos(strtolower($output), 'found') === false;
        } catch (\Exception $e) {
            Log::error('File scan failed: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Securely retrieve a stored file
     *
     * @param string $path The file path
     * @return \Symfony\Component\HttpFoundation\StreamedResponse|null
     */
    public function retrieve(string $path)
    {
        try {
            if (!Storage::disk('private')->exists($path)) {
                return null;
            }

            $mimeType = Storage::disk('private')->mimeType($path);
            
            return Storage::disk('private')->response($path, null, [
                'Content-Type' => $mimeType,
                'Content-Disposition' => 'inline',
                'X-Content-Type-Options' => 'nosniff',
                'Cache-Control' => 'private, no-cache, no-store, must-revalidate',
            ]);
        } catch (\Exception $e) {
            Log::error('File retrieval failed: ' . $e->getMessage(), [
                'path' => $path
            ]);
            return null;
        }
    }

    /**
     * Securely delete a stored file
     *
     * @param string $path The file path
     * @return bool
     */
    public function delete(string $path)
    {
        try {
            if (!Storage::disk('private')->exists($path)) {
                return false;
            }

            $result = Storage::disk('private')->delete($path);
            
            if ($result) {
                Log::info('File deleted successfully', ['path' => $path]);
            }

            return $result;
        } catch (\Exception $e) {
            Log::error('File deletion failed: ' . $e->getMessage(), [
                'path' => $path
            ]);
            return false;
        }
    }

    /**
     * Set the maximum allowed file size
     *
     * @param int $sizeInBytes Size in bytes
     * @return $this
     */
    public function setMaxFileSize(int $sizeInBytes)
    {
        $this->maxFileSize = $sizeInBytes;
        return $this;
    }

    /**
     * Add or update allowed file types
     *
     * @param array $types Array of extensions and MIME types
     * @return $this
     */
    public function setAllowedTypes(array $types)
    {
        $this->allowedTypes = array_merge($this->allowedTypes, $types);
        return $this;
    }
}
