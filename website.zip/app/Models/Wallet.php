<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Traits\LogsActivity;

class Wallet extends Model
{
    use HasFactory, LogsActivity;

    protected $fillable = ['user_id', 'balance'];

    protected static $logAttributes = ['balance'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function transactions()
    {
        return $this->hasMany(WalletTransaction::class);
    }

    public function credit($amount, $description)
    {
        $this->balance += $amount;
        $this->save();

        return $this->transactions()->create([
            'amount' => $amount,
            'type' => 'credit',
            'description' => $description,
            'status' => 'completed'
        ]);
    }

    public function debit($amount, $description)
    {
        if ($this->balance < $amount) {
            throw new \Exception('Insufficient balance');
        }

        $this->balance -= $amount;
        $this->save();

        return $this->transactions()->create([
            'amount' => $amount,
            'type' => 'debit',
            'description' => $description,
            'status' => 'completed'
        ]);
    }

    public function canAfford($amount)
    {
        return $this->balance >= $amount;
    }
}
