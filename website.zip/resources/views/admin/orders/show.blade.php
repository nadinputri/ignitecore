@extends('layouts.admin')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Order #{{ $order->id }}</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="{{ route('admin.orders.index') }}" class="btn btn-outline-secondary">
                Back to Orders
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <!-- Order Details Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Order Details</h5>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6>Status</h6>
                            <span class="badge bg-{{ 
                                $order->status === 'pending' ? 'warning' : 
                                ($order->status === 'price_offered' ? 'info' : 
                                ($order->status === 'price_countered' ? 'primary' : 
                                ($order->status === 'accepted' ? 'success' : 
                                ($order->status === 'in_progress' ? 'info' : 
                                ($order->status === 'completed' ? 'success' : 'secondary')))))
                            }} mb-2">
                                {{ ucfirst(str_replace('_', ' ', $order->status)) }}
                            </span>
                            
                            @if($order->status === 'pending')
                                <button type="button" 
                                        class="btn btn-primary btn-sm ms-2"
                                        data-bs-toggle="modal"
                                        data-bs-target="#offerPriceModal">
                                    Offer Price
                                </button>
                            @endif

                            @if($order->status === 'accepted')
                                <form action="{{ route('admin.orders.update-status', $order) }}" 
                                      method="POST" 
                                      class="d-inline">
                                    @csrf
                                    <input type="hidden" name="status" value="in_progress">
                                    <button type="submit" class="btn btn-primary btn-sm ms-2">
                                        Start Work
                                    </button>
                                </form>
                            @endif

                            @if($order->status === 'in_progress')
                                <form action="{{ route('admin.orders.update-status', $order) }}" 
                                      method="POST" 
                                      class="d-inline">
                                    @csrf
                                    <input type="hidden" name="status" value="completed">
                                    <button type="submit" class="btn btn-success btn-sm ms-2">
                                        Mark Completed
                                    </button>
                                </form>
                            @endif
                        </div>
                        <div class="col-md-6 text-end">
                            <h6>Price</h6>
                            @if($order->final_price)
                                <span class="h4 text-success">${{ number_format($order->final_price, 2) }}</span>
                                <small class="text-muted">(Final)</small>
                            @elseif($order->counter_price)
                                <span class="h4 text-warning">${{ number_format($order->counter_price, 2) }}</span>
                                <small class="text-muted">(Counter Offer)</small>
                            @elseif($order->initial_price)
                                <span class="h4 text-info">${{ number_format($order->initial_price, 2) }}</span>
                                <small class="text-muted">(Initial Offer)</small>
                            @else
                                <span class="text-muted">Not Set</span>
                            @endif
                        </div>
                    </div>

                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6>Service</h6>
                            <p class="mb-1">{{ $order->service->name }}</p>
                            <small class="text-muted">Base Price: ${{ number_format($order->service->price, 2) }}</small>
                        </div>
                        <div class="col-md-6">
                            <h6>Timeline</h6>
                            <ul class="list-unstyled">
                                <li><small>Created: {{ $order->created_at->format('M d, Y H:i') }}</small></li>
                                @if($order->price_offered_at)
                                    <li><small>Price Offered: {{ $order->price_offered_at->format('M d, Y H:i') }}</small></li>
                                @endif
                                @if($order->price_countered_at)
                                    <li><small>Counter Offered: {{ $order->price_countered_at->format('M d, Y H:i') }}</small></li>
                                @endif
                                @if($order->accepted_at)
                                    <li><small>Accepted: {{ $order->accepted_at->format('M d, Y H:i') }}</small></li>
                                @endif
                                @if($order->started_at)
                                    <li><small>Started: {{ $order->started_at->format('M d, Y H:i') }}</small></li>
                                @endif
                                @if($order->completed_at)
                                    <li><small>Completed: {{ $order->completed_at->format('M d, Y H:i') }}</small></li>
                                @endif
                            </ul>
                        </div>
                    </div>

                    <div class="mb-4">
                        <h6>Requirements</h6>
                        <div class="card bg-light">
                            <div class="card-body">
                                {!! nl2br(e($order->requirements)) !!}
                            </div>
                        </div>
                    </div>

                    @if($order->admin_notes)
                        <div class="mb-4">
                            <h6>Admin Notes</h6>
                            <div class="card bg-light">
                                <div class="card-body">
                                    {!! nl2br(e($order->admin_notes)) !!}
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </div>

            <!-- Order History -->
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Order History</h5>
                </div>
                <div class="card-body">
                    <div class="timeline">
                        @foreach($order->activity_logs()->latest()->get() as $log)
                            <div class="timeline-item">
                                <div class="timeline-marker"></div>
                                <div class="timeline-content">
                                    <h6 class="mb-0">{{ $log->description }}</h6>
                                    <small class="text-muted">{{ $log->created_at->format('M d, Y H:i') }}</small>
                                    @if($log->properties)
                                        <div class="mt-2">
                                            <pre class="bg-light p-2 rounded"><code>{{ json_encode($log->properties, JSON_PRETTY_PRINT) }}</code></pre>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <!-- Customer Information -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Customer Information</h5>
                </div>
                <div class="card-body">
                    <h6>{{ $order->user->name }}</h6>
                    <p class="mb-2">{{ $order->user->email }}</p>
                    <hr>
                    <div class="mb-3">
                        <strong>Wallet Balance:</strong>
                        <span class="text-primary">${{ number_format($order->user->wallet->balance, 2) }}</span>
                    </div>
                    <div class="mb-3">
                        <strong>Member Since:</strong>
                        <br>
                        {{ $order->user->created_at->format('M d, Y') }}
                    </div>
                    <div class="mb-3">
                        <strong>Total Orders:</strong>
                        <br>
                        {{ $order->user->orders()->count() }}
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Actions</h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        @if(in_array($order->status, ['pending', 'price_offered', 'price_countered']))
                            <button type="button" 
                                    class="btn btn-primary"
                                    data-bs-toggle="modal"
                                    data-bs-target="#updateNotesModal">
                                Update Admin Notes
                            </button>

                            <form action="{{ route('admin.orders.update-status', $order) }}" 
                                  method="POST" 
                                  onsubmit="return confirm('Are you sure you want to cancel this order?')">
                                @csrf
                                <input type="hidden" name="status" value="cancelled">
                                <button type="submit" class="btn btn-danger w-100">
                                    Cancel Order
                                </button>
                            </form>
                        @endif

                        @if(in_array($order->status, ['accepted', 'in_progress', 'completed']))
                            <button type="button" 
                                    class="btn btn-warning"
                                    data-bs-toggle="modal"
                                    data-bs-target="#refundModal">
                                Process Refund
                            </button>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Offer Price Modal -->
<div class="modal fade" id="offerPriceModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.orders.offer-price', $order) }}" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Offer Price</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="price" class="form-label">Price Amount</label>
                        <div class="input-group">
                            <span class="input-group-text">$</span>
                            <input type="number" 
                                   class="form-control @error('price') is-invalid @enderror" 
                                   id="price" 
                                   name="price" 
                                   step="0.01" 
                                   min="0" 
                                   value="{{ old('price', $order->service->price) }}"
                                   required>
                        </div>
                        @error('price')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Offer Price</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Update Notes Modal -->
<div class="modal fade" id="updateNotesModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.orders.update-notes', $order) }}" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Update Admin Notes</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="admin_notes" class="form-label">Admin Notes</label>
                        <textarea class="form-control @error('admin_notes') is-invalid @enderror" 
                                  id="admin_notes" 
                                  name="admin_notes" 
                                  rows="5">{{ old('admin_notes', $order->admin_notes) }}</textarea>
                        @error('admin_notes')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Notes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Refund Modal -->
<div class="modal fade" id="refundModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.orders.refund', $order) }}" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Process Refund</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-warning">
                        <strong>Warning!</strong> This will refund ${{ number_format($order->final_price, 2) }} 
                        back to the user's wallet.
                    </div>
                    <div class="mb-3">
                        <label for="reason" class="form-label">Refund Reason</label>
                        <textarea class="form-control @error('reason') is-invalid @enderror" 
                                  id="reason" 
                                  name="reason" 
                                  rows="3" 
                                  required>{{ old('reason') }}</textarea>
                        @error('reason')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-warning">Process Refund</button>
                </div>
            </form>
        </div>
    </div>
</div>

@push('styles')
<style>
.timeline {
    position: relative;
    padding: 20px 0;
}

.timeline-item {
    position: relative;
    padding-left: 40px;
    margin-bottom: 20px;
}

.timeline-marker {
    position: absolute;
    left: 0;
    top: 0;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background-color: #007bff;
    border: 2px solid #fff;
    box-shadow: 0 0 0 2px #007bff;
}

.timeline-item:not(:last-child)::after {
    content: '';
    position: absolute;
    left: 5px;
    top: 12px;
    bottom: -20px;
    width: 2px;
    background-color: #e9ecef;
}
</style>
@endpush
@endsection
