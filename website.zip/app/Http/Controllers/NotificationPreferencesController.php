<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Notifications\DatabaseNotification;

class NotificationPreferencesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'verified']);
        $this->authorizeResource(DatabaseNotification::class, 'notification');
    }

    /**
     * Display a listing of the notifications.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $this->authorize('viewAny', DatabaseNotification::class);

        $notifications = Auth::user()
            ->notifications()
            ->latest()
            ->paginate(15);

        return view('user.notifications.index', compact('notifications'));
    }

    /**
     * Show the notification preferences form.
     *
     * @return \Illuminate\View\View
     */
    public function edit()
    {
        $this->authorize('viewPreferences', DatabaseNotification::class);

        $user = Auth::user();
        $preferences = $user->getNotificationPreferences();

        return view('user.notifications.edit', compact('preferences'));
    }

    /**
     * Update the user's notification preferences.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request)
    {
        $this->authorize('updatePreferences', DatabaseNotification::class);

        $validated = $request->validate([
            'preferences' => 'required|array',
            'preferences.*' => 'boolean',
        ]);

        $user = Auth::user();
        $user->updateNotificationPreferences($validated['preferences']);

        return redirect()
            ->route('notification-preferences.edit')
            ->with('success', 'Notification preferences updated successfully.');
    }

    /**
     * Mark all notifications as read.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function markAllAsRead()
    {
        $this->authorize('markAllAsRead', DatabaseNotification::class);

        Auth::user()->unreadNotifications->markAsRead();

        return back()->with('success', 'All notifications marked as read.');
    }

    /**
     * Mark a specific notification as read.
     *
     * @param  string  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function markAsRead($id)
    {
        $notification = Auth::user()->notifications()->findOrFail($id);
        $this->authorize('markAsRead', $notification);

        $notification->markAsRead();

        return back()->with('success', 'Notification marked as read.');
    }

    /**
     * Delete a specific notification.
     *
     * @param  string  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy($id)
    {
        $notification = Auth::user()->notifications()->findOrFail($id);
        $this->authorize('delete', $notification);

        $notification->delete();

        return back()->with('success', 'Notification deleted.');
    }

    /**
     * Clear all notifications.
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function clearAll()
    {
        $this->authorize('deleteAll', DatabaseNotification::class);

        Auth::user()->notifications()->delete();

        return back()->with('success', 'All notifications cleared.');
    }

    /**
     * Show a specific notification.
     *
     * @param  string  $id
     * @return \Illuminate\View\View|\Illuminate\Http\RedirectResponse
     */
    public function show($id)
    {
        $notification = Auth::user()->notifications()->findOrFail($id);
        $this->authorize('view', $notification);
        
        if (!$notification->read_at) {
            $notification->markAsRead();
        }

        // If the notification has a URL, redirect to it
        if (isset($notification->data['action_url'])) {
            return redirect($notification->data['action_url']);
        }

        return view('user.notifications.show', compact('notification'));
    }

    /**
     * Get the map of resource methods to ability names.
     *
     * @return array
     */
    protected function resourceAbilityMap()
    {
        return [
            'index' => 'viewAny',
            'show' => 'view',
            'create' => 'create',
            'store' => 'create',
            'edit' => 'update',
            'update' => 'update',
            'destroy' => 'delete',
        ];
    }
}
