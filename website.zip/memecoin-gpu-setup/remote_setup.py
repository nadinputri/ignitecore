import os
import sys
import time
import yaml
import paramiko
import threading
import logging
from tqdm import tqdm
from colorama import Fore, Style, init
from cryptography.fernet import Fernet

# Initialize colorama for cross-platform colored output
init()

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("setup_log.txt"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# Script directory
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

class SpinnerThread(threading.Thread):
    """Thread for displaying a spinner animation"""
    def __init__(self, message="Working"):
        super().__init__()
        self.message = message
        self.stop_event = threading.Event()
        self.spinner_chars = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        self.daemon = True
        
    def run(self):
        i = 0
        while not self.stop_event.is_set():
            sys.stdout.write(f"\r{Fore.CYAN}{self.spinner_chars[i]} {self.message}{Style.RESET_ALL}")
            sys.stdout.flush()
            i = (i + 1) % len(self.spinner_chars)
            time.sleep(0.1)
            
    def stop(self):
        self.stop_event.set()
        self.join()
        sys.stdout.write("\r" + " " * (len(self.message) + 2) + "\r")
        sys.stdout.flush()

class RemoteSetup:
    """Handles remote server setup operations"""
    def __init__(self):
        self.config = self._load_config()
        self.client = None
    
    def _load_config(self):
        """Load configuration from YAML file"""
        config_path = os.path.join(SCRIPT_DIR, "server_config.yml")
        with open(config_path, 'r') as file:
            return yaml.safe_load(file)
    
    def _get_password(self):
        """Retrieve the decrypted password"""
        if self.config['server']['auth_type'] != 'password':
            return None
            
        key_path = os.path.join(SCRIPT_DIR, "server_pass.key")
        enc_path = os.path.join(SCRIPT_DIR, "server_pass.enc")
        
        with open(key_path, 'rb') as key_file:
            key = key_file.read()
        
        with open(enc_path, 'rb') as enc_file:
            encrypted = enc_file.read()
            
        f = Fernet(key)
        return f.decrypt(encrypted).decode()
    
    def connect(self):
        """Connect to the remote server"""
        spinner = SpinnerThread("Connecting to server")
        spinner.start()
        
        try:
            self.client = paramiko.SSHClient()
            self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            
            connect_kwargs = {
                'hostname': self.config['server']['ip'],
                'port': self.config['server']['port'],
                'username': self.config['server']['username'],
            }
            
            if self.config['server']['auth_type'] == 'password':
                connect_kwargs['password'] = self._get_password()
            else:
                key_path = os.path.join(SCRIPT_DIR, "id_rsa")
                connect_kwargs['key_filename'] = key_path
                
            self.client.connect(**connect_kwargs, timeout=30)
            logger.info(f"Successfully connected to {self.config['server']['ip']}")
            spinner.stop()
            print(f"{Fore.GREEN}✓ Connected to server{Style.RESET_ALL}")
            return True
            
        except Exception as e:
            spinner.stop()
            logger.error(f"Connection failed: {str(e)}")
            print(f"{Fore.RED}✗ Failed to connect: {str(e)}{Style.RESET_ALL}")
            return False
    
    def run_command(self, command, display=None):
        """Run a command on the remote server"""
        if display:
            spinner = SpinnerThread(display)
            spinner.start()
            
        try:
            stdin, stdout, stderr = self.client.exec_command(command)
            exit_status = stdout.channel.recv_exit_status()
            
            if display:
                spinner.stop()
                
            if exit_status == 0:
                if display:
                    print(f"{Fore.GREEN}✓ {display} - Completed{Style.RESET_ALL}")
                logger.info(f"Command succeeded: {command}")
                return True, stdout.read().decode(), stderr.read().decode()
            else:
                if display:
                    print(f"{Fore.RED}✗ {display} - Failed{Style.RESET_ALL}")
                error_message = stderr.read().decode()
                logger.error(f"Command failed: {command}\nError: {error_message}")
                return False, "", error_message
                
        except Exception as e:
            if display:
                spinner.stop()
                print(f"{Fore.RED}✗ {display} - Error: {str(e)}{Style.RESET_ALL}")
            logger.error(f"Error executing command: {str(e)}")
            return False, "", str(e)
    
    def upload_file(self, local_path, remote_path):
        """Upload a file to the remote server"""
        try:
            sftp = self.client.open_sftp()
            sftp.put(local_path, remote_path)
            sftp.close()
            logger.info(f"Uploaded {local_path} to {remote_path}")
            return True
        except Exception as e:
            logger.error(f"Error uploading file: {str(e)}")
            return False
    
    def setup_server(self):
        """Run the complete server setup process"""
        if not self.connect():
            return False
            
        steps = [
            self._prepare_environment,
            self._install_dependencies,
            self._install_gpu_drivers,
            self._setup_python_environment,
            self._configure_security,
            self._setup_monitoring,
            self._setup_api_server,
            self._run_tests
        ]
        
        success = True
        with tqdm(total=len(steps), desc="Overall Progress") as progress_bar:
            for step_func in steps:
                step_name = step_func.__name__.replace('_', ' ').title().replace('Gpu', 'GPU').replace('Api', 'API')
                progress_bar.set_description(f"Running: {step_name}")
                success &= step_func()
                progress_bar.update(1)
                time.sleep(0.5)  # Small delay for UI feedback
        
        if success:
            print(f"{Fore.GREEN}✨ All setup steps completed successfully!{Style.RESET_ALL}")
        else:
            print(f"{Fore.YELLOW}⚠️  Setup completed with some issues. Check logs for details.{Style.RESET_ALL}")
        
        self.client.close()
        return success
    
    def _prepare_environment(self):
        """Prepare the server environment"""
        print(f"\n{Fore.BLUE}== Preparing Environment =={Style.RESET_ALL}")
        
        # Create working directory
        success, _, _ = self.run_command(
            "mkdir -p ~/memecoin-setup",
            "Creating working directory"
        )
        return success
    
    def _install_dependencies(self):
        """Install required system dependencies"""
        print(f"\n{Fore.BLUE}== Installing System Dependencies =={Style.RESET_ALL}")
        
        # Check OS and install appropriate packages
        check_os_cmd = "if [ -f /etc/os-release ]; then grep -oP '(?<=^ID=).+' /etc/os-release | tr -d '\"'; else echo unknown; fi"
        success, os_type, _ = self.run_command(check_os_cmd)
        
        if not success:
            return False
        
        os_type = os_type.strip()
        if "ubuntu" in os_type or "debian" in os_type:
            update_cmd = "apt-get update && apt-get upgrade -y"
            install_cmd = "apt-get install -y build-essential curl wget git software-properties-common python3 python3-pip"
        elif "fedora" in os_type or "centos" in os_type or "rhel" in os_type:
            update_cmd = "dnf update -y"
            install_cmd = "dnf install -y gcc gcc-c++ make curl wget git python3 python3-pip"
        else:
            logger.error(f"Unsupported OS: {os_type}")
            print(f"{Fore.RED}✗ Unsupported operating system: {os_type}{Style.RESET_ALL}")
            return False
        
        # Update package lists
        success, _, _ = self.run_command(
            update_cmd,
            "Updating system packages"
        )
        if not success:
            return False
            
        # Install dependencies
        success, _, _ = self.run_command(
            install_cmd,
            "Installing essential packages"
        )
        return success
    
    def _install_gpu_drivers(self):
        """Install GPU drivers and CUDA"""
        print(f"\n{Fore.BLUE}== Installing GPU Drivers and CUDA =={Style.RESET_ALL}")
        
        # Check for NVIDIA GPU
        success, gpu_check, _ = self.run_command(
            "lspci | grep -i nvidia",
            "Detecting NVIDIA GPU"
        )
        
        if not gpu_check:
            print(f"{Fore.RED}✗ No NVIDIA GPU detected. This setup requires NVIDIA GPU.{Style.RESET_ALL}")
            return False
        
        # Determine OS for driver installation
        success, os_info, _ = self.run_command("cat /etc/os-release")
        if not success:
            return False
        
        if "ubuntu" in os_info.lower() or "debian" in os_info.lower():
            # Install NVIDIA drivers on Ubuntu/Debian
            commands = [
                "apt-get install -y linux-headers-$(uname -r)",
                "add-apt-repository -y ppa:graphics-drivers/ppa",
                "apt-get update",
                "apt-get install -y nvidia-driver-560",
                "wget https://developer.download.nvidia.com/compute/cuda/12.6.0/local_installers/cuda_12.6.0_535.54.03_linux.run -O ~/cuda_installer.run",
                "sh ~/cuda_installer.run --toolkit --silent --override",
                "echo 'export PATH=/usr/local/cuda/bin:$PATH' > /etc/profile.d/cuda.sh",
                "echo 'export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH' >> /etc/profile.d/cuda.sh",
                "chmod +x /etc/profile.d/cuda.sh"
            ]
        else:
            # For Fedora/RHEL/CentOS
            commands = [
                "dnf install -y kernel-devel kernel-headers gcc make dkms acpid libglvnd-glx libglvnd-opengl libglvnd-devel pkgconfig",
                "dnf config-manager --add-repo https://developer.download.nvidia.com/compute/cuda/repos/fedora36/x86_64/cuda-fedora36.repo",
                "dnf clean all",
                "dnf module install -y nvidia-driver:latest-dkms",
                "dnf install -y cuda",
                "echo 'export PATH=/usr/local/cuda/bin:$PATH' > /etc/profile.d/cuda.sh",
                "echo 'export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH' >> /etc/profile.d/cuda.sh",
                "chmod +x /etc/profile.d/cuda.sh"
            ]
        
        # Execute each command in sequence
        for cmd in commands:
            success, _, _ = self.run_command(cmd, f"Running: {cmd.split()[0]}")
            if not success:
                return False
        
        # Verify installation
        success, cuda_version, _ = self.run_command(
            "source /etc/profile.d/cuda.sh && nvcc --version",
            "Verifying CUDA installation"
        )
        return success
    
    def _setup_python_environment(self):
        """Set up Python environment with AI frameworks"""
        print(f"\n{Fore.BLUE}== Setting Up Python Environment =={Style.RESET_ALL}")
        
        # Create virtual environment
        commands = [
            "mkdir -p ~/memecoin-ai",
            "cd ~/memecoin-ai && python3 -m venv venv",
            "echo 'source ~/memecoin-ai/venv/bin/activate' > ~/memecoin-ai/activate.sh",
            "chmod +x ~/memecoin-ai/activate.sh"
        ]
        
        for cmd in commands:
            success, _, _ = self.run_command(cmd, f"Setting up virtual environment")
            if not success:
                return False
        
        # Install AI packages
        pip_installs = [
            "pip install --upgrade pip",
            "pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121",
            "pip install tensorflow",
            "pip install transformers huggingface_hub accelerate bitsandbytes optimum auto-gptq exllama safetensors sentence-transformers",
            "pip install fastapi uvicorn pydantic"
        ]
        
        for cmd in pip_installs:
            success, _, _ = self.run_command(
                f"source ~/memecoin-ai/venv/bin/activate && {cmd}",
                f"Installing AI packages"
            )
            if not success:
                return False
        
        return True
    
    def _configure_security(self):
        """Configure security measures"""
        print(f"\n{Fore.BLUE}== Configuring Security =={Style.RESET_ALL}")
        
        # Backup SSH config
        self.run_command("cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak", "Backing up SSH config")
        
        # Create improved SSH config
        ssh_config = """
# Memecoin Bot enhanced SSH config
Port 2222
PermitRootLogin prohibit-password
PasswordAuthentication no
ChallengeResponseAuthentication no
UsePAM yes
X11Forwarding no
PrintMotd no
AcceptEnv LANG LC_*
Subsystem sftp /usr/lib/openssh/sftp-server
"""
        
        # Write to temp file and move to correct location
        tmp_path = "/tmp/sshd_config.new"
        with open(os.path.join(SCRIPT_DIR, "sshd_config.new"), "w") as f:
            f.write(ssh_config.strip())
        
        self.upload_file(os.path.join(SCRIPT_DIR, "sshd_config.new"), tmp_path)
        
        # Add user's public key if provided
        api_user = self.config['api']['username']
        success, _, _ = self.run_command(
            f"useradd -m -s /bin/bash {api_user} || true",
            f"Creating API user account"
        )
        
        # Configure automatic security updates
        success, os_info, _ = self.run_command("cat /etc/os-release")
        if "ubuntu" in os_info.lower() or "debian" in os_info.lower():
            self.run_command(
                "apt-get install -y unattended-upgrades && dpkg-reconfigure -plow unattended-upgrades",
                "Setting up automatic security updates"
            )
        else:
            self.run_command(
                "dnf install -y dnf-automatic && systemctl enable --now dnf-automatic.timer",
                "Setting up automatic security updates"
            )
        
        # Validate security settings
        self.run_command("sshd -t", "Validating SSH configuration")
        
        return True
    
    def _setup_monitoring(self):
        """Set up monitoring tools"""
        print(f"\n{Fore.BLUE}== Setting Up Monitoring =={Style.RESET_ALL}")
        
        # Install basic monitoring tools
        success, os_info, _ = self.run_command("cat /etc/os-release")
        if "ubuntu" in os_info.lower() or "debian" in os_info.lower():
            self.run_command(
                "apt-get install -y htop nvidia-smi",
                "Installing basic monitoring tools"
            )
        else:
            self.run_command(
                "dnf install -y htop",
                "Installing basic monitoring tools"
            )
        
        # Install gpustat via pip
        self.run_command(
            "pip3 install gpustat",
            "Installing GPU stats utility"
        )
        
        # Create monitoring script
        monitor_script = """#!/bin/bash
source ~/memecoin-ai/venv/bin/activate
echo "===== GPU Status ====="
nvidia-smi
echo
echo "===== Detailed GPU Stats ====="
gpustat -cp
deactivate
"""
        
        # Write to file and make executable
        with open(os.path.join(SCRIPT_DIR, "monitor-gpu.sh"), "w") as f:
            f.write(monitor_script)
        
        self.upload_file(os.path.join(SCRIPT_DIR, "monitor-gpu.sh"), "/tmp/monitor-gpu.sh")
        self.run_command(
            "mv /tmp/monitor-gpu.sh ~/memecoin-ai/monitor-gpu.sh && chmod +x ~/memecoin-ai/monitor-gpu.sh",
            "Creating GPU monitoring script"
        )
        
        return True
    
    def _setup_api_server(self):
        """Set up the API server for integration with admin panel"""
        print(f"\n{Fore.BLUE}== Setting Up API Server =={Style.RESET_ALL}")
        
        # Set environment variables for API credentials
        env_vars = f"""
export API_USERNAME="{self.config['api']['username']}"
export API_PASSWORD="{self.config['api']['password']}"
"""
        
        # Write environment variables
        with open(os.path.join(SCRIPT_DIR, "api_env.sh"), "w") as f:
            f.write(env_vars)
            
        self.upload_file(os.path.join(SCRIPT_DIR, "api_env.sh"), "/tmp/api_env.sh")
        self.run_command(
            "mv /tmp/api_env.sh ~/memecoin-ai/api_env.sh && chmod +x ~/memecoin-ai/api_env.sh",
            "Setting up API environment"
        )
        
        # Upload API server script
        self.upload_file(os.path.join(SCRIPT_DIR, "api_server.py"), "/tmp/api_server.py")
        self.run_command(
            "mv /tmp/api_server.py ~/memecoin-ai/api_server.py",
            "Installing API server script"
        )
        
        # Create systemd service file
        service_file = f"""[Unit]
Description=Memecoin Bot GPU API Server
After=network.target

[Service]
User={self.config['server']['username']}
WorkingDirectory=/home/{self.config['server']['username']}/memecoin-ai
EnvironmentFile=/home/{self.config['server']['username']}/memecoin-ai/api_env.sh
ExecStart=/home/{self.config['server']['username']}/memecoin-ai/venv/bin/python /home/{self.config['server']['username']}/memecoin-ai/api_server.py
Restart=always
RestartSec=5
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=memecoin-api

[Install]
WantedBy=multi-user.target
"""
        
        # Write service file and install
        with open(os.path.join(SCRIPT_DIR, "memecoin-api.service"), "w") as f:
            f.write(service_file)
            
        self.upload_file(os.path.join(SCRIPT_DIR, "memecoin-api.service"), "/tmp/memecoin-api.service")
        
        commands = [
            "mv /tmp/memecoin-api.service /etc/systemd/system/",
            "systemctl daemon-reload",
            "systemctl enable memecoin-api.service",
            "systemctl start memecoin-api.service"
        ]
        
        for cmd in commands:
            success, _, _ = self.run_command(cmd, "Setting up API server service")
            if not success:
                return False
                
        # Verify service is running
        success, service_status, _ = self.run_command(
            "systemctl is-active memecoin-api.service",
            "Verifying API service is running"
        )
        
        return service_status.strip() == "active"
    
    def _run_tests(self):
        """Run tests to ensure the setup is working correctly"""
        print(f"\n{Fore.BLUE}== Testing Installation =={Style.RESET_ALL}")
        
        # Create test script
        test_script = """
import os
import sys
import platform
import subprocess
import torch

def print_header(title):
    print("\\n" + "=" * 50)
    print(f" {title}")
    print("=" * 50)

def check_system_info():
    print_header("SYSTEM INFORMATION")
    print(f"OS: {platform.platform()}")
    print(f"Python Version: {platform.python_version()}")
    
    # Check CPU info
    cpu_info = subprocess.check_output("cat /proc/cpuinfo | grep 'model name' | head -1", shell=True).decode()
    print(f"CPU: {cpu_info.split(':')[1].strip()}")
    
    # Check memory
    mem_info = subprocess.check_output("free -h | grep Mem", shell=True).decode().split()
    print(f"Memory: Total={mem_info[1]}, Used={mem_info[2]}, Free={mem_info[3]}")
    
    # Check disk space
    disk_info = subprocess.check_output("df -h / | tail -1", shell=True).decode().split()
    print(f"Disk Space: Total={disk_info[1]}, Used={disk_info[2]}, Free={disk_info[3]}")

def check_gpu_info():
    print_header("GPU INFORMATION")
    try:
        # Check NVIDIA driver
        nvidia_version = subprocess.check_output("nvidia-smi --query-gpu=driver_version --format=csv,noheader", shell=True).decode().strip()
        print(f"NVIDIA Driver Version: {nvidia_version}")
        
        # Check GPU details
        gpu_info = subprocess.check_output("nvidia-smi --query-gpu=name,memory.total,power.draw,temperature.gpu --format=csv,noheader", shell=True).decode().strip().split(',')
        print(f"GPU: {gpu_info[0].strip()}")
        print(f"GPU Memory: {gpu_info[1].strip()}")
        print(f"GPU Power: {gpu_info[2].strip()}")
        print(f"GPU Temperature: {gpu_info[3].strip()}")
    except Exception as e:
        print(f"Error getting GPU info: {e}")

def check_cuda():
    print_header("CUDA CONFIGURATION")
    
    # Check CUDA version
    try:
        cuda_version = subprocess.check_output("nvcc --version | grep release", shell=True).decode()
        print(f"CUDA Version: {cuda_version.split('release')[1].strip()}")
    except Exception:
        print("NVCC not found or not in PATH")
    
    # Check PyTorch CUDA
    print(f"PyTorch Version: {torch.__version__}")
    print(f"CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"CUDA version used by PyTorch: {torch.version.cuda}")
        print(f"Number of GPUs: {torch.cuda.device_count()}")
        for i in range(torch.cuda.device_count()):
            print(f"  GPU {i}: {torch.cuda.get_device_name(i)}")

def test_pytorch():
    print_header("PYTORCH GPU TEST")
    
    if not torch.cuda.is_available():
        print("CUDA is not available for PyTorch")
        return
    
    print("Creating test tensor...")
    x = torch.rand(5, 3)
    print(x)
    
    try:
        print("Moving tensor to GPU...")
        x = x.cuda()
        print(f"Tensor device: {x.device}")
        print("Running basic matrix multiplication...")
        y = torch.matmul(x, x.t())
        print("Result shape:", y.shape)
        print("GPU test successful!")
    except Exception as e:
        print(f"GPU test failed: {e}")

def test_transformers():
    print_header("TESTING TRANSFORMERS")
    try:
        from transformers import pipeline
        
        print("Loading small model for testing...")
        classifier = pipeline('sentiment-analysis', device=0 if torch.cuda.is_available() else -1)
        
        print("Running inference...")
        result = classifier("Memecoin Bot is awesome!")[0]
        print(f"Result: {result['label']} (Score: {result['score']:.4f})")
        print("Transformers test successful!")
    except Exception as e:
        print(f"Transformers test failed: {e}")

def main():
    print("MEMECOIN BOT GPU SERVER TEST")
    print("===========================")
    
    check_system_info()
    check_gpu_info()
    check_cuda()
    test_pytorch()
    test_transformers()
    
    print("\\nTesting completed!")

if __name__ == "__main__":
    main()
"""
        
        # Write test script
        with open(os.path.join(SCRIPT_DIR, "test_gpu.py"), "w") as f:
            f.write(test_script)
            
        self.upload_file(os.path.join(SCRIPT_DIR, "test_gpu.py"), "/tmp/test_gpu.py")
        self.run_command(
            "mv /tmp/test_gpu.py ~/memecoin-ai/test_gpu.py",
            "Creating test script"
        )
        
        # Run tests
        print("\nRunning tests to verify installation...")
        success, output, error = self.run_command(
            "cd ~/memecoin-ai && source ./venv/bin/activate && python test_gpu.py",
            "Running GPU tests"
        )
        
        if success:
            print(f"{Fore.GREEN}Test completed successfully!{Style.RESET_ALL}")
        else:
            print(f"{Fore.RED}Test encountered issues. See log for details.{Style.RESET_ALL}")
            
        # Save test results to log
        logger.info("Test Results:\n" + output)
        if error:
            logger.error("Test Errors:\n" + error)
        
        return success

if __name__ == "__main__":
    setup = RemoteSetup()
    success = setup.setup_server()
    sys.exit(0 if success else 1)
