<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Security Headers
    |--------------------------------------------------------------------------
    |
    | Configuration for security headers applied to all responses.
    |
    */
    'headers' => [
        'strict-transport-security' => [
            'enabled' => true,
            'max-age' => 31536000, // 1 year
            'include-subdomains' => true,
            'preload' => true,
        ],
        'content-security-policy' => [
            'enabled' => true,
            'report-only' => false,
            'report-uri' => null,
        ],
        'permissions-policy' => [
            'enabled' => true,
            'features' => [
                'camera' => [],
                'microphone' => [],
                'geolocation' => [],
                'payment' => [],
                'usb' => [],
                'bluetooth' => [],
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Session Security
    |--------------------------------------------------------------------------
    |
    | Configuration for session security features.
    |
    */
    'session' => [
        'regenerate_interval' => 300, // 5 minutes
        'expire_on_close' => true,
        'strict_security' => true,
        'same_site' => 'lax',
        'secure' => true,
        'http_only' => true,
    ],

    /*
    |--------------------------------------------------------------------------
    | File Upload Security
    |--------------------------------------------------------------------------
    |
    | Configuration for file upload security features.
    |
    */
    'file_uploads' => [
        'max_size' => 10485760, // 10MB
        'scan_uploads' => true,
        'scan_command' => 'clamscan', // Requires ClamAV to be installed
        'allowed_types' => [
            'image/jpeg',
            'image/png',
            'image/gif',
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel',
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'text/plain',
            'application/zip',
        ],
        'image_validation' => [
            'max_width' => 8000,
            'max_height' => 8000,
            'optimize' => true,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Input Validation
    |--------------------------------------------------------------------------
    |
    | Configuration for input validation and sanitization.
    |
    */
    'input_validation' => [
        'enable_strict_validation' => true,
        'sanitize_all_inputs' => true,
        'log_validation_failures' => true,
    ],

    /*
    |--------------------------------------------------------------------------
    | API Security
    |--------------------------------------------------------------------------
    |
    | Configuration for API security features.
    |
    */
    'api' => [
        'rate_limiting' => [
            'enabled' => true,
            'max_attempts' => 60,
            'decay_minutes' => 1,
        ],
        'require_https' => true,
        'token_expiration' => 60, // minutes
    ],

    /*
    |--------------------------------------------------------------------------
    | Password Security
    |--------------------------------------------------------------------------
    |
    | Configuration for password security features.
    |
    */
    'passwords' => [
        'expire_days' => 90,
        'min_length' => 12,
        'require_special_chars' => true,
        'require_numbers' => true,
        'require_mixed_case' => true,
        'prevent_common_passwords' => true,
        'max_login_attempts' => 5,
        'lockout_minutes' => 15,
    ],

    /*
    |--------------------------------------------------------------------------
    | Activity Logging
    |--------------------------------------------------------------------------
    |
    | Configuration for security-related activity logging.
    |
    */
    'logging' => [
        'enabled' => true,
        'channels' => ['security', 'daily'],
        'retention_days' => 90,
        'log_login_attempts' => true,
        'log_password_resets' => true,
        'log_suspicious_activity' => true,
    ],

    /*
    |--------------------------------------------------------------------------
    | Two Factor Authentication
    |--------------------------------------------------------------------------
    |
    | Configuration for 2FA features.
    |
    */
    'two_factor' => [
        'enabled' => true,
        'enforce_for_admins' => true,
        'issuer' => env('APP_NAME', 'Laravel'),
        'window' => 1,
        'recovery_codes' => 8,
    ],

    /*
    |--------------------------------------------------------------------------
    | IP Security
    |--------------------------------------------------------------------------
    |
    | Configuration for IP-based security features.
    |
    */
    'ip_security' => [
        'max_login_attempts' => 10,
        'block_duration' => 24, // hours
        'whitelist' => [],
        'blacklist' => [],
    ],

    /*
    |--------------------------------------------------------------------------
    | Security Audit
    |--------------------------------------------------------------------------
    |
    | Configuration for security audit features.
    |
    */
    'audit' => [
        'enabled' => true,
        'interval' => 'daily',
        'notify_email' => env('SECURITY_AUDIT_EMAIL'),
        'check_file_permissions' => true,
        'check_composer_dependencies' => true,
        'check_php_version' => true,
    ],
];
