<?php

namespace App\Services;

use App\Models\Order;
use App\Models\User;
use App\Models\Service;
use Illuminate\Support\Facades\DB;
use Exception;

class OrderService
{
    /**
     * Create a new order for a service.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Service  $service
     * @param  array  $data
     * @return \App\Models\Order
     */
    public function createOrder(User $user, Service $service, array $data)
    {
        return DB::transaction(function () use ($user, $service, $data) {
            return $user->orders()->create([
                'service_id' => $service->id,
                'status' => 'pending',
                'requirements' => $data['requirements'] ?? null,
            ]);
        });
    }

    /**
     * Offer initial price for an order.
     *
     * @param  \App\Models\Order  $order
     * @param  float  $price
     * @return \App\Models\Order
     */
    public function offerPrice(Order $order, float $price)
    {
        return DB::transaction(function () use ($order, $price) {
            $order->update([
                'initial_price' => $price,
                'status' => 'price_offered',
                'price_offered_at' => now()
            ]);

            return $order;
        });
    }

    /**
     * Submit a counter offer for an order.
     *
     * @param  \App\Models\Order  $order
     * @param  float  $price
     * @return \App\Models\Order
     */
    public function counterOffer(Order $order, float $price)
    {
        if (!in_array($order->status, ['price_offered'])) {
            throw new Exception('Cannot make counter offer at this stage.');
        }

        return DB::transaction(function () use ($order, $price) {
            $order->update([
                'counter_price' => $price,
                'status' => 'price_countered',
                'price_countered_at' => now()
            ]);

            return $order;
        });
    }

    /**
     * Accept the offered price and process payment.
     *
     * @param  \App\Models\Order  $order
     * @return \App\Models\Order
     */
    public function acceptPrice(Order $order)
    {
        if (!in_array($order->status, ['price_offered'])) {
            throw new Exception('Cannot accept price at this stage.');
        }

        return DB::transaction(function () use ($order) {
            // Get the user's wallet
            $wallet = $order->user->wallet;

            // Check if user has enough balance
            if (!$wallet->canAfford($order->initial_price)) {
                throw new Exception('Insufficient wallet balance.');
            }

            // Process the payment
            $wallet->debit(
                $order->initial_price,
                "Payment for Order #{$order->id}"
            );

            // Update order status
            $order->update([
                'final_price' => $order->initial_price,
                'status' => 'accepted',
                'accepted_at' => now()
            ]);

            return $order;
        });
    }

    /**
     * Start working on the order.
     *
     * @param  \App\Models\Order  $order
     * @return \App\Models\Order
     */
    public function startWork(Order $order)
    {
        if ($order->status !== 'accepted') {
            throw new Exception('Cannot start work at this stage.');
        }

        return DB::transaction(function () use ($order) {
            $order->update([
                'status' => 'in_progress',
                'started_at' => now()
            ]);

            return $order;
        });
    }

    /**
     * Mark the order as completed.
     *
     * @param  \App\Models\Order  $order
     * @return \App\Models\Order
     */
    public function completeOrder(Order $order)
    {
        if ($order->status !== 'in_progress') {
            throw new Exception('Cannot complete order at this stage.');
        }

        return DB::transaction(function () use ($order) {
            $order->update([
                'status' => 'completed',
                'completed_at' => now()
            ]);

            return $order;
        });
    }

    /**
     * Cancel the order.
     *
     * @param  \App\Models\Order  $order
     * @return \App\Models\Order
     */
    public function cancelOrder(Order $order)
    {
        if (!in_array($order->status, ['pending', 'price_offered', 'price_countered'])) {
            throw new Exception('Cannot cancel order at this stage.');
        }

        return DB::transaction(function () use ($order) {
            $order->update([
                'status' => 'cancelled',
                'cancelled_at' => now()
            ]);

            return $order;
        });
    }

    /**
     * Refund an order.
     *
     * @param  \App\Models\Order  $order
     * @param  string  $reason
     * @return \App\Models\Order
     */
    public function refundOrder(Order $order, string $reason)
    {
        if (!in_array($order->status, ['accepted', 'in_progress', 'completed'])) {
            throw new Exception('Cannot refund order at this stage.');
        }

        return DB::transaction(function () use ($order, $reason) {
            // Process refund to user's wallet
            $order->user->wallet->credit(
                $order->final_price,
                "Refund for Order #{$order->id}: {$reason}"
            );

            // Update order status
            $order->update([
                'status' => 'refunded',
                'refunded_at' => now(),
                'refund_reason' => $reason
            ]);

            return $order;
        });
    }
}
