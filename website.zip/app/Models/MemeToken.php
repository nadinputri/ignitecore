<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MemeToken extends Model
{
    protected $fillable = [
        'name',
        'symbol',
        'contract_address',
        'network',
        'current_price',
        'market_cap',
        'holder_count',
        'dex_pairs',
        'is_active'
    ];

    protected $casts = [
        'dex_pairs' => 'array',
        'is_active' => 'boolean',
        'current_price' => 'decimal:18',
        'market_cap' => 'decimal:2',
    ];

    public function analyses()
    {
        return $this->hasMany(TokenAnalysis::class);
    }

    public function latestAnalysis()
    {
        return $this->hasOne(TokenAnalysis::class)->latest('analyzed_at');
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function getFormattedMarketCapAttribute()
    {
        if (!$this->market_cap) return 'N/A';
        
        if ($this->market_cap >= 1000000000) {
            return '$' . number_format($this->market_cap / 1000000000, 2) . 'B';
        }
        
        if ($this->market_cap >= 1000000) {
            return '$' . number_format($this->market_cap / 1000000, 2) . 'M';
        }
        
        return '$' . number_format($this->market_cap, 2);
    }
}
