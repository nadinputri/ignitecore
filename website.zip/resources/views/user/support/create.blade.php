@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Create Support Ticket</h5>
                    <a href="{{ route('support-tickets.index') }}" class="btn btn-outline-secondary btn-sm">
                        Back to Tickets
                    </a>
                </div>

                <div class="card-body">
                    <form action="{{ route('support-tickets.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf

                        <div class="mb-3">
                            <label for="subject" class="form-label">Subject</label>
                            <input type="text" 
                                   class="form-control @error('subject') is-invalid @enderror" 
                                   id="subject" 
                                   name="subject" 
                                   value="{{ old('subject') }}" 
                                   required>
                            @error('subject')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="description" class="form-label">Description</label>
                            <textarea class="form-control @error('description') is-invalid @enderror" 
                                      id="description" 
                                      name="description" 
                                      rows="5" 
                                      required>{{ old('description') }}</textarea>
                            @error('description')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div class="form-text">
                                Please provide as much detail as possible about your issue.
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="priority" class="form-label">Priority</label>
                            <select class="form-select @error('priority') is-invalid @enderror" 
                                    id="priority" 
                                    name="priority" 
                                    required>
                                <option value="">Select Priority</option>
                                <option value="low" {{ old('priority') === 'low' ? 'selected' : '' }}>
                                    Low - General inquiry or non-urgent issue
                                </option>
                                <option value="medium" {{ old('priority') === 'medium' ? 'selected' : '' }}>
                                    Medium - Issue affecting functionality
                                </option>
                                <option value="high" {{ old('priority') === 'high' ? 'selected' : '' }}>
                                    High - Critical issue requiring immediate attention
                                </option>
                            </select>
                            @error('priority')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="attachments" class="form-label">Attachments (Optional)</label>
                            <input type="file" 
                                   class="form-control @error('attachments.*') is-invalid @enderror" 
                                   id="attachments" 
                                   name="attachments[]" 
                                   multiple>
                            @error('attachments.*')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div class="form-text">
                                You can upload multiple files (max 10MB each). Supported formats: images, PDFs, and documents.
                            </div>
                        </div>

                        <div class="mb-3" id="attachment-preview">
                            <!-- Preview selected files here via JavaScript -->
                        </div>

                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">
                                Submit Ticket
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.getElementById('attachments').addEventListener('change', function(e) {
    const preview = document.getElementById('attachment-preview');
    preview.innerHTML = '';

    if (this.files.length > 0) {
        const list = document.createElement('div');
        list.className = 'list-group mt-2';

        Array.from(this.files).forEach(file => {
            const item = document.createElement('div');
            item.className = 'list-group-item d-flex justify-content-between align-items-center';
            
            const name = document.createElement('span');
            name.textContent = file.name;
            
            const size = document.createElement('span');
            size.className = 'badge bg-primary rounded-pill';
            size.textContent = Math.round(file.size / 1024) + ' KB';
            
            item.appendChild(name);
            item.appendChild(size);
            list.appendChild(item);
        });

        preview.appendChild(list);
    }
});
</script>
@endpush
@endsection
