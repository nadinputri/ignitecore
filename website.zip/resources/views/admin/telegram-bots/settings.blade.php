@extends('layouts.admin')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Telegram Bot Global Settings</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="{{ route('admin.telegram-bots.index') }}" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Bots
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Configuration Settings</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.telegram-bots.update-settings') }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="mb-4">
                            <label for="credit_cost_per_message" class="form-label">Credit Cost per Message</label>
                            <div class="input-group">
                                <input type="number" 
                                    class="form-control @error('credit_cost_per_message') is-invalid @enderror" 
                                    id="credit_cost_per_message" 
                                    name="credit_cost_per_message" 
                                    value="{{ old('credit_cost_per_message', $settings['credit_cost_per_message']) }}"
                                    min="1">
                                <span class="input-group-text">credits</span>
                            </div>
                            @error('credit_cost_per_message')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div class="form-text">Number of credits charged per message processed by the bot</div>
                        </div>

                        <div class="mb-4">
                            <label for="max_bots_per_user" class="form-label">Maximum Bots per User</label>
                            <input type="number" 
                                class="form-control @error('max_bots_per_user') is-invalid @enderror" 
                                id="max_bots_per_user" 
                                name="max_bots_per_user" 
                                value="{{ old('max_bots_per_user', $settings['max_bots_per_user']) }}"
                                min="1">
                            @error('max_bots_per_user')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div class="form-text">Maximum number of bots a user can create</div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Allowed Commands</label>
                            <div class="card bg-light">
                                <div class="card-body" id="commands-container">
                                    @foreach($settings['allowed_commands'] as $command)
                                        <div class="input-group mb-2">
                                            <input type="text" 
                                                class="form-control" 
                                                name="allowed_commands[]" 
                                                value="{{ $command }}"
                                                placeholder="Command name">
                                            <button type="button" class="btn btn-danger remove-command">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                    @endforeach
                                </div>
                                <div class="card-footer">
                                    <button type="button" class="btn btn-secondary" id="add-command">
                                        <i class="fas fa-plus"></i> Add Command
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Network Settings</label>
                            <div class="card bg-light">
                                <div class="card-body">
                                    <div class="mb-3">
                                        <div class="form-check">
                                            <input type="checkbox" 
                                                class="form-check-input" 
                                                id="enable_ethereum" 
                                                name="networks[ethereum]" 
                                                value="1"
                                                {{ isset($settings['networks']['ethereum']) && $settings['networks']['ethereum'] ? 'checked' : '' }}>
                                            <label class="form-check-label" for="enable_ethereum">
                                                Enable Ethereum Network
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <div class="form-check">
                                            <input type="checkbox" 
                                                class="form-check-input" 
                                                id="enable_bsc" 
                                                name="networks[bsc]" 
                                                value="1"
                                                {{ isset($settings['networks']['bsc']) && $settings['networks']['bsc'] ? 'checked' : '' }}>
                                            <label class="form-check-label" for="enable_bsc">
                                                Enable Binance Smart Chain
                                            </label>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="default_gas_limit" class="form-label">Default Gas Limit</label>
                                        <input type="number" 
                                            class="form-control" 
                                            id="default_gas_limit" 
                                            name="default_gas_limit" 
                                            value="{{ old('default_gas_limit', $settings['default_gas_limit'] ?? 300000) }}"
                                            min="21000">
                                    </div>

                                    <div class="mb-3">
                                        <label for="default_slippage" class="form-label">Default Slippage (%)</label>
                                        <input type="number" 
                                            class="form-control" 
                                            id="default_slippage" 
                                            name="default_slippage" 
                                            value="{{ old('default_slippage', $settings['default_slippage'] ?? 5) }}"
                                            min="0.1" 
                                            max="100" 
                                            step="0.1">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Settings
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Usage Statistics</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <small class="text-muted">Total Active Bots:</small>
                        <div class="h4">{{ number_format($activeBots) }}</div>
                    </div>

                    <div class="mb-3">
                        <small class="text-muted">Total Credits Used Today:</small>
                        <div class="h4">{{ number_format($creditsUsedToday) }}</div>
                    </div>

                    <div class="mb-3">
                        <small class="text-muted">Average Credits per Bot:</small>
                        <div>{{ number_format($averageCreditsPerBot, 1) }}</div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Quick Actions</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.telegram-bots.reset-settings') }}" method="POST" class="mb-3">
                        @csrf
                        <button type="submit" class="btn btn-warning w-100" 
                            onclick="return confirm('Are you sure you want to reset all settings to default values?')">
                            <i class="fas fa-undo"></i> Reset to Defaults
                        </button>
                    </form>

                    <form action="{{ route('admin.telegram-bots.disable-all') }}" method="POST">
                        @csrf
                        <button type="submit" class="btn btn-danger w-100"
                            onclick="return confirm('Are you sure you want to disable all bots? This will affect all users.')">
                            <i class="fas fa-power-off"></i> Disable All Bots
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const commandsContainer = document.getElementById('commands-container');
    const addCommandBtn = document.getElementById('add-command');

    addCommandBtn.addEventListener('click', function() {
        const div = document.createElement('div');
        div.className = 'input-group mb-2';
        div.innerHTML = `
            <input type="text" class="form-control" name="allowed_commands[]" placeholder="Command name">
            <button type="button" class="btn btn-danger remove-command">
                <i class="fas fa-times"></i>
            </button>
        `;
        commandsContainer.appendChild(div);
    });

    commandsContainer.addEventListener('click', function(e) {
        if (e.target.closest('.remove-command')) {
            e.target.closest('.input-group').remove();
        }
    });
});
</script>
@endpush
