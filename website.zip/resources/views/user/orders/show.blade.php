@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-0">Order #{{ $order->id }}</h5>
                        <p class="text-muted mb-0">{{ $order->service->name }}</p>
                    </div>
                    <div>
                        <a href="{{ url()->previous() }}" class="btn btn-outline-secondary btn-sm">
                            Back
                        </a>
                    </div>
                </div>

                <div class="card-body">
                    <!-- Order Status -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <span class="badge bg-{{ 
                                $order->status === 'pending' ? 'warning' : 
                                ($order->status === 'in_progress' ? 'info' : 
                                ($order->status === 'completed' ? 'success' : 'secondary'))
                            }} me-2">
                                {{ ucfirst(str_replace('_', ' ', $order->status)) }}
                            </span>
                            <span class="text-muted">
                                Created {{ $order->created_at->format('M d, Y H:i') }}
                            </span>
                        </div>
                        <div class="col-md-6 text-end">
                            @if(in_array($order->status, ['pending', 'price_offered', 'price_countered']))
                                <form action="{{ route('orders.cancel', $order) }}" method="POST" class="d-inline">
                                    @csrf
                                    <button type="submit" class="btn btn-danger btn-sm" 
                                            onclick="return confirm('Are you sure you want to cancel this order?')">
                                        Cancel Order
                                    </button>
                                </form>
                            @endif
                        </div>
                    </div>

                    <!-- Price Information -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <div class="card bg-light">
                                <div class="card-body">
                                    <h6>Price Details</h6>
                                    @if($order->final_price)
                                        <p class="mb-0">
                                            <strong>Final Price:</strong> 
                                            ${{ number_format($order->final_price, 2) }}
                                        </p>
                                    @elseif($order->counter_price)
                                        <p class="mb-0">
                                            <strong>Your Counter Offer:</strong> 
                                            ${{ number_format($order->counter_price, 2) }}
                                        </p>
                                        <p class="mb-0">
                                            <strong>Initial Price:</strong> 
                                            ${{ number_format($order->initial_price, 2) }}
                                        </p>
                                        <small class="text-muted">Waiting for admin response</small>
                                    @elseif($order->initial_price)
                                        <p class="mb-0">
                                            <strong>Offered Price:</strong> 
                                            ${{ number_format($order->initial_price, 2) }}
                                        </p>
                                        @if($order->status === 'price_offered')
                                            <div class="mt-3">
                                                <form action="{{ route('orders.accept-price', $order) }}" method="POST" class="d-inline">
                                                    @csrf
                                                    <button type="submit" class="btn btn-success btn-sm me-2">
                                                        Accept Price
                                                    </button>
                                                </form>
                                                <button type="button" 
                                                        class="btn btn-primary btn-sm"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#counterOfferModal">
                                                    Make Counter Offer
                                                </button>
                                            </div>
                                        @endif
                                    @else
                                        <p class="mb-0 text-muted">Waiting for price offer...</p>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Service Details -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <h6>Service Details</h6>
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-3">
                                            @if($order->service->image)
                                                <img src="{{ asset($order->service->image) }}" 
                                                     class="img-fluid rounded" 
                                                     alt="{{ $order->service->name }}">
                                            @endif
                                        </div>
                                        <div class="col-md-9">
                                            <h5>{{ $order->service->name }}</h5>
                                            <p>{{ $order->service->description }}</p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-muted">
                                                    Base Price: ${{ number_format($order->service->price, 2) }}
                                                </span>
                                                <a href="{{ route('services.show', $order->service) }}" 
                                                   class="btn btn-outline-primary btn-sm">
                                                    View Service
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Requirements -->
                    @if($order->requirements)
                        <div class="row mb-4">
                            <div class="col-md-12">
                                <h6>Your Requirements</h6>
                                <div class="card">
                                    <div class="card-body">
                                        {!! nl2br(e($order->requirements)) !!}
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif

                    <!-- Order Timeline -->
                    <div class="row">
                        <div class="col-md-12">
                            <h6>Order Timeline</h6>
                            <div class="card">
                                <div class="card-body p-0">
                                    <div class="list-group list-group-flush">
                                        @if($order->completed_at)
                                            <div class="list-group-item">
                                                <div class="d-flex w-100 justify-content-between">
                                                    <h6 class="mb-1">Order Completed</h6>
                                                    <small>{{ $order->completed_at->format('M d, Y H:i') }}</small>
                                                </div>
                                            </div>
                                        @endif

                                        @if($order->started_at)
                                            <div class="list-group-item">
                                                <div class="d-flex w-100 justify-content-between">
                                                    <h6 class="mb-1">Work Started</h6>
                                                    <small>{{ $order->started_at->format('M d, Y H:i') }}</small>
                                                </div>
                                            </div>
                                        @endif

                                        @if($order->accepted_at)
                                            <div class="list-group-item">
                                                <div class="d-flex w-100 justify-content-between">
                                                    <h6 class="mb-1">Price Accepted</h6>
                                                    <small>{{ $order->accepted_at->format('M d, Y H:i') }}</small>
                                                </div>
                                                <p class="mb-1">Final Price: ${{ number_format($order->final_price, 2) }}</p>
                                            </div>
                                        @endif

                                        @if($order->price_countered_at)
                                            <div class="list-group-item">
                                                <div class="d-flex w-100 justify-content-between">
                                                    <h6 class="mb-1">Counter Offer Made</h6>
                                                    <small>{{ $order->price_countered_at->format('M d, Y H:i') }}</small>
                                                </div>
                                                <p class="mb-1">Counter Price: ${{ number_format($order->counter_price, 2) }}</p>
                                            </div>
                                        @endif

                                        @if($order->price_offered_at)
                                            <div class="list-group-item">
                                                <div class="d-flex w-100 justify-content-between">
                                                    <h6 class="mb-1">Price Offered</h6>
                                                    <small>{{ $order->price_offered_at->format('M d, Y H:i') }}</small>
                                                </div>
                                                <p class="mb-1">Initial Price: ${{ number_format($order->initial_price, 2) }}</p>
                                            </div>
                                        @endif

                                        <div class="list-group-item">
                                            <div class="d-flex w-100 justify-content-between">
                                                <h6 class="mb-1">Order Created</h6>
                                                <small>{{ $order->created_at->format('M d, Y H:i') }}</small>
                                            </div>
                                            <p class="mb-1">Service: {{ $order->service->name }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Counter Offer Modal -->
<div class="modal fade" id="counterOfferModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('orders.counter-offer', $order) }}" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Make Counter Offer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Initial Price</label>
                        <input type="text" class="form-control" value="${{ number_format($order->initial_price, 2) }}" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="counter_price" class="form-label">Your Counter Offer</label>
                        <div class="input-group">
                            <span class="input-group-text">$</span>
                            <input type="number" 
                                   class="form-control @error('counter_price') is-invalid @enderror" 
                                   id="counter_price" 
                                   name="counter_price" 
                                   step="0.01" 
                                   min="0" 
                                   required>
                        </div>
                        @error('counter_price')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit Counter Offer</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
