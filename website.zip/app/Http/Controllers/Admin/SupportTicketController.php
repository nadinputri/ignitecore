<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SupportTicket;
use App\Models\SupportTicketReply;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SupportTicketController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'admin']);
    }

    public function index(Request $request)
    {
        $query = SupportTicket::with(['user', 'assignedTo'])
            ->withCount('replies');

        // Filter by status
        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        // Filter by priority
        if ($request->has('priority')) {
            $query->where('priority', $request->priority);
        }

        // Search by ticket number or subject
        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('ticket_number', 'like', "%{$search}%")
                    ->orWhere('subject', 'like', "%{$search}%");
            });
        }

        $tickets = $query->latest()->paginate(15);
        $admins = User::where('is_admin', true)->get();

        return view('admin.support.index', compact('tickets', 'admins'));
    }

    public function show(SupportTicket $ticket)
    {
        $ticket->load(['user', 'assignedTo', 'replies.user', 'replies.attachments', 'attachments']);
        $admins = User::where('is_admin', true)->get();

        return view('admin.support.show', compact('ticket', 'admins'));
    }

    public function reply(Request $request, SupportTicket $ticket)
    {
        $validated = $request->validate([
            'message' => 'required|string',
            'attachments.*' => 'nullable|file|max:10240'
        ]);

        $reply = $ticket->replies()->create([
            'user_id' => Auth::id(),
            'message' => $validated['message'],
            'is_admin_reply' => true
        ]);

        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {
                $path = $file->store('support-tickets/' . $ticket->id . '/replies');
                
                $reply->attachments()->create([
                    'ticket_id' => $ticket->id,
                    'filename' => $file->getClientOriginalName(),
                    'path' => $path,
                    'mime_type' => $file->getMimeType(),
                    'size' => $file->getSize()
                ]);
            }
        }

        // Update ticket status if it's the first admin reply
        if ($ticket->status === 'open') {
            $ticket->markAsInProgress();
        }

        return redirect()
            ->route('admin.support-tickets.show', $ticket)
            ->with('success', 'Reply added successfully.');
    }

    public function assign(Request $request, SupportTicket $ticket)
    {
        $validated = $request->validate([
            'admin_id' => 'required|exists:users,id'
        ]);

        $ticket->update([
            'assigned_to' => $validated['admin_id'],
            'status' => 'in_progress'
        ]);

        return redirect()
            ->route('admin.support-tickets.show', $ticket)
            ->with('success', 'Ticket assigned successfully.');
    }

    public function updateStatus(Request $request, SupportTicket $ticket)
    {
        $validated = $request->validate([
            'status' => 'required|in:open,in_progress,resolved,closed'
        ]);

        switch ($validated['status']) {
            case 'resolved':
                $ticket->markAsResolved();
                break;
            case 'closed':
                $ticket->markAsClosed();
                break;
            case 'open':
                $ticket->reopen();
                break;
            default:
                $ticket->markAsInProgress();
        }

        return redirect()
            ->route('admin.support-tickets.show', $ticket)
            ->with('success', 'Ticket status updated successfully.');
    }

    public function updatePriority(Request $request, SupportTicket $ticket)
    {
        $validated = $request->validate([
            'priority' => 'required|in:low,medium,high'
        ]);

        $ticket->update(['priority' => $validated['priority']]);

        return redirect()
            ->route('admin.support-tickets.show', $ticket)
            ->with('success', 'Ticket priority updated successfully.');
    }
}
