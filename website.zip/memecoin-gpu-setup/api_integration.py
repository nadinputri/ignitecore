"""
API Integration module for external data sources and trading platforms
"""

import os
import sys
import logging
import aiohttp
import asyncio
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Union
import pandas as pd

logger = logging.getLogger(__name__)

class APIIntegration:
    """Handles integration with external APIs"""
    
    def __init__(self, config_path: str = "config/api_config.json"):
        """
        Initialize API integration
        
        Args:
            config_path: Path to API configuration file
        """
        self.config = self._load_config(config_path)
        self.session = None
        self.rate_limits = {}
        
    def _load_config(self, config_path: str) -> Dict:
        """Load API configuration"""
        try:
            with open(config_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Error loading config: {str(e)}")
            return {
                'base_urls': {
                    'binance': 'https://api.binance.com',
                    'coingecko': 'https://api.coingecko.com/api/v3'
                },
                'api_keys': {
                    'binance': os.getenv('BINANCE_API_KEY'),
                    'binance_secret': os.getenv('BINANCE_SECRET_KEY')
                },
                'rate_limits': {
                    'binance': {'requests': 1200, 'period': 60},
                    'coingecko': {'requests': 50, 'period': 60}
                }
            }
            
    async def start(self):
        """Initialize API session"""
        if not self.session:
            self.session = aiohttp.ClientSession()
            
    async def stop(self):
        """Close API session"""
        if self.session:
            await self.session.close()
            self.session = None
            
    async def get_token_price(self,
                            token_symbol: str,
                            vs_currency: str = 'usd') -> Optional[float]:
        """
        Get current token price
        
        Args:
            token_symbol: Token symbol (e.g., 'BTC')
            vs_currency: Quote currency (e.g., 'USD')
            
        Returns:
            Current price or None if request fails
        """
        try:
            url = f"{self.config['base_urls']['coingecko']}/simple/price"
            params = {
                'ids': token_symbol.lower(),
                'vs_currencies': vs_currency.lower()
            }
            
            async with self.session.get(url, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    return data[token_symbol.lower()][vs_currency.lower()]
                else:
                    logger.error(f"Error getting price: {response.status}")
                    return None
                    
        except Exception as e:
            logger.error(f"Error fetching token price: {str(e)}")
            return None
            
    async def get_historical_data(self,
                                token_symbol: str,
                                timeframe: str = '1h',
                                limit: int = 100) -> Optional[pd.DataFrame]:
        """
        Get historical price data
        
        Args:
            token_symbol: Token symbol
            timeframe: Candle timeframe (e.g., '1h', '4h', '1d')
            limit: Number of candles to fetch
            
        Returns:
            DataFrame with historical data or None if request fails
        """
        try:
            url = f"{self.config['base_urls']['binance']}/api/v3/klines"
            params = {
                'symbol': f"{token_symbol}USDT",
                'interval': timeframe,
                'limit': limit
            }
            
            async with self.session.get(url, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    df = pd.DataFrame(data, columns=[
                        'timestamp', 'open', 'high', 'low', 'close',
                        'volume', 'close_time', 'quote_volume', 'trades',
                        'taker_buy_volume', 'taker_buy_quote_volume', 'ignore'
                    ])
                    
                    # Convert timestamp to datetime
                    df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
                    
                    # Convert price columns to float
                    for col in ['open', 'high', 'low', 'close', 'volume']:
                        df[col] = df[col].astype(float)
                        
                    return df
                else:
                    logger.error(f"Error getting historical data: {response.status}")
                    return None
                    
        except Exception as e:
            logger.error(f"Error fetching historical data: {str(e)}")
            return None
            
    async def get_market_depth(self,
                             token_symbol: str,
                             limit: int = 100) -> Optional[Dict]:
        """
        Get market depth (order book)
        
        Args:
            token_symbol: Token symbol
            limit: Number of bids/asks to fetch
            
        Returns:
            Dictionary with bids and asks or None if request fails
        """
        try:
            url = f"{self.config['base_urls']['binance']}/api/v3/depth"
            params = {
                'symbol': f"{token_symbol}USDT",
                'limit': limit
            }
            
            async with self.session.get(url, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    return {
                        'bids': [[float(p), float(q)] for p, q in data['bids']],
                        'asks': [[float(p), float(q)] for p, q in data['asks']]
                    }
                else:
                    logger.error(f"Error getting market depth: {response.status}")
                    return None
                    
        except Exception as e:
            logger.error(f"Error fetching market depth: {str(e)}")
            return None
            
    async def get_token_info(self, token_symbol: str) -> Optional[Dict]:
        """
        Get detailed token information
        
        Args:
            token_symbol: Token symbol
            
        Returns:
            Dictionary with token information or None if request fails
        """
        try:
            url = f"{self.config['base_urls']['coingecko']}/coins/{token_symbol.lower()}"
            params = {
                'localization': 'false',
                'tickers': 'false',
                'market_data': 'true',
                'community_data': 'true',
                'developer_data': 'true'
            }
            
            async with self.session.get(url, params=params) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    logger.error(f"Error getting token info: {response.status}")
                    return None
                    
        except Exception as e:
            logger.error(f"Error fetching token info: {str(e)}")
            return None
            
    async def get_trading_volume(self,
                               token_symbol: str,
                               timeframe: str = '24h') -> Optional[float]:
        """
        Get trading volume for specified timeframe
        
        Args:
            token_symbol: Token symbol
            timeframe: Time period (e.g., '24h', '7d')
            
        Returns:
            Trading volume or None if request fails
        """
        try:
            url = f"{self.config['base_urls']['coingecko']}/coins/{token_symbol.lower()}/market_chart"
            params = {
                'vs_currency': 'usd',
                'days': '1' if timeframe == '24h' else '7',
                'interval': 'daily'
            }
            
            async with self.session.get(url, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    volumes = [v[1] for v in data['total_volumes']]
                    return sum(volumes)
                else:
                    logger.error(f"Error getting trading volume: {response.status}")
                    return None
                    
        except Exception as e:
            logger.error(f"Error fetching trading volume: {str(e)}")
            return None
            
    def _check_rate_limit(self, api: str) -> bool:
        """Check if we're within rate limits for the specified API"""
        now = datetime.now()
        limit_info = self.config['rate_limits'].get(api, {})
        
        if not limit_info:
            return True
            
        if api not in self.rate_limits:
            self.rate_limits[api] = {
                'count': 0,
                'reset_time': now + timedelta(seconds=limit_info['period'])
            }
            
        # Reset counter if period has elapsed
        if now >= self.rate_limits[api]['reset_time']:
            self.rate_limits[api] = {
                'count': 0,
                'reset_time': now + timedelta(seconds=limit_info['period'])
            }
            
        # Check if we're within limits
        if self.rate_limits[api]['count'] >= limit_info['requests']:
            return False
            
        self.rate_limits[api]['count'] += 1
        return True
        
    async def _handle_rate_limit(self, api: str):
        """Handle rate limiting for API requests"""
        while not self._check_rate_limit(api):
            wait_time = (self.rate_limits[api]['reset_time'] - datetime.now()).total_seconds()
            if wait_time > 0:
                logger.warning(f"Rate limit reached for {api}, waiting {wait_time:.2f} seconds")
                await asyncio.sleep(wait_time)
                
    async def execute_trade(self,
                          token_symbol: str,
                          side: str,
                          quantity: float,
                          price: Optional[float] = None) -> Optional[Dict]:
        """
        Execute a trade
        
        Args:
            token_symbol: Token symbol
            side: 'buy' or 'sell'
            quantity: Amount to trade
            price: Optional limit price (market order if None)
            
        Returns:
            Order details or None if trade fails
        """
        try:
            # This is a placeholder - implement actual trading logic
            logger.info(f"Executing {side} order for {quantity} {token_symbol}")
            return {
                'symbol': token_symbol,
                'side': side,
                'quantity': quantity,
                'price': price,
                'status': 'simulated',
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Error executing trade: {str(e)}")
            return None
