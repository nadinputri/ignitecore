@extends('layouts.admin')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Telegram Bots Management</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="{{ route('admin.telegram-bots.settings') }}" class="btn btn-primary">
                <i class="fas fa-cog"></i> Global Settings
            </a>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>User</th>
                            <th>Status</th>
                            <th>Credits Used</th>
                            <th>Created</th>
                            <th>Last Active</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($bots as $bot)
                            <tr>
                                <td>{{ $bot->id }}</td>
                                <td>{{ $bot->name }}</td>
                                <td>
                                    <a href="{{ route('admin.users.show', $bot->user) }}">
                                        {{ $bot->user->name }}
                                    </a>
                                </td>
                                <td>
                                    <span class="badge {{ $bot->status === 'active' ? 'bg-success' : 'bg-danger' }}">
                                        {{ ucfirst($bot->status) }}
                                    </span>
                                </td>
                                <td>{{ number_format($bot->total_credits_used) }}</td>
                                <td>{{ $bot->created_at->format('M d, Y') }}</td>
                                <td>
                                    @if($bot->credits()->exists())
                                        {{ $bot->credits()->latest()->first()->created_at->diffForHumans() }}
                                    @else
                                        Never
                                    @endif
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="{{ route('admin.telegram-bots.show', $bot) }}" 
                                            class="btn btn-sm btn-info" 
                                            data-bs-toggle="tooltip" 
                                            title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        
                                        <a href="{{ route('admin.telegram-bots.edit', $bot) }}" 
                                            class="btn btn-sm btn-primary"
                                            data-bs-toggle="tooltip" 
                                            title="Edit Bot">
                                            <i class="fas fa-edit"></i>
                                        </a>

                                        <form action="{{ route('admin.telegram-bots.destroy', $bot) }}" 
                                            method="POST" 
                                            class="d-inline"
                                            onsubmit="return confirm('Are you sure you want to delete this bot?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" 
                                                class="btn btn-sm btn-danger"
                                                data-bs-toggle="tooltip" 
                                                title="Delete Bot">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center py-4">
                                    No telegram bots found
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            @if($bots->hasPages())
                <div class="mt-4">
                    {{ $bots->links() }}
                </div>
            @endif
        </div>
    </div>

    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5 class="card-title">Total Bots</h5>
                    <div class="h2">{{ number_format($bots->total()) }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5 class="card-title">Active Bots</h5>
                    <div class="h2">{{ number_format($bots->where('status', 'active')->count()) }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h5 class="card-title">Total Credits Used</h5>
                    <div class="h2">{{ number_format($bots->sum('total_credits_used')) }}</div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function(tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
</script>
@endpush
