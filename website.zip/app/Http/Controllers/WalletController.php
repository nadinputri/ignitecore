<?php

namespace App\Http\Controllers;

use App\Models\Wallet;
use App\Models\WalletTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class WalletController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $wallet = Auth::user()->wallet;
        $transactions = $wallet->transactions()
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('user.wallet.index', compact('wallet', 'transactions'));
    }

    public function topUp(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|min:1'
        ]);

        $wallet = Auth::user()->wallet;
        $transaction = $wallet->credit(
            $request->amount,
            'Manual top-up'
        );

        return redirect()->route('wallet.index')
            ->with('success', 'Wallet topped up successfully!');
    }

    public function transactions()
    {
        $transactions = Auth::user()->wallet->transactions()
            ->orderBy('created_at', 'desc')
            ->paginate(20);

        return view('user.wallet.transactions', compact('transactions'));
    }

    public function show(WalletTransaction $transaction)
    {
        $this->authorize('view', $transaction);
        
        return view('user.wallet.transaction-details', compact('transaction'));
    }
}
