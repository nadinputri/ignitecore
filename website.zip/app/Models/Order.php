<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Traits\LogsActivity;

class Order extends Model
{
    use HasFactory, LogsActivity;

    protected $fillable = [
        'user_id',
        'service_id',
        'status',
        'requirements',
        'initial_price',
        'counter_price',
        'final_price',
        'admin_notes',
        'price_offered_at',
        'price_countered_at',
        'accepted_at',
        'started_at',
        'completed_at',
        'cancelled_at',
        'refunded_at',
        'refund_reason'
    ];

    protected $casts = [
        'price_offered_at' => 'datetime',
        'price_countered_at' => 'datetime',
        'accepted_at' => 'datetime',
        'started_at' => 'datetime',
        'completed_at' => 'datetime',
        'cancelled_at' => 'datetime',
        'refunded_at' => 'datetime',
    ];

    protected static $logAttributes = [
        'status',
        'initial_price',
        'counter_price',
        'final_price',
        'admin_notes',
    ];

    /**
     * Get the user that owns the order.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the service associated with the order.
     */
    public function service()
    {
        return $this->belongsTo(Service::class);
    }

    /**
     * Get the order transactions for this order.
     */
    public function orderTransactions()
    {
        return $this->hasMany(OrderTransaction::class);
    }

    /**
     * Get the wallet transactions through order transactions.
     */
    public function transactions()
    {
        return $this->hasManyThrough(
            WalletTransaction::class,
            OrderTransaction::class,
            'order_id',
            'id',
            'id',
            'wallet_transaction_id'
        );
    }

    /**
     * Get the payment transaction for this order.
     */
    public function paymentTransaction()
    {
        return $this->orderTransactions()->payments()->first();
    }

    /**
     * Get the refund transaction for this order.
     */
    public function refundTransaction()
    {
        return $this->orderTransactions()->refunds()->first();
    }

    /**
     * Mark the order as in progress.
     */
    public function markAsInProgress()
    {
        $this->update([
            'status' => 'in_progress',
            'started_at' => now()
        ]);
    }

    /**
     * Mark the order as completed.
     */
    public function markAsCompleted()
    {
        $this->update([
            'status' => 'completed',
            'completed_at' => now()
        ]);
    }

    /**
     * Mark the order as cancelled.
     */
    public function markAsCancelled()
    {
        $this->update([
            'status' => 'cancelled',
            'cancelled_at' => now()
        ]);
    }

    /**
     * Mark the order as refunded.
     */
    public function markAsRefunded($reason)
    {
        $this->update([
            'status' => 'refunded',
            'refunded_at' => now(),
            'refund_reason' => $reason
        ]);
    }

    /**
     * Check if the order can be cancelled.
     */
    public function canBeCancelled()
    {
        return in_array($this->status, ['pending', 'price_offered', 'price_countered']);
    }

    /**
     * Check if the order can be refunded.
     */
    public function canBeRefunded()
    {
        return in_array($this->status, ['accepted', 'in_progress', 'completed']) && 
               !is_null($this->final_price) && 
               is_null($this->refunded_at);
    }

    /**
     * Check if the order is active.
     */
    public function isActive()
    {
        return in_array($this->status, ['pending', 'price_offered', 'price_countered', 'accepted', 'in_progress']);
    }

    /**
     * Check if the order is completed.
     */
    public function isCompleted()
    {
        return $this->status === 'completed';
    }

    /**
     * Check if the order is cancelled.
     */
    public function isCancelled()
    {
        return $this->status === 'cancelled';
    }

    /**
     * Check if the order is refunded.
     */
    public function isRefunded()
    {
        return !is_null($this->refunded_at);
    }

    /**
     * Get the current price of the order.
     */
    public function getCurrentPrice()
    {
        return $this->final_price ?? $this->counter_price ?? $this->initial_price ?? null;
    }

    /**
     * Get the formatted current price.
     */
    public function getFormattedCurrentPrice()
    {
        $price = $this->getCurrentPrice();
        return $price ? '$' . number_format($price, 2) : 'Not Set';
    }

    /**
     * Get the status label for display.
     */
    public function getStatusLabel()
    {
        return ucfirst(str_replace('_', ' ', $this->status));
    }

    /**
     * Get the status badge class.
     */
    public function getStatusBadgeClass()
    {
        return match($this->status) {
            'pending' => 'warning',
            'price_offered' => 'info',
            'price_countered' => 'primary',
            'accepted' => 'success',
            'in_progress' => 'info',
            'completed' => 'success',
            'cancelled' => 'danger',
            'refunded' => 'secondary',
            default => 'secondary'
        };
    }

    /**
     * Scope a query to only include active orders.
     */
    public function scopeActive($query)
    {
        return $query->whereIn('status', ['pending', 'price_offered', 'price_countered', 'accepted', 'in_progress']);
    }

    /**
     * Scope a query to only include completed orders.
     */
    public function scopeCompleted($query)
    {
        return $query->where('status', 'completed');
    }

    /**
     * Scope a query to only include cancelled orders.
     */
    public function scopeCancelled($query)
    {
        return $query->where('status', 'cancelled');
    }

    /**
     * Scope a query to only include refunded orders.
     */
    public function scopeRefunded($query)
    {
        return $query->whereNotNull('refunded_at');
    }

    /**
     * Scope a query to only include orders with a specific status.
     */
    public function scopeStatus($query, $status)
    {
        return $query->where('status', $status);
    }

    /**
     * Scope a query to only include orders within a date range.
     */
    public function scopeBetweenDates($query, $startDate, $endDate)
    {
        return $query->whereBetween('created_at', [$startDate, $endDate]);
    }
}
