<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class CleanNotifications extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'notifications:clean 
                          {--days=30 : Number of days to keep notifications}
                          {--unread : Keep all unread notifications regardless of age}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Clean up old notifications from the database';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $days = $this->option('days');
        $keepUnread = $this->option('unread');
        $cutoffDate = Carbon::now()->subDays($days);

        $query = DB::table('notifications')
            ->where('created_at', '<', $cutoffDate);

        // If --unread flag is set, only delete read notifications
        if ($keepUnread) {
            $query->whereNotNull('read_at');
        }

        // Get count before deletion
        $count = $query->count();

        // Perform deletion
        $query->delete();

        $this->info("Deleted {$count} notifications older than {$days} days" . 
            ($keepUnread ? ' (excluding unread notifications)' : ''));

        // Log the cleanup
        activity()
            ->withProperties([
                'days' => $days,
                'keep_unread' => $keepUnread,
                'deleted_count' => $count,
                'cutoff_date' => $cutoffDate->toDateTimeString(),
            ])
            ->log('Notifications cleaned up');
    }
}
