@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>My Orders</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="{{ route('services.index') }}" class="btn btn-primary">
                <i class="fas fa-plus"></i> New Order
            </a>
        </div>
    </div>

    <div class="row mb-4">
        <!-- Order Statistics -->
        <div class="col-md-3">
            <div class="card bg-light">
                <div class="card-body text-center">
                    <h3>{{ $orders->where('status', 'pending')->count() }}</h3>
                    <p class="text-muted mb-0">Pending Orders</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-light">
                <div class="card-body text-center">
                    <h3>{{ $orders->where('status', 'in_progress')->count() }}</h3>
                    <p class="text-muted mb-0">In Progress</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-light">
                <div class="card-body text-center">
                    <h3>{{ $orders->where('status', 'completed')->count() }}</h3>
                    <p class="text-muted mb-0">Completed</p>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-light">
                <div class="card-body text-center">
                    <h3>{{ $orders->where('status', 'cancelled')->count() }}</h3>
                    <p class="text-muted mb-0">Cancelled</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    @if($orders->count() > 0)
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Service</th>
                                        <th>Status</th>
                                        <th>Price</th>
                                        <th>Created</th>
                                        <th>Last Updated</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($orders as $order)
                                        <tr>
                                            <td>#{{ $order->id }}</td>
                                            <td>{{ $order->service->name }}</td>
                                            <td>
                                                <span class="badge bg-{{ 
                                                    $order->status === 'pending' ? 'warning' : 
                                                    ($order->status === 'in_progress' ? 'info' : 
                                                    ($order->status === 'completed' ? 'success' : 
                                                    ($order->status === 'cancelled' ? 'danger' : 'secondary')))
                                                }}">
                                                    {{ ucfirst(str_replace('_', ' ', $order->status)) }}
                                                </span>
                                            </td>
                                            <td>
                                                @if($order->final_price)
                                                    ${{ number_format($order->final_price, 2) }}
                                                @elseif($order->counter_price)
                                                    <span class="text-warning">
                                                        ${{ number_format($order->counter_price, 2) }}
                                                        <small>(Counter)</small>
                                                    </span>
                                                @elseif($order->initial_price)
                                                    <span class="text-info">
                                                        ${{ number_format($order->initial_price, 2) }}
                                                        <small>(Offered)</small>
                                                    </span>
                                                @else
                                                    <span class="text-muted">Pending</span>
                                                @endif
                                            </td>
                                            <td>{{ $order->created_at->format('M d, Y') }}</td>
                                            <td>{{ $order->updated_at->diffForHumans() }}</td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="{{ route('orders.show', $order) }}" 
                                                       class="btn btn-sm btn-outline-primary">
                                                        View
                                                    </a>
                                                    @if(in_array($order->status, ['pending', 'price_offered', 'price_countered']))
                                                        <button type="button" 
                                                                class="btn btn-sm btn-outline-primary dropdown-toggle dropdown-toggle-split"
                                                                data-bs-toggle="dropdown">
                                                        </button>
                                                        <ul class="dropdown-menu">
                                                            @if($order->status === 'price_offered')
                                                                <li>
                                                                    <form action="{{ route('orders.accept-price', $order) }}" method="POST">
                                                                        @csrf
                                                                        <button type="submit" class="dropdown-item">
                                                                            Accept Price
                                                                        </button>
                                                                    </form>
                                                                </li>
                                                                <li>
                                                                    <a class="dropdown-item" href="#"
                                                                       data-bs-toggle="modal"
                                                                       data-bs-target="#counterOfferModal"
                                                                       data-order-id="{{ $order->id }}"
                                                                       data-initial-price="{{ $order->initial_price }}">
                                                                        Counter Offer
                                                                    </a>
                                                                </li>
                                                            @endif
                                                            <li>
                                                                <form action="{{ route('orders.cancel', $order) }}" method="POST">
                                                                    @csrf
                                                                    <button type="submit" 
                                                                            class="dropdown-item text-danger"
                                                                            onclick="return confirm('Are you sure you want to cancel this order?')">
                                                                        Cancel Order
                                                                    </button>
                                                                </form>
                                                            </li>
                                                        </ul>
                                                    @endif
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <div class="d-flex justify-content-center mt-4">
                            {{ $orders->links() }}
                        </div>
                    @else
                        <div class="text-center py-4">
                            <h4>No Orders Found</h4>
                            <p class="text-muted mb-3">You haven't placed any orders yet.</p>
                            <a href="{{ route('services.index') }}" class="btn btn-primary">
                                Browse Services
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Counter Offer Modal -->
<div class="modal fade" id="counterOfferModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="counterOfferForm" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Make Counter Offer</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Initial Price</label>
                        <input type="text" class="form-control" id="initialPrice" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="counter_price" class="form-label">Your Counter Offer</label>
                        <div class="input-group">
                            <span class="input-group-text">$</span>
                            <input type="number" 
                                   class="form-control @error('counter_price') is-invalid @enderror" 
                                   id="counter_price" 
                                   name="counter_price" 
                                   step="0.01" 
                                   min="0" 
                                   required>
                        </div>
                        @error('counter_price')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit Counter Offer</button>
                </div>
            </form>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const counterOfferModal = document.getElementById('counterOfferModal');
    if (counterOfferModal) {
        counterOfferModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const orderId = button.dataset.orderId;
            const initialPrice = button.dataset.initialPrice;
            
            const form = this.querySelector('#counterOfferForm');
            form.action = `/orders/${orderId}/counter-offer`;
            
            this.querySelector('#initialPrice').value = `$${parseFloat(initialPrice).toFixed(2)}`;
        });
    }
});
</script>
@endpush
@endsection
