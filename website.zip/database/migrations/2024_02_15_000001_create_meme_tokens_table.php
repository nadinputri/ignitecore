<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('meme_tokens', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('symbol');
            $table->string('contract_address');
            $table->string('network')->default('ethereum'); // ethereum, bsc, etc.
            $table->decimal('current_price', 30, 18)->nullable();
            $table->decimal('market_cap', 30, 2)->nullable();
            $table->integer('holder_count')->nullable();
            $table->json('dex_pairs')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            
            $table->unique(['contract_address', 'network']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('meme_tokens');
    }
};
