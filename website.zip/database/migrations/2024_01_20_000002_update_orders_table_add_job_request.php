<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('orders', function (Blueprint $table) {
            // Add status field with predefined states
            $table->enum('status', [
                'pending',
                'price_offered',
                'price_countered',
                'accepted',
                'in_progress',
                'completed',
                'cancelled'
            ])->default('pending')->after('service_id');

            // Add fields for price negotiation
            $table->decimal('initial_price', 10, 2)->nullable()->after('status');
            $table->decimal('counter_price', 10, 2)->nullable()->after('initial_price');
            $table->decimal('final_price', 10, 2)->nullable()->after('counter_price');
            
            // Add fields for job request details
            $table->text('requirements')->nullable()->after('final_price');
            $table->text('admin_notes')->nullable()->after('requirements');
            $table->text('client_notes')->nullable()->after('admin_notes');
            
            // Add timestamps for status changes
            $table->timestamp('price_offered_at')->nullable();
            $table->timestamp('price_countered_at')->nullable();
            $table->timestamp('accepted_at')->nullable();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamp('cancelled_at')->nullable();
        });
    }

    public function down()
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn([
                'status',
                'initial_price',
                'counter_price',
                'final_price',
                'requirements',
                'admin_notes',
                'client_notes',
                'price_offered_at',
                'price_countered_at',
                'accepted_at',
                'started_at',
                'completed_at',
                'cancelled_at'
            ]);
        });
    }
};
