import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from datetime import datetime, timedelta
import logging
from typing import List, Dict, Optional
from transformers import AutoTokenizer, AutoModel

logger = logging.getLogger(__name__)

class MarketAnalyzer:
    """Analyzes market data using ML models for trend prediction"""
    
    def __init__(self, model_path: str = "models/market_analyzer"):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = self._load_model(model_path)
        self.tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
        
    def _load_model(self, model_path: str) -> nn.Module:
        """Load the pre-trained model"""
        try:
            model = torch.load(model_path, map_location=self.device)
            model.eval()
            return model
        except Exception as e:
            logger.error(f"Failed to load model: {str(e)}")
            return None
            
    def analyze_price_movement(self, price_data: pd.DataFrame) -> Dict:
        """Analyze price movements and predict trends"""
        try:
            # Convert price data to tensors
            price_tensor = torch.tensor(
                price_data[['open', 'high', 'low', 'close', 'volume']].values,
                dtype=torch.float32,
                device=self.device
            )
            
            with torch.no_grad():
                prediction = self.model(price_tensor.unsqueeze(0))
                
            return {
                'trend': prediction[0].item(),
                'confidence': prediction[1].item(),
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error analyzing price movement: {str(e)}")
            return None
            
    def detect_patterns(self, price_data: pd.DataFrame) -> List[Dict]:
        """Detect technical analysis patterns in price data"""
        patterns = []
        try:
            # Calculate technical indicators
            price_data['SMA_20'] = price_data['close'].rolling(window=20).mean()
            price_data['SMA_50'] = price_data['close'].rolling(window=50).mean()
            price_data['RSI'] = self._calculate_rsi(price_data['close'])
            
            # Detect patterns
            patterns.extend(self._detect_support_resistance(price_data))
            patterns.extend(self._detect_trend_patterns(price_data))
            
            return patterns
            
        except Exception as e:
            logger.error(f"Error detecting patterns: {str(e)}")
            return []
            
    def _calculate_rsi(self, prices: pd.Series, periods: int = 14) -> pd.Series:
        """Calculate Relative Strength Index"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=periods).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=periods).mean()
        
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
        
    def _detect_support_resistance(self, data: pd.DataFrame) -> List[Dict]:
        """Detect support and resistance levels"""
        levels = []
        try:
            # Implementation of support/resistance detection
            window = 20
            for i in range(window, len(data)):
                section = data.iloc[i-window:i]
                current_price = data.iloc[i]['close']
                
                # Detect support
                if current_price == section['close'].min():
                    levels.append({
                        'type': 'support',
                        'price': current_price,
                        'timestamp': data.index[i]
                    })
                    
                # Detect resistance
                if current_price == section['close'].max():
                    levels.append({
                        'type': 'resistance',
                        'price': current_price,
                        'timestamp': data.index[i]
                    })
                    
            return levels
            
        except Exception as e:
            logger.error(f"Error detecting support/resistance: {str(e)}")
            return []
            
    def _detect_trend_patterns(self, data: pd.DataFrame) -> List[Dict]:
        """Detect trend patterns like double tops, head and shoulders, etc."""
        patterns = []
        try:
            # Implementation of trend pattern detection
            for i in range(len(data) - 1):
                # Example: Detect potential reversal patterns
                if data.iloc[i]['RSI'] > 70:
                    patterns.append({
                        'type': 'overbought',
                        'price': data.iloc[i]['close'],
                        'timestamp': data.index[i]
                    })
                elif data.iloc[i]['RSI'] < 30:
                    patterns.append({
                        'type': 'oversold',
                        'price': data.iloc[i]['close'],
                        'timestamp': data.index[i]
                    })
                    
            return patterns
            
        except Exception as e:
            logger.error(f"Error detecting trend patterns: {str(e)}")
            return []
            
    def analyze_sentiment(self, text_data: List[str]) -> Dict:
        """Analyze market sentiment from text data"""
        try:
            # Tokenize and encode text
            inputs = self.tokenizer(
                text_data,
                padding=True,
                truncation=True,
                max_length=512,
                return_tensors="pt"
            ).to(self.device)
            
            with torch.no_grad():
                outputs = self.model(**inputs)
                
            # Process sentiment scores
            sentiment_scores = torch.softmax(outputs.logits, dim=1)
            avg_sentiment = sentiment_scores.mean(dim=0)
            
            return {
                'bullish': avg_sentiment[0].item(),
                'neutral': avg_sentiment[1].item(),
                'bearish': avg_sentiment[2].item(),
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error analyzing sentiment: {str(e)}")
            return None
            
    def generate_report(self, price_data: pd.DataFrame, sentiment_data: List[str]) -> Dict:
        """Generate comprehensive market analysis report"""
        try:
            price_analysis = self.analyze_price_movement(price_data)
            patterns = self.detect_patterns(price_data)
            sentiment = self.analyze_sentiment(sentiment_data)
            
            return {
                'timestamp': datetime.now().isoformat(),
                'price_analysis': price_analysis,
                'technical_patterns': patterns,
                'sentiment_analysis': sentiment,
                'summary': self._generate_summary(price_analysis, patterns, sentiment)
            }
            
        except Exception as e:
            logger.error(f"Error generating report: {str(e)}")
            return None
            
    def _generate_summary(self, price_analysis: Dict, patterns: List[Dict], sentiment: Dict) -> str:
        """Generate a summary of the analysis"""
        try:
            # Implement summary generation logic
            summary = []
            
            if price_analysis:
                trend = "bullish" if price_analysis['trend'] > 0.5 else "bearish"
                summary.append(f"Price trend appears to be {trend} with {price_analysis['confidence']:.2%} confidence.")
                
            if patterns:
                pattern_summary = [p['type'] for p in patterns[-3:]]  # Last 3 patterns
                summary.append(f"Recent patterns detected: {', '.join(pattern_summary)}")
                
            if sentiment:
                dominant_sentiment = max(sentiment.items(), key=lambda x: x[1] if x[0] != 'timestamp' else -1)
                summary.append(f"Market sentiment is predominantly {dominant_sentiment[0]}")
                
            return " ".join(summary)
            
        except Exception as e:
            logger.error(f"Error generating summary: {str(e)}")
            return "Unable to generate summary due to an error."
