<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Carbon\Carbon;

class AccountSuspended extends Notification implements ShouldQueue
{
    use Queueable;

    protected $lastActive;
    protected $inactiveDays;

    /**
     * Create a new notification instance.
     */
    public function __construct(Carbon $lastActive, int $inactiveDays)
    {
        $this->lastActive = $lastActive;
        $this->inactiveDays = $inactiveDays;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail', 'database'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject('Account Suspended Due to Inactivity')
            ->greeting("Hello {$notifiable->name},")
            ->line("Your account has been suspended due to {$this->inactiveDays} days of inactivity. Your last activity was on " . $this->lastActive->format('M d, Y') . ".")
            ->line("For security reasons, we automatically suspend accounts that have been inactive for extended periods.")
            ->line("Your account will remain suspended for 30 days. During this time, you won't be able to:")
            ->line("• Place new orders")
            ->line("• Access your wallet")
            ->line("• Interact with support tickets")
            ->line("To reactivate your account, please contact our support team using the button below.")
            ->action('Contact Support', url('/support'))
            ->line("If you need immediate assistance, you can also email us at support@example.com")
            ->line("We value your membership and hope to see you active on our platform again soon.");
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            'title' => 'Account Suspended',
            'message' => "Your account has been suspended due to {$this->inactiveDays} days of inactivity.",
            'type' => 'account_suspended',
            'last_active' => $this->lastActive->toDateTimeString(),
            'inactive_days' => $this->inactiveDays,
            'suspended_until' => Carbon::now()->addDays(30)->toDateTimeString(),
            'action_text' => 'Contact Support',
            'action_url' => url('/support'),
        ];
    }
}
