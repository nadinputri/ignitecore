@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">{{ isset($bot) ? 'Edit Bot: ' . $bot->name : 'Create New Telegram Bot' }}</h4>
                </div>

                <div class="card-body">
                    @if(isset($bot))
                        <form action="{{ route('user.telegram-bots.update', $bot) }}" method="POST">
                        @method('PUT')
                    @else
                        <form action="{{ route('user.telegram-bots.store') }}" method="POST">
                    @endif
                        @csrf

                        <div class="mb-4">
                            <label for="name" class="form-label">Bot Name</label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" 
                                id="name" name="name" value="{{ old('name', $bot->name ?? '') }}" required>
                            @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div class="form-text">Choose a memorable name for your bot</div>
                        </div>

                        @unless(isset($bot))
                        <div class="mb-4">
                            <label for="bot_token" class="form-label">Bot Token</label>
                            <input type="text" class="form-control @error('bot_token') is-invalid @enderror" 
                                id="bot_token" name="bot_token" value="{{ old('bot_token') }}" required>
                            @error('bot_token')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <div class="form-text">
                                Get this from <a href="https://t.me/BotFather" target="_blank">@BotFather</a> on Telegram
                            </div>
                        </div>
                        @endunless

                        <div class="mb-4">
                            <label class="form-label">Memecoin Settings</label>
                            <div class="card bg-light">
                                <div class="card-body">
                                    <div class="mb-3">
                                        <label for="settings_network" class="form-label">Network</label>
                                        <select class="form-select @error('settings.network') is-invalid @enderror" 
                                            id="settings_network" name="settings[network]">
                                            <option value="ethereum" {{ old('settings.network', $bot->settings['network'] ?? '') === 'ethereum' ? 'selected' : '' }}>
                                                Ethereum
                                            </option>
                                            <option value="bsc" {{ old('settings.network', $bot->settings['network'] ?? '') === 'bsc' ? 'selected' : '' }}>
                                                Binance Smart Chain
                                            </option>
                                        </select>
                                    </div>

                                    <div class="mb-3">
                                        <label for="settings_trading_enabled" class="form-label d-flex align-items-center gap-2">
                                            <input type="checkbox" class="form-check-input" 
                                                id="settings_trading_enabled" name="settings[trading_enabled]" value="1"
                                                {{ old('settings.trading_enabled', $bot->settings['trading_enabled'] ?? false) ? 'checked' : '' }}>
                                            Enable Trading
                                        </label>
                                        <div class="form-text">Allow the bot to execute trades</div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="settings_max_slippage" class="form-label">Max Slippage (%)</label>
                                        <input type="number" class="form-control @error('settings.max_slippage') is-invalid @enderror" 
                                            id="settings_max_slippage" name="settings[max_slippage]" 
                                            value="{{ old('settings.max_slippage', $bot->settings['max_slippage'] ?? 5) }}"
                                            min="0.1" max="100" step="0.1">
                                    </div>

                                    <div class="mb-3">
                                        <label for="settings_gas_limit" class="form-label">Gas Limit</label>
                                        <input type="number" class="form-control @error('settings.gas_limit') is-invalid @enderror" 
                                            id="settings_gas_limit" name="settings[gas_limit]" 
                                            value="{{ old('settings.gas_limit', $bot->settings['gas_limit'] ?? 300000) }}"
                                            min="21000">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between">
                            <a href="{{ route('user.telegram-bots.index') }}" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Back
                            </a>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> {{ isset($bot) ? 'Update' : 'Create' }} Bot
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            @if(isset($bot))
            <div class="card mt-4">
                <div class="card-header bg-danger text-white">
                    <h4 class="mb-0">Danger Zone</h4>
                </div>
                <div class="card-body">
                    <form action="{{ route('user.telegram-bots.destroy', $bot) }}" method="POST" 
                        onsubmit="return confirm('Are you sure you want to delete this bot? This action cannot be undone.');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash"></i> Delete Bot
                        </button>
                    </form>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const tradingEnabled = document.getElementById('settings_trading_enabled');
        const slippageInput = document.getElementById('settings_max_slippage');
        const gasLimitInput = document.getElementById('settings_gas_limit');

        function updateFieldsState() {
            const isEnabled = tradingEnabled.checked;
            slippageInput.disabled = !isEnabled;
            gasLimitInput.disabled = !isEnabled;
        }

        tradingEnabled.addEventListener('change', updateFieldsState);
        updateFieldsState();
    });
</script>
@endpush
