# Testing Guide

## Overview

This guide covers testing practices and guidelines for IgniteHub. Following these standards ensures reliable code and consistent quality across the platform.

## Testing Structure 🏗️

### Test Types

1. **Unit Tests**
   - Individual components
   - Isolated functionality
   - No external dependencies
   - Fast execution

2. **Feature Tests**
   - End-to-end functionality
   - Integration points
   - Database interactions
   - API endpoints

3. **Browser Tests**
   - User interface
   - JavaScript functionality
   - Real browser simulation
   - Visual regression

## Writing Tests 📝

### Unit Tests

```php
class WalletTest extends TestCase
{
    /** @test */
    public function it_can_add_funds_to_wallet()
    {
        // Arrange
        $wallet = new Wallet();
        $amount = 100;

        // Act
        $wallet->addFunds($amount);

        // Assert
        $this->assertEquals($amount, $wallet->balance);
    }
}
```

### Feature Tests

```php
class OrderControllerTest extends TestCase
{
    /** @test */
    public function it_can_create_new_order()
    {
        // Arrange
        $user = User::factory()->create();
        $orderData = [
            'service_id' => 1,
            'amount' => 100
        ];

        // Act
        $response = $this->actingAs($user)
            ->postJson('/api/orders', $orderData);

        // Assert
        $response->assertStatus(201)
            ->assertJsonStructure(['id', 'status']);
    }
}
```

### Browser Tests

```php
class LoginTest extends DuskTestCase
{
    /** @test */
    public function it_can_login_user()
    {
        $this->browse(function (Browser $browser) {
            $browser->visit('/login')
                   ->type('email', 'test@example.com')
                   ->type('password', 'password')
                   ->press('Login')
                   ->assertPathIs('/dashboard');
        });
    }
}
```

## Test Organization 📂

### Directory Structure

```
tests/
├── Unit/
│   ├── Services/
│   ├── Models/
│   └── Helpers/
├── Feature/
│   ├── Controllers/
│   ├── API/
│   └── Commands/
└── Browser/
    ├── Pages/
    └── Components/
```

### Naming Conventions

1. **Test Classes**
   ```
   {Feature}Test.php
   {Action}Test.php
   ```

2. **Test Methods**
   ```
   it_can_{action}()
   it_cannot_{action}()
   it_should_{expectation}()
   ```

## Testing Tools 🛠️

### PHPUnit

1. **Running Tests**
   ```bash
   # Run all tests
   php artisan test

   # Run specific test
   php artisan test --filter=WalletTest

   # Run with coverage
   php artisan test --coverage
   ```

2. **Configuration**
   ```xml
   <phpunit>
       <testsuites>
           <testsuite name="Unit">
               <directory>tests/Unit</directory>
           </testsuite>
       </testsuites>
   </phpunit>
   ```

### Laravel Dusk

1. **Setup**
   ```bash
   # Install Dusk
   composer require --dev laravel/dusk

   # Generate browser test files
   php artisan dusk:install
   ```

2. **Running Browser Tests**
   ```bash
   php artisan dusk
   ```

## Best Practices 💡

### Test Structure

1. **Arrange-Act-Assert**
   ```php
   public function test_example()
   {
       // Arrange
       $data = $this->prepareData();

       // Act
       $result = $this->performAction($data);

       // Assert
       $this->assertEquals($expected, $result);
   }
   ```

2. **Test Independence**
   - Self-contained tests
   - No shared state
   - Clear setup/teardown
   - Isolated resources

### Testing Guidelines

✅ **Do:**
- Write descriptive test names
- Test edge cases
- Use meaningful assertions
- Keep tests focused

❌ **Don't:**
- Skip error cases
- Use magic numbers
- Write brittle tests
- Ignore failed tests

## Mocking & Stubs 🎭

### Mock Examples

```php
// Mock Service
$service = $this->mock(PaymentService::class);
$service->shouldReceive('process')
        ->once()
        ->andReturn(true);

// Mock HTTP Requests
Http::fake([
    'api.example.com/*' => Http::response(['status' => 'success'], 200)
]);
```

### Stub Examples

```php
// Stub Model
$user = $this->createStub(User::class);
$user->method('hasPermission')
     ->willReturn(true);

// Stub Time
Carbon::setTestNow('2024-01-01 12:00:00');
```

## Database Testing 🗄️

### Test Database

1. **Configuration**
   ```php
   // phpunit.xml
   <php>
       <env name="DB_CONNECTION" value="sqlite"/>
       <env name="DB_DATABASE" value=":memory:"/>
   </php>
   ```

2. **Migrations**
   ```php
   use RefreshDatabase;

   public function setUp(): void
   {
       parent::setUp();
       $this->artisan('migrate');
   }
   ```

### Factories

```php
// User Factory
User::factory()
    ->hasWallet()
    ->hasOrders(3)
    ->create();

// Custom States
Order::factory()
    ->paid()
    ->forUser($user)
    ->create();
```

## API Testing 🌐

### Request Testing

```php
class ApiTest extends TestCase
{
    /** @test */
    public function it_returns_correct_response()
    {
        $response = $this->getJson('/api/users');

        $response
            ->assertStatus(200)
            ->assertJsonStructure([
                'data' => [
                    '*' => ['id', 'name', 'email']
                ]
            ]);
    }
}
```

### Authentication Testing

```php
$this->actingAs($user, 'api')
     ->getJson('/api/protected-route')
     ->assertStatus(200);
```

## Performance Testing ⚡

### Load Testing

```bash
# Using k6
k6 run load-test.js

# Using Apache Benchmark
ab -n 1000 -c 10 http://localhost/api/endpoint
```

### Profiling

```php
// Using Laravel Debugbar
Debugbar::startMeasure('operation');
// ... code ...
Debugbar::stopMeasure('operation');
```

## Continuous Integration 🔄

### GitHub Actions

```yaml
name: Tests

on: [push, pull_request]

jobs:
  tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Run Tests
        run: |
          composer install
          php artisan test
```

### Test Coverage

```bash
# Generate coverage report
php artisan test --coverage-html coverage/
```

## Resources 📚

### Documentation

- [PHPUnit Documentation](https://phpunit.de/documentation.html)
- [Laravel Testing](https://laravel.com/docs/testing)
- [Dusk Documentation](https://laravel.com/docs/dusk)
- [Testing Best Practices](https://wiki.ignitehub.me/testing)

### Tools

- PHPUnit
- Laravel Dusk
- Laravel Debugbar
- Xdebug
- k6

---

Last updated: [Current Date]

⚠️ **Note:** Testing requirements may be updated. Check regularly for changes.

💡 **Need help?** Contact the development team through:
- Developer Discord
- GitHub Issues
- Technical Documentation
