@extends('layouts.admin')

@section('styles')
<style>
/* Terminal themes */
.theme-default {
    --bg-color: #1e1e1e;
    --text-color: #fff;
    --prompt-color: #00ff00;
    --output-color: #b0b0b0;
    --error-color: #ff5f56;
    --success-color: #27c93f;
    --header-bg: #2d2d2d;
}

.theme-light {
    --bg-color: #f0f0f0;
    --text-color: #333;
    --prompt-color: #0066cc;
    --output-color: #666;
    --error-color: #cc0000;
    --success-color: #008800;
    --header-bg: #e0e0e0;
}

.theme-matrix {
    --bg-color: #000;
    --text-color: #00ff00;
    --prompt-color: #00ff00;
    --output-color: #00cc00;
    --error-color: #ff0000;
    --success-color: #00ff00;
    --header-bg: #001100;
}

.theme-retro {
    --bg-color: #2b2b2b;
    --text-color: #ffa500;
    --prompt-color: #ffd700;
    --output-color: #ff8c00;
    --error-color: #ff4500;
    --success-color: #98fb98;
    --header-bg: #1a1a1a;
}

.theme-ocean {
    --bg-color: #1a1a2e;
    --text-color: #00ffff;
    --prompt-color: #00ffff;
    --output-color: #87ceeb;
    --error-color: #ff6b6b;
    --success-color: #00fa9a;
    --header-bg: #16162b;
}

.theme-forest {
    --bg-color: #1b2819;
    --text-color: #90ee90;
    --prompt-color: #98fb98;
    --output-color: #7ccd7c;
    --error-color: #ff6b6b;
    --success-color: #00ff00;
    --header-bg: #1a2517;
}

.terminal-container {
    background-color: var(--bg-color);
    border-radius: 6px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    margin: 20px 0;
    position: relative;
    height: 600px;
    display: flex;
    flex-direction: column;
}

.terminal-header {
    background-color: var(--header-bg);
    border-radius: 6px 6px 0 0;
    padding: 8px 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.terminal-title {
    color: var(--text-color);
    font-size: 14px;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 8px;
}

.terminal-controls {
    display: flex;
    gap: 15px;
    align-items: center;
}

.terminal-theme-selector {
    background-color: var(--header-bg);
    color: var(--text-color);
    border: 1px solid var(--text-color);
    border-radius: 4px;
    padding: 2px 8px;
}

.terminal-buttons {
    display: flex;
    gap: 8px;
}

.terminal-button {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    cursor: pointer;
    transition: opacity 0.2s;
}

.terminal-button:hover {
    opacity: 0.8;
}

.terminal-close { background-color: #ff5f56; }
.terminal-minimize { background-color: #ffbd2e; }
.terminal-maximize { background-color: #27c93f; }

.terminal-body {
    background-color: var(--bg-color);
    color: var(--text-color);
    font-family: 'Fira Code', 'Courier New', monospace;
    font-size: 14px;
    line-height: 1.5;
    padding: 15px;
    flex-grow: 1;
    overflow-y: auto;
    white-space: pre-wrap;
    position: relative;
}

.terminal-input-line {
    display: flex;
    margin: 4px 0;
    align-items: flex-start;
}

.terminal-prompt {
    color: var(--prompt-color);
    margin-right: 8px;
    user-select: none;
}

.terminal-input {
    background: transparent;
    border: none;
    color: var(--text-color);
    flex-grow: 1;
    font-family: inherit;
    font-size: inherit;
    outline: none;
    min-height: 20px;
}

.terminal-output {
    color: var(--output-color);
    margin: 4px 0;
}

.terminal-error {
    color: var(--error-color);
}

.terminal-success {
    color: var(--success-color);
}

.terminal-help {
    color: var(--prompt-color);
}

.terminal-cursor {
    animation: blink 1s step-end infinite;
    background-color: var(--text-color);
    display: inline-block;
    width: 8px;
    height: 15px;
    vertical-align: middle;
    margin-left: 2px;
}

@keyframes blink {
    0%, 100% { opacity: 1; }
    50% { opacity: 0; }
}

.terminal-body::-webkit-scrollbar {
    width: 8px;
}

.terminal-body::-webkit-scrollbar-track {
    background: var(--header-bg);
}

.terminal-body::-webkit-scrollbar-thumb {
    background: var(--output-color);
    border-radius: 4px;
}

.terminal-body::-webkit-scrollbar-thumb:hover {
    background: var(--text-color);
}

.terminal-suggestions {
    background-color: var(--header-bg);
    border: 1px solid var(--output-color);
    border-radius: 4px;
    margin-top: 4px;
    padding: 4px;
    position: absolute;
    z-index: 1000;
}

.terminal-suggestion {
    color: var(--text-color);
    cursor: pointer;
    padding: 2px 8px;
    transition: background-color 0.2s;
}

.terminal-suggestion:hover {
    background-color: var(--bg-color);
}

.terminal-footer {
    background-color: var(--header-bg);
    border-radius: 0 0 6px 6px;
    padding: 8px 15px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 12px;
    color: var(--output-color);
}

.terminal-stats {
    display: flex;
    gap: 15px;
}

.terminal-stat {
    display: flex;
    align-items: center;
    gap: 5px;
}

.terminal-shortcuts {
    display: flex;
    gap: 15px;
}

.terminal-shortcut {
    display: flex;
    align-items: center;
    gap: 5px;
}

.terminal-shortcut kbd {
    background-color: var(--bg-color);
    border: 1px solid var(--output-color);
    border-radius: 3px;
    padding: 1px 4px;
    font-size: 11px;
}

/* Matrix theme animation */
.theme-matrix .terminal-body::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(0deg, rgba(0,255,0,0.1) 0%, transparent 50%);
    pointer-events: none;
    animation: matrix-scan 2s linear infinite;
}

@keyframes matrix-scan {
    from { transform: translateY(-100%); }
    to { transform: translateY(100%); }
}

/* Loading animation */
.terminal-loading {
    display: inline-block;
    margin-left: 5px;
}

.terminal-loading::after {
    content: '';
    animation: loading 1s steps(4) infinite;
}

@keyframes loading {
    0% { content: ''; }
    25% { content: '.'; }
    50% { content: '..'; }
    75% { content: '...'; }
}
</style>
@endsection

@section('content')
<div class="container-fluid px-4">
    <h1 class="mt-4">Terminal</h1>
    
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-terminal me-1"></i>
            System Terminal
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-1"></i>
                Type 'help' to see available commands. Enhanced features include system analysis, monitoring, and AI-powered suggestions.
            </div>

            <div class="terminal-container theme-default" id="terminal-container">
                <div class="terminal-header">
                    <div class="terminal-buttons">
                        <div class="terminal-button terminal-close" title="Close"></div>
                        <div class="terminal-button terminal-minimize" title="Minimize"></div>
                        <div class="terminal-button terminal-maximize" title="Maximize"></div>
                    </div>
                    <div class="terminal-title">
                        <i class="fas fa-terminal"></i>
                        <span>ignitehub-terminal</span>
                    </div>
                    <div class="terminal-controls">
                        <select class="terminal-theme-selector" id="theme-selector">
                            @foreach($themes as $key => $name)
                                <option value="{{ $key }}">{{ $name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="terminal-body" id="terminal"></div>
                <div class="terminal-footer">
                    <div class="terminal-stats">
                        <div class="terminal-stat">
                            <i class="fas fa-microchip"></i>
                            <span id="cpu-usage">0%</span>
                        </div>
                        <div class="terminal-stat">
                            <i class="fas fa-memory"></i>
                            <span id="memory-usage">0MB</span>
                        </div>
                        <div class="terminal-stat">
                            <i class="fas fa-hdd"></i>
                            <span id="disk-usage">0%</span>
                        </div>
                    </div>
                    <div class="terminal-shortcuts">
                        @foreach($shortcuts as $key => $description)
                            <div class="terminal-shortcut" title="{{ $description }}">
                                <kbd>{{ $key }}</kbd>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const terminal = document.getElementById('terminal');
    const container = document.getElementById('terminal-container');
    const themeSelector = document.getElementById('theme-selector');
    let commandHistory = [];
    let historyIndex = -1;
    let suggestions = @json($allowedCommands);
    let customCommands = @json(array_keys($customCommands));
    suggestions = suggestions.concat(customCommands);

    // Theme handling
    themeSelector.addEventListener('change', function() {
        container.className = 'terminal-container theme-' + this.value;
        localStorage.setItem('terminal-theme', this.value);
    });

    // Load saved theme
    const savedTheme = localStorage.getItem('terminal-theme');
    if (savedTheme) {
        themeSelector.value = savedTheme;
        container.className = 'terminal-container theme-' + savedTheme;
    }

    // System stats update
    function updateStats() {
        fetch('{{ route("admin.terminal.execute") }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}'
            },
            body: JSON.stringify({ command: 'monitor' })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const metrics = JSON.parse(data.output);
                document.getElementById('cpu-usage').textContent = Math.round(metrics.cpu * 100) / 100 + '%';
                document.getElementById('memory-usage').textContent = Math.round(metrics.memory / 1024 / 1024) + 'MB';
                document.getElementById('disk-usage').textContent = Math.round((1 - metrics.disk / metrics.disk_total) * 100) + '%';
            }
        });
    }

    // Update stats every 5 seconds
    setInterval(updateStats, 5000);
    updateStats();

    // Terminal functionality
    function createInputLine() {
        const line = document.createElement('div');
        line.className = 'terminal-input-line';
        
        const prompt = document.createElement('span');
        prompt.className = 'terminal-prompt';
        prompt.textContent = '{{ auth()->user()->name }}@ignitehub:$ ';
        
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'terminal-input';
        input.autocomplete = 'off';
        
        line.appendChild(prompt);
        line.appendChild(input);
        terminal.appendChild(line);
        
        input.focus();
        return input;
    }

    // ... (rest of the JavaScript code remains the same)
});
</script>
@endsection
