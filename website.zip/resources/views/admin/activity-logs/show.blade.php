@extends('layouts.admin')

@section('content')
<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="mt-4">Activity Log Details</h1>
        <a href="{{ route('admin.activity-logs.index') }}" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Back to List
        </a>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-info-circle me-1"></i>
            Log Information
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-3">
                    <strong>Date:</strong>
                </div>
                <div class="col-md-9">
                    {{ $log->formatted_date }}
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3">
                    <strong>User:</strong>
                </div>
                <div class="col-md-9">
                    @if($log->user)
                        {{ $log->user->name }} ({{ $log->user->email }})
                    @else
                        System
                    @endif
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3">
                    <strong>Event:</strong>
                </div>
                <div class="col-md-9">
                    <span class="badge bg-{{ $log->event === 'deleted' ? 'danger' : ($log->event === 'created' ? 'success' : 'info') }}">
                        {{ $log->event_label }}
                    </span>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3">
                    <strong>Model:</strong>
                </div>
                <div class="col-md-9">
                    {{ class_basename($log->model_type) }} (ID: {{ $log->model_id }})
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3">
                    <strong>Description:</strong>
                </div>
                <div class="col-md-9">
                    {{ $log->description }}
                </div>
            </div>

            @if($log->properties)
                <div class="row mb-3">
                    <div class="col-md-3">
                        <strong>Changes:</strong>
                    </div>
                    <div class="col-md-9">
                        @if(isset($log->properties['changed']))
                            <div class="table-responsive">
                                <table class="table table-sm table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Field</th>
                                            <th>Old Value</th>
                                            <th>New Value</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($log->properties['changed'] as $field => $value)
                                            <tr>
                                                <td>{{ $field }}</td>
                                                <td>{{ $log->properties['old'][$field] ?? 'N/A' }}</td>
                                                <td>{{ $value }}</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        @else
                            <pre class="bg-light p-3 rounded">{{ json_encode($log->properties, JSON_PRETTY_PRINT) }}</pre>
                        @endif
                    </div>
                </div>
            @endif

            <div class="row mb-3">
                <div class="col-md-3">
                    <strong>IP Address:</strong>
                </div>
                <div class="col-md-9">
                    {{ $log->ip_address }}
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3">
                    <strong>User Agent:</strong>
                </div>
                <div class="col-md-9">
                    <small class="text-muted">{{ $log->user_agent }}</small>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
