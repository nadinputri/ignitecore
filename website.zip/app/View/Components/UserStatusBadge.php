<?php

namespace App\View\Components;

use Illuminate\View\Component;
use App\Models\User;

class UserStatusBadge extends Component
{
    /**
     * The user instance.
     *
     * @var \App\Models\User
     */
    public $user;

    /**
     * Whether to show detailed information.
     *
     * @var bool
     */
    public $detailed;

    /**
     * Create a new component instance.
     *
     * @param  \App\Models\User  $user
     * @param  bool  $detailed
     * @return void
     */
    public function __construct(User $user, $detailed = false)
    {
        $this->user = $user;
        $this->detailed = $detailed;
    }

    /**
     * Get the status badge color class.
     *
     * @return string
     */
    public function getBadgeClass()
    {
        if ($this->user->isBanned()) {
            return 'bg-danger';
        }

        if ($this->user->isSuspended()) {
            return 'bg-warning text-dark';
        }

        return match($this->user->status) {
            'active' => $this->user->isOnline() ? 'bg-success' : 'bg-secondary',
            'inactive' => 'bg-secondary',
            default => 'bg-secondary'
        };
    }

    /**
     * Get the status text.
     *
     * @return string
     */
    public function getStatusText()
    {
        if ($this->user->isBanned()) {
            return 'Banned';
        }

        if ($this->user->isSuspended()) {
            return 'Suspended';
        }

        if ($this->user->status === 'active' && $this->user->isOnline()) {
            return 'Online';
        }

        return ucfirst($this->user->status);
    }

    /**
     * Get the view / contents that represent the component.
     *
     * @return \Illuminate\Contracts\View\View|\Closure|string
     */
    public function render()
    {
        return view('components.user-status-badge');
    }
}
