<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use App\Services\UserService;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class CleanInactiveUsers extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'users:clean-inactive 
                          {--days=90 : Number of days of inactivity before marking user as inactive}
                          {--suspend=180 : Number of days of inactivity before suspending user}
                          {--notify : Send notification to users before marking them inactive}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Clean up inactive users and update their status';

    /**
     * The user service instance.
     *
     * @var \App\Services\UserService
     */
    protected $userService;

    /**
     * Create a new command instance.
     *
     * @param  \App\Services\UserService  $userService
     * @return void
     */
    public function __construct(UserService $userService)
    {
        parent::__construct();
        $this->userService = $userService;
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $inactiveDays = $this->option('days');
        $suspendDays = $this->option('suspend');
        $shouldNotify = $this->option('notify');

        $this->info("Starting inactive users cleanup...");
        $this->info("Inactive threshold: {$inactiveDays} days");
        $this->info("Suspension threshold: {$suspendDays} days");

        $inactiveDate = Carbon::now()->subDays($inactiveDays);
        $suspendDate = Carbon::now()->subDays($suspendDays);

        // Process users who need inactivity warnings
        if ($shouldNotify) {
            $this->processInactivityWarnings();
        }

        // Process users to be marked as inactive
        $inactiveCount = $this->processInactiveUsers($inactiveDate);

        // Process users to be suspended
        $suspendedCount = $this->processSuspendedUsers($suspendDate);

        // Log the cleanup results
        Log::info('Inactive users cleanup completed', [
            'inactive_threshold' => $inactiveDays,
            'suspend_threshold' => $suspendDays,
            'users_marked_inactive' => $inactiveCount,
            'users_suspended' => $suspendedCount,
        ]);

        $this->info("Marked {$inactiveCount} users as inactive");
        $this->info("Suspended {$suspendedCount} users");

        if ($shouldNotify) {
            $this->info('Notifications have been sent to affected users');
        }
    }

    /**
     * Process users who need inactivity warnings.
     *
     * @return int
     */
    protected function processInactivityWarnings()
    {
        $warningCount = 0;

        User::where('status', 'active')
            ->whereNull('banned_at')
            ->whereNull('suspended_until')
            ->chunk(100, function ($users) use (&$warningCount) {
                foreach ($users as $user) {
                    if ($this->userService->needsInactivityWarning($user)) {
                        if ($this->userService->sendInactivityWarning($user)) {
                            $warningCount++;
                        }
                    }
                }
            });

        $this->info("Sent {$warningCount} inactivity warnings");
        return $warningCount;
    }

    /**
     * Process users to be marked as inactive.
     *
     * @param  \Carbon\Carbon  $inactiveDate
     * @return int
     */
    protected function processInactiveUsers($inactiveDate)
    {
        $inactiveCount = 0;

        User::where(function ($query) use ($inactiveDate) {
            $query->whereNull('last_active_at')
                ->orWhere('last_active_at', '<', $inactiveDate);
        })
        ->where('status', 'active')
        ->whereNull('banned_at')
        ->whereNull('suspended_until')
        ->chunk(100, function ($users) use (&$inactiveCount) {
            foreach ($users as $user) {
                if ($this->userService->markAsInactive($user)) {
                    $inactiveCount++;
                }
            }
        });

        return $inactiveCount;
    }

    /**
     * Process users to be suspended.
     *
     * @param  \Carbon\Carbon  $suspendDate
     * @return int
     */
    protected function processSuspendedUsers($suspendDate)
    {
        $suspendedCount = 0;

        User::where(function ($query) use ($suspendDate) {
            $query->whereNull('last_active_at')
                ->orWhere('last_active_at', '<', $suspendDate);
        })
        ->where('status', 'inactive')
        ->whereNull('banned_at')
        ->whereNull('suspended_until')
        ->chunk(100, function ($users) use (&$suspendedCount) {
            foreach ($users as $user) {
                if ($this->userService->suspend($user)) {
                    $suspendedCount++;
                }
            }
        });

        return $suspendedCount;
    }
}
