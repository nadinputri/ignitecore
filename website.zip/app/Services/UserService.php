<?php

namespace App\Services;

use App\Models\User;
use App\Models\SupportTicket;
use App\Notifications\AccountInactivityWarning;
use App\Notifications\AccountSuspended;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;

class UserService
{
    /**
     * Mark a user as inactive.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function markAsInactive(User $user)
    {
        try {
            $user->update([
                'status' => 'inactive',
            ]);

            activity()
                ->performedOn($user)
                ->withProperties([
                    'last_active' => $user->last_active_at?->format('Y-m-d H:i:s'),
                    'days_inactive' => config('users.activity.inactive_after'),
                ])
                ->log('User marked as inactive');

            return true;
        } catch (\Exception $e) {
            Log::error('Failed to mark user as inactive', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }

    /**
     * Suspend a user account.
     *
     * @param  \App\Models\User  $user
     * @param  int  $days
     * @return bool
     */
    public function suspend(User $user, $days = null)
    {
        try {
            $days = $days ?? config('users.activity.suspension_duration', 30);
            
            $user->update([
                'suspended_until' => Carbon::now()->addDays($days),
            ]);

            // Create support ticket if configured
            if (config('users.support.auto_ticket_on_suspend', true)) {
                $this->createSuspensionSupportTicket($user, $days);
            }

            activity()
                ->performedOn($user)
                ->withProperties([
                    'suspended_until' => $user->suspended_until->format('Y-m-d H:i:s'),
                    'days' => $days,
                ])
                ->log('User account suspended');

            return true;
        } catch (\Exception $e) {
            Log::error('Failed to suspend user', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }

    /**
     * Ban a user account.
     *
     * @param  \App\Models\User  $user
     * @param  string  $reason
     * @return bool
     */
    public function ban(User $user, $reason = null)
    {
        try {
            $user->update([
                'status' => 'banned',
                'banned_at' => now(),
            ]);

            activity()
                ->performedOn($user)
                ->withProperties([
                    'reason' => $reason,
                ])
                ->log('User account banned');

            return true;
        } catch (\Exception $e) {
            Log::error('Failed to ban user', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }

    /**
     * Reactivate a user account.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function reactivate(User $user)
    {
        try {
            $user->update([
                'status' => config('users.status.default', 'active'),
                'suspended_until' => null,
                'banned_at' => null,
            ]);

            activity()
                ->performedOn($user)
                ->log('User account reactivated');

            return true;
        } catch (\Exception $e) {
            Log::error('Failed to reactivate user', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }

    /**
     * Send inactivity warning to user.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function sendInactivityWarning(User $user)
    {
        try {
            $user->notify(new AccountInactivityWarning(
                $user->last_active_at ?? $user->created_at,
                config('users.activity.inactive_after')
            ));

            activity()
                ->performedOn($user)
                ->log('Inactivity warning sent to user');

            return true;
        } catch (\Exception $e) {
            Log::error('Failed to send inactivity warning', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }

    /**
     * Create a support ticket for suspended user.
     *
     * @param  \App\Models\User  $user
     * @param  int  $days
     * @return \App\Models\SupportTicket|null
     */
    protected function createSuspensionSupportTicket(User $user, $days)
    {
        try {
            return SupportTicket::create([
                'user_id' => $user->id,
                'title' => 'Account Suspended Due to Inactivity',
                'description' => "Your account has been suspended for {$days} days due to inactivity. " .
                               "Please contact support to reactivate your account.",
                'priority' => 'medium',
                'status' => 'open',
                'type' => 'account_suspension',
            ]);
        } catch (\Exception $e) {
            Log::error('Failed to create suspension support ticket', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return null;
        }
    }

    /**
     * Update user's last activity timestamp.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function updateLastActivity(User $user)
    {
        try {
            $user->update([
                'last_active_at' => now(),
            ]);

            return true;
        } catch (\Exception $e) {
            Log::error('Failed to update user last activity', [
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }

    /**
     * Check if user needs an inactivity warning.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function needsInactivityWarning(User $user)
    {
        if (!$user->last_active_at) {
            return false;
        }

        $warnAfter = config('users.activity.inactive_after') - 
                     config('users.activity.notify_days_before', 7);

        return $user->last_active_at->addDays($warnAfter)->isPast() &&
               $user->status === 'active';
    }
}
