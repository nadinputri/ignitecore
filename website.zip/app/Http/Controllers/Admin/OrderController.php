<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\OrderService;
use Illuminate\Http\Request;
use Exception;

class OrderController extends Controller
{
    protected $orderService;

    public function __construct(OrderService $orderService)
    {
        $this->middleware(['auth', 'admin']);
        $this->orderService = $orderService;
    }

    /**
     * Display a listing of orders.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $query = Order::with(['user', 'service']);

        // Filter by status
        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        // Search by order ID or user
        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('id', 'like', "%{$search}%")
                    ->orWhereHas('user', function ($q) use ($search) {
                        $q->where('name', 'like', "%{$search}%")
                            ->orWhere('email', 'like', "%{$search}%");
                    });
            });
        }

        $orders = $query->latest()->paginate(15);

        return view('admin.orders.index', compact('orders'));
    }

    /**
     * Show the form for creating a new order.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        $users = \App\Models\User::where('is_admin', false)->get();
        $services = \App\Models\Service::where('active', true)->get();

        return view('admin.orders.create', compact('users', 'services'));
    }

    /**
     * Store a newly created order in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
            'service_id' => 'required|exists:services,id',
            'requirements' => 'required|string|min:10',
            'initial_price' => 'required|numeric|min:0'
        ]);

        try {
            $user = \App\Models\User::findOrFail($validated['user_id']);
            $service = \App\Models\Service::findOrFail($validated['service_id']);

            $order = $this->orderService->createOrder($user, $service, [
                'requirements' => $validated['requirements']
            ]);

            // Immediately set the initial price since this is created by admin
            $this->orderService->offerPrice($order, $validated['initial_price']);

            return redirect()
                ->route('admin.orders.show', $order)
                ->with('success', 'Order created and price offered successfully.');
        } catch (Exception $e) {
            return back()
                ->withInput()
                ->with('error', 'Failed to create order. ' . $e->getMessage());
        }
    }

    /**
     * Display the specified order.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\View\View
     */
    public function show(Order $order)
    {
        $order->load(['user', 'service', 'transactions']);
        
        return view('admin.orders.show', compact('order'));
    }

    /**
     * Update the order status.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\RedirectResponse
     */
    public function updateStatus(Request $request, Order $order)
    {
        $validated = $request->validate([
            'status' => 'required|in:pending,in_progress,completed,cancelled'
        ]);

        try {
            switch ($validated['status']) {
                case 'in_progress':
                    $this->orderService->startWork($order);
                    break;
                case 'completed':
                    $this->orderService->completeOrder($order);
                    break;
                case 'cancelled':
                    $this->orderService->cancelOrder($order);
                    break;
            }

            return redirect()
                ->route('admin.orders.show', $order)
                ->with('success', 'Order status updated successfully.');
        } catch (Exception $e) {
            return back()
                ->with('error', 'Failed to update order status. ' . $e->getMessage());
        }
    }

    /**
     * Offer or update price for the order.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\RedirectResponse
     */
    public function offerPrice(Request $request, Order $order)
    {
        $validated = $request->validate([
            'price' => 'required|numeric|min:0'
        ]);

        try {
            $this->orderService->offerPrice($order, $validated['price']);

            return redirect()
                ->route('admin.orders.show', $order)
                ->with('success', 'Price offered successfully.');
        } catch (Exception $e) {
            return back()
                ->with('error', 'Failed to offer price. ' . $e->getMessage());
        }
    }

    /**
     * Process refund for the order.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\RedirectResponse
     */
    public function refund(Request $request, Order $order)
    {
        $validated = $request->validate([
            'reason' => 'required|string|min:10'
        ]);

        try {
            $this->orderService->refundOrder($order, $validated['reason']);

            return redirect()
                ->route('admin.orders.show', $order)
                ->with('success', 'Order refunded successfully.');
        } catch (Exception $e) {
            return back()
                ->with('error', 'Failed to process refund. ' . $e->getMessage());
        }
    }
}
