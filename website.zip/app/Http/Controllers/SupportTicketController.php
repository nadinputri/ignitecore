<?php

namespace App\Http\Controllers;

use App\Models\SupportTicket;
use App\Models\SupportTicketReply;
use App\Models\SupportTicketAttachment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class SupportTicketController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'verified']);
    }

    public function index()
    {
        $tickets = Auth::user()->supportTickets()
            ->with(['replies' => function ($query) {
                $query->latest()->limit(1);
            }])
            ->latest()
            ->paginate(10);

        return view('user.support.index', compact('tickets'));
    }

    public function create()
    {
        return view('user.support.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'subject' => 'required|string|max:255',
            'description' => 'required|string',
            'priority' => 'required|in:low,medium,high',
            'attachments.*' => 'nullable|file|max:10240' // 10MB max per file
        ]);

        $ticket = Auth::user()->supportTickets()->create([
            'subject' => $validated['subject'],
            'description' => $validated['description'],
            'priority' => $validated['priority'],
            'status' => 'open'
        ]);

        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {
                $path = $file->store('support-tickets/' . $ticket->id);
                
                $ticket->attachments()->create([
                    'filename' => $file->getClientOriginalName(),
                    'path' => $path,
                    'mime_type' => $file->getMimeType(),
                    'size' => $file->getSize()
                ]);
            }
        }

        return redirect()
            ->route('support-tickets.show', $ticket)
            ->with('success', 'Support ticket created successfully.');
    }

    public function show(SupportTicket $ticket)
    {
        $this->authorize('view', $ticket);

        $ticket->load(['replies.user', 'replies.attachments', 'attachments']);

        return view('user.support.show', compact('ticket'));
    }

    public function reply(Request $request, SupportTicket $ticket)
    {
        $this->authorize('reply', $ticket);

        $validated = $request->validate([
            'message' => 'required|string',
            'attachments.*' => 'nullable|file|max:10240'
        ]);

        $reply = $ticket->replies()->create([
            'user_id' => Auth::id(),
            'message' => $validated['message'],
            'is_admin_reply' => false
        ]);

        if ($request->hasFile('attachments')) {
            foreach ($request->file('attachments') as $file) {
                $path = $file->store('support-tickets/' . $ticket->id . '/replies');
                
                $reply->attachments()->create([
                    'ticket_id' => $ticket->id,
                    'filename' => $file->getClientOriginalName(),
                    'path' => $path,
                    'mime_type' => $file->getMimeType(),
                    'size' => $file->getSize()
                ]);
            }
        }

        return redirect()
            ->route('support-tickets.show', $ticket)
            ->with('success', 'Reply added successfully.');
    }

    public function downloadAttachment(SupportTicketAttachment $attachment)
    {
        $this->authorize('download', $attachment);

        return Storage::download(
            $attachment->path,
            $attachment->filename
        );
    }

    public function close(SupportTicket $ticket)
    {
        $this->authorize('update', $ticket);

        $ticket->markAsClosed();

        return redirect()
            ->route('support-tickets.show', $ticket)
            ->with('success', 'Ticket closed successfully.');
    }

    public function reopen(SupportTicket $ticket)
    {
        $this->authorize('update', $ticket);

        $ticket->reopen();

        return redirect()
            ->route('support-tickets.show', $ticket)
            ->with('success', 'Ticket reopened successfully.');
    }
}
