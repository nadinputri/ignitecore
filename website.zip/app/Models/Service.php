<?php

namespace App\Models;

use App\Traits\LogsActivity;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    use HasFactory, LogsActivity;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'description',
        'price',
        'active',
        'category_id'
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'price' => 'decimal:2',
        'active' => 'boolean',
    ];

    /**
     * Get the category that owns the service.
     */
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    /**
     * Get the orders for the service.
     */
    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    /**
     * Scope a query to only include active services.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    public function scopeActive($query)
    {
        return $query->where('active', true);
    }

    /**
     * Format the price with currency symbol.
     *
     * @return string
     */
    public function getFormattedPriceAttribute()
    {
        return '$' . number_format($this->price, 2);
    }

    /**
     * Get the service's status label.
     *
     * @return string
     */
    public function getStatusLabelAttribute()
    {
        return $this->active ? 'Active' : 'Inactive';
    }

    /**
     * Get the service's status class for UI.
     *
     * @return string
     */
    public function getStatusClassAttribute()
    {
        return $this->active ? 'success' : 'danger';
    }

    /**
     * Check if the service can be deleted.
     *
     * @return bool
     */
    public function canBeDeleted()
    {
        return !$this->orders()->exists();
    }

    /**
     * Get the activity description for the service.
     * Override the default description from LogsActivity trait.
     *
     * @param string $event
     * @return string
     */
    protected function getActivityDescription(string $event): string
    {
        return match ($event) {
            'created' => "Service '{$this->name}' was created with price {$this->formatted_price}",
            'updated' => "Service '{$this->name}' was updated",
            'deleted' => "Service '{$this->name}' was deleted",
            default => parent::getActivityDescription($event),
        };
    }

    /**
     * Get the properties to be logged.
     * Override the default properties from LogsActivity trait.
     *
     * @return array
     */
    protected function getActivityProperties(): array
    {
        $properties = $this->getAttributes();
        
        // Remove sensitive or unnecessary data
        unset($properties['created_at'], $properties['updated_at']);
        
        // Add formatted values
        $properties['formatted_price'] = $this->formatted_price;
        $properties['status'] = $this->status_label;
        
        if ($this->category) {
            $properties['category_name'] = $this->category->name;
        }

        return $properties;
    }

    /**
     * Determine if the model should log activity.
     * Override the default condition from LogsActivity trait.
     *
     * @return bool
     */
    protected function shouldLogActivity(): bool
    {
        // Always log service changes as they are critical to the business
        return true;
    }
}
