<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Log;

class SqlInjectionProtection
{
    /**
     * Known SQL injection patterns
     *
     * @var array
     */
    protected $patterns = [
        '/\bUNION\b/i',
        '/\bSELECT\b.*\bFROM\b/i',
        '/\bINSERT\b.*\bINTO\b/i',
        '/\bUPDATE\b.*\bSET\b/i',
        '/\bDELETE\b.*\bFROM\b/i',
        '/\bDROP\b.*\bTABLE\b/i',
        '/\bTRUNCATE\b.*\bTABLE\b/i',
        '/\bALTER\b.*\bTABLE\b/i',
        '/\bEXEC\b.*\bsp_/i',
        '/\bXP_\b/i'
    ];

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $input = $request->all();
        
        try {
            array_walk_recursive($input, function(&$value) use ($request) {
                if (is_string($value)) {
                    // Check for SQL injection patterns
                    foreach ($this->patterns as $pattern) {
                        if (preg_match($pattern, $value)) {
                            // Log the attempt
                            Log::channel('security')->warning('Potential SQL injection attempt', [
                                'ip' => $request->ip(),
                                'path' => $request->path(),
                                'input' => $value,
                                'pattern' => $pattern
                            ]);

                            abort(403, 'Invalid input detected');
                        }
                    }

                    // Remove potentially dangerous characters
                    $value = preg_replace('/[;\'"]/', '', $value);
                    
                    // Apply basic sanitization
                    $value = strip_tags($value);
                    $value = htmlspecialchars($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                }
            });

            $request->merge($input);
            
            return $next($request);
        } catch (\Exception $e) {
            Log::channel('security')->error('Error in SQL injection protection', [
                'error' => $e->getMessage(),
                'ip' => $request->ip(),
                'path' => $request->path()
            ]);

            abort(403, 'Invalid input detected');
        }
    }
}
