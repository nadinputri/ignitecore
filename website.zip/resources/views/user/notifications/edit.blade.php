@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Notification Preferences</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="{{ route('notification-preferences.index') }}" class="btn btn-outline-secondary">
                <i class="fas fa-bell"></i> View Notifications
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <form action="{{ route('notification-preferences.update') }}" method="POST">
                        @csrf

                        <!-- Order Notifications -->
                        <div class="mb-4">
                            <h5>Order Notifications</h5>
                            <div class="list-group">
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1">Order Status Updates</h6>
                                            <p class="text-muted mb-0 small">Receive notifications when your order status changes</p>
                                        </div>
                                        <div class="form-check form-switch">
                                            <input type="checkbox" 
                                                   class="form-check-input" 
                                                   name="preferences[order_status_email]" 
                                                   id="order_status_email"
                                                   {{ $preferences['order_status_email'] ? 'checked' : '' }}>
                                            <label class="form-check-label" for="order_status_email">Email</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1">Price Updates</h6>
                                            <p class="text-muted mb-0 small">Receive notifications about price offers and changes</p>
                                        </div>
                                        <div class="form-check form-switch">
                                            <input type="checkbox" 
                                                   class="form-check-input" 
                                                   name="preferences[price_updates_email]" 
                                                   id="price_updates_email"
                                                   {{ $preferences['price_updates_email'] ? 'checked' : '' }}>
                                            <label class="form-check-label" for="price_updates_email">Email</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Support Ticket Notifications -->
                        <div class="mb-4">
                            <h5>Support Ticket Notifications</h5>
                            <div class="list-group">
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1">Ticket Updates</h6>
                                            <p class="text-muted mb-0 small">Receive notifications about your support tickets</p>
                                        </div>
                                        <div class="form-check form-switch">
                                            <input type="checkbox" 
                                                   class="form-check-input" 
                                                   name="preferences[support_ticket_email]" 
                                                   id="support_ticket_email"
                                                   {{ $preferences['support_ticket_email'] ? 'checked' : '' }}>
                                            <label class="form-check-label" for="support_ticket_email">Email</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Wallet Notifications -->
                        <div class="mb-4">
                            <h5>Wallet Notifications</h5>
                            <div class="list-group">
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            <h6 class="mb-1">Balance Updates</h6>
                                            <p class="text-muted mb-0 small">Receive notifications about your wallet balance changes</p>
                                        </div>
                                        <div class="form-check form-switch">
                                            <input type="checkbox" 
                                                   class="form-check-input" 
                                                   name="preferences[wallet_updates_email]" 
                                                   id="wallet_updates_email"
                                                   {{ $preferences['wallet_updates_email'] ? 'checked' : '' }}>
                                            <label class="form-check-label" for="wallet_updates_email">Email</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary">
                                Save Preferences
                            </button>
                            <a href="{{ route('notification-preferences.index') }}" class="btn btn-outline-secondary">
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">About Notifications</h5>
                    <p class="card-text">
                        Customize how you receive notifications about your orders, support tickets, and wallet activities.
                    </p>
                    <hr>
                    <h6>Email Notifications</h6>
                    <p class="card-text">
                        Email notifications will be sent to: <strong>{{ Auth::user()->email }}</strong>
                    </p>
                    <p class="text-muted small">
                        To change your email address, please update it in your profile settings.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

@push('styles')
<style>
.form-switch {
    padding-left: 2.5em;
}
.form-switch .form-check-input {
    width: 3em;
}
.list-group-item {
    transition: background-color 0.3s;
}
.list-group-item:hover {
    background-color: #f8f9fa;
}
</style>
@endpush
@endsection
