import numpy as np
import pandas as pd
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from .market_analyzer import MarketAnalyzer
from .pump_dump_detector import PumpDumpDetector

logger = logging.getLogger(__name__)

class TradingStrategy:
    """Implements trading strategies for meme coins"""
    
    def __init__(self,
                 risk_level: str = "medium",
                 max_position_size: float = 0.1,
                 stop_loss_pct: float = 0.05,
                 take_profit_pct: float = 0.15):
        """
        Initialize trading strategy
        
        Args:
            risk_level: Risk tolerance (low, medium, high)
            max_position_size: Maximum position size as fraction of portfolio
            stop_loss_pct: Stop loss percentage
            take_profit_pct: Take profit percentage
        """
        self.risk_level = risk_level
        self.max_position_size = max_position_size
        self.stop_loss_pct = stop_loss_pct
        self.take_profit_pct = take_profit_pct
        
        self.market_analyzer = MarketAnalyzer()
        self.pump_detector = PumpDumpDetector()
        
        # Strategy parameters based on risk level
        self._set_risk_parameters()
        
    def _set_risk_parameters(self):
        """Set strategy parameters based on risk level"""
        if self.risk_level == "low":
            self.volume_threshold = 3.0
            self.price_threshold = 0.05
            self.trend_confirmation_periods = 24
        elif self.risk_level == "medium":
            self.volume_threshold = 2.0
            self.price_threshold = 0.03
            self.trend_confirmation_periods = 12
        else:  # high risk
            self.volume_threshold = 1.5
            self.price_threshold = 0.02
            self.trend_confirmation_periods = 6
            
    def analyze_opportunity(self,
                          token_data: pd.DataFrame,
                          market_data: Optional[pd.DataFrame] = None) -> Dict:
        """
        Analyze trading opportunity
        
        Args:
            token_data: Historical price/volume data for the token
            market_data: Optional market-wide data for context
            
        Returns:
            Dictionary containing analysis results and recommendations
        """
        try:
            # Get market analysis
            market_analysis = self.market_analyzer.analyze_price_movement(token_data)
            
            # Check for pump and dump patterns
            pump_dump_analysis = self.pump_detector.analyze_token(
                token_data[['open', 'high', 'low', 'close']],
                token_data[['volume']]
            )
            
            # Calculate technical indicators
            indicators = self._calculate_indicators(token_data)
            
            # Generate trading signals
            signals = self._generate_signals(
                market_analysis,
                pump_dump_analysis,
                indicators
            )
            
            return {
                'timestamp': datetime.now().isoformat(),
                'market_analysis': market_analysis,
                'risk_analysis': pump_dump_analysis,
                'technical_indicators': indicators,
                'signals': signals,
                'recommendation': self._generate_recommendation(signals)
            }
            
        except Exception as e:
            logger.error(f"Error analyzing opportunity: {str(e)}")
            return None
            
    def _calculate_indicators(self, data: pd.DataFrame) -> Dict:
        """Calculate technical indicators"""
        try:
            # Moving averages
            data['SMA_20'] = data['close'].rolling(window=20).mean()
            data['SMA_50'] = data['close'].rolling(window=50).mean()
            data['EMA_20'] = data['close'].ewm(span=20).mean()
            
            # RSI
            delta = data['close'].diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
            rs = gain / loss
            data['RSI'] = 100 - (100 / (1 + rs))
            
            # MACD
            exp1 = data['close'].ewm(span=12).mean()
            exp2 = data['close'].ewm(span=26).mean()
            data['MACD'] = exp1 - exp2
            data['Signal_Line'] = data['MACD'].ewm(span=9).mean()
            
            # Bollinger Bands
            data['BB_middle'] = data['close'].rolling(window=20).mean()
            std = data['close'].rolling(window=20).std()
            data['BB_upper'] = data['BB_middle'] + (std * 2)
            data['BB_lower'] = data['BB_middle'] - (std * 2)
            
            return {
                'current_price': data['close'].iloc[-1],
                'sma_20': data['SMA_20'].iloc[-1],
                'sma_50': data['SMA_50'].iloc[-1],
                'ema_20': data['EMA_20'].iloc[-1],
                'rsi': data['RSI'].iloc[-1],
                'macd': data['MACD'].iloc[-1],
                'macd_signal': data['Signal_Line'].iloc[-1],
                'bb_upper': data['BB_upper'].iloc[-1],
                'bb_middle': data['BB_middle'].iloc[-1],
                'bb_lower': data['BB_lower'].iloc[-1]
            }
            
        except Exception as e:
            logger.error(f"Error calculating indicators: {str(e)}")
            return {}
            
    def _generate_signals(self,
                         market_analysis: Dict,
                         risk_analysis: Dict,
                         indicators: Dict) -> Dict:
        """Generate trading signals based on analysis"""
        try:
            signals = {
                'trend': self._analyze_trend(indicators),
                'momentum': self._analyze_momentum(indicators),
                'volatility': self._analyze_volatility(indicators),
                'risk': self._analyze_risk(risk_analysis),
                'overall': 'neutral'
            }
            
            # Weight the signals based on risk level
            weights = self._get_signal_weights()
            score = (
                weights['trend'] * self._signal_to_score(signals['trend']) +
                weights['momentum'] * self._signal_to_score(signals['momentum']) +
                weights['volatility'] * self._signal_to_score(signals['volatility']) +
                weights['risk'] * self._signal_to_score(signals['risk'])
            )
            
            # Convert score to overall signal
            if score > 0.6:
                signals['overall'] = 'strong_buy'
            elif score > 0.2:
                signals['overall'] = 'buy'
            elif score < -0.6:
                signals['overall'] = 'strong_sell'
            elif score < -0.2:
                signals['overall'] = 'sell'
                
            return signals
            
        except Exception as e:
            logger.error(f"Error generating signals: {str(e)}")
            return {}
            
    def _analyze_trend(self, indicators: Dict) -> str:
        """Analyze price trend"""
        try:
            price = indicators['current_price']
            sma_20 = indicators['sma_20']
            sma_50 = indicators['sma_50']
            
            if price > sma_20 and sma_20 > sma_50:
                return 'strong_uptrend'
            elif price > sma_20:
                return 'uptrend'
            elif price < sma_20 and sma_20 < sma_50:
                return 'strong_downtrend'
            elif price < sma_20:
                return 'downtrend'
            else:
                return 'neutral'
                
        except Exception as e:
            logger.error(f"Error analyzing trend: {str(e)}")
            return 'neutral'
            
    def _analyze_momentum(self, indicators: Dict) -> str:
        """Analyze price momentum"""
        try:
            rsi = indicators['rsi']
            macd = indicators['macd']
            macd_signal = indicators['macd_signal']
            
            if rsi > 70 and macd < macd_signal:
                return 'strong_sell'
            elif rsi < 30 and macd > macd_signal:
                return 'strong_buy'
            elif rsi > 60:
                return 'sell'
            elif rsi < 40:
                return 'buy'
            else:
                return 'neutral'
                
        except Exception as e:
            logger.error(f"Error analyzing momentum: {str(e)}")
            return 'neutral'
            
    def _analyze_volatility(self, indicators: Dict) -> str:
        """Analyze price volatility"""
        try:
            price = indicators['current_price']
            bb_upper = indicators['bb_upper']
            bb_lower = indicators['bb_lower']
            
            if price > bb_upper:
                return 'sell'
            elif price < bb_lower:
                return 'buy'
            else:
                return 'neutral'
                
        except Exception as e:
            logger.error(f"Error analyzing volatility: {str(e)}")
            return 'neutral'
            
    def _analyze_risk(self, risk_analysis: Dict) -> str:
        """Analyze risk level"""
        try:
            risk_score = risk_analysis.get('risk_score', 0.5)
            pattern_type = risk_analysis.get('pattern_type', 'normal_trading')
            
            if risk_score > 0.8:
                return 'strong_sell'
            elif risk_score > 0.6:
                return 'sell'
            elif risk_score < 0.2 and pattern_type == 'normal_trading':
                return 'buy'
            elif risk_score < 0.4 and pattern_type == 'normal_trading':
                return 'neutral'
            else:
                return 'neutral'
                
        except Exception as e:
            logger.error(f"Error analyzing risk: {str(e)}")
            return 'neutral'
            
    def _get_signal_weights(self) -> Dict[str, float]:
        """Get signal weights based on risk level"""
        if self.risk_level == "low":
            return {
                'trend': 0.4,
                'momentum': 0.2,
                'volatility': 0.1,
                'risk': 0.3
            }
        elif self.risk_level == "medium":
            return {
                'trend': 0.3,
                'momentum': 0.3,
                'volatility': 0.2,
                'risk': 0.2
            }
        else:  # high risk
            return {
                'trend': 0.2,
                'momentum': 0.4,
                'volatility': 0.3,
                'risk': 0.1
            }
            
    def _signal_to_score(self, signal: str) -> float:
        """Convert signal to numerical score"""
        scores = {
            'strong_buy': 1.0,
            'buy': 0.5,
            'neutral': 0.0,
            'sell': -0.5,
            'strong_sell': -1.0
        }
        return scores.get(signal, 0.0)
        
    def _generate_recommendation(self, signals: Dict) -> Dict:
        """Generate trading recommendation"""
        try:
            overall_signal = signals['overall']
            
            if overall_signal in ['strong_buy', 'buy']:
                position_size = self.max_position_size
                if overall_signal == 'buy':
                    position_size *= 0.5
                    
                return {
                    'action': 'buy',
                    'position_size': position_size,
                    'stop_loss': self.stop_loss_pct,
                    'take_profit': self.take_profit_pct,
                    'confidence': 'high' if overall_signal == 'strong_buy' else 'medium'
                }
                
            elif overall_signal in ['strong_sell', 'sell']:
                return {
                    'action': 'sell',
                    'position_size': 1.0,  # Sell entire position
                    'confidence': 'high' if overall_signal == 'strong_sell' else 'medium'
                }
                
            else:
                return {
                    'action': 'hold',
                    'confidence': 'low'
                }
                
        except Exception as e:
            logger.error(f"Error generating recommendation: {str(e)}")
            return {
                'action': 'hold',
                'confidence': 'low',
                'error': str(e)
            }
            
    def calculate_position_size(self,
                              portfolio_value: float,
                              risk_per_trade: float) -> float:
        """
        Calculate appropriate position size
        
        Args:
            portfolio_value: Total portfolio value
            risk_per_trade: Maximum risk per trade as percentage
            
        Returns:
            Recommended position size in base currency
        """
        try:
            # Calculate base position size
            base_size = portfolio_value * self.max_position_size
            
            # Adjust for risk per trade
            risk_adjusted_size = (portfolio_value * risk_per_trade) / self.stop_loss_pct
            
            # Take the minimum of the two calculations
            position_size = min(base_size, risk_adjusted_size)
            
            # Apply additional risk level adjustments
            if self.risk_level == "low":
                position_size *= 0.7
            elif self.risk_level == "high":
                position_size *= 1.2
                
            return round(position_size, 2)
            
        except Exception as e:
            logger.error(f"Error calculating position size: {str(e)}")
            return 0.0
