<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\LlmSetting;
use App\Services\LlmService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Process;
use Illuminate\Support\Facades\Storage;

class LlmSettingController extends Controller
{
    protected $llmService;
    protected $settings;

    public function __construct(LlmService $llmService)
    {
        $this->llmService = $llmService;
        $this->settings = LlmSetting::getConfig();
    }

    /**
     * Display LLM settings page
     */
    public function index()
    {
        $metrics = Cache::remember('llm_metrics', 60, function () {
            return $this->llmService->getMetrics();
        });

        $models = get_llm_model_info();

        return view('admin.llm-settings.index', [
            'settings' => $this->settings,
            'metrics' => $metrics,
            'models' => $models
        ]);
    }

    /**
     * Update LLM settings
     */
    public function update(Request $request)
    {
        $validated = $request->validate([
            'model_name' => 'required|string|in:llama2,mistral',
            'model_size' => 'required|string|in:7B,13B,70B',
            'model_variant' => 'required|string|in:chat,instruct,base',
            'quantization' => 'required|string|in:4-bit,8-bit,none',
            'batch_size' => 'required|integer|min:1|max:128',
            'threads' => 'required|integer|min:1|max:32',
            'gpu_layers' => 'required|integer|min:-1',
            'context_window' => 'required|integer|min:512|max:8192',
            'max_tokens' => 'required|integer|min:1|max:4096',
            'temperature' => 'required|numeric|min:0|max:2',
            'max_requests_per_minute' => 'required|integer|min:1',
            'content_filtering' => 'boolean',
            'blocked_words' => 'nullable|string',
            'monitoring_enabled' => 'boolean',
            'log_requests' => 'boolean',
            'log_responses' => 'boolean',
            'log_errors' => 'boolean'
        ]);

        // Convert blocked words string to array
        if (isset($validated['blocked_words'])) {
            $validated['blocked_words'] = array_map('trim', explode(',', $validated['blocked_words']));
        }

        // Update settings
        if (!$this->settings->updateSettings($validated)) {
            return back()->with('error', 'Failed to update settings. Please check system requirements.');
        }

        return back()->with('success', 'Settings updated successfully.');
    }

    /**
     * Download model
     */
    public function download(Request $request)
    {
        $validated = $request->validate([
            'model_name' => 'required|string|in:llama2,mistral',
            'model_size' => 'required|string|in:7B,13B,70B',
            'model_variant' => 'required|string|in:chat,instruct,base'
        ]);

        try {
            // Check system requirements
            if (!$this->llmService->checkSystemRequirements($validated['model_size'])) {
                return response()->json([
                    'status' => 'error',
                    'message' => 'System requirements not met for this model size.'
                ], 400);
            }

            // Start download process
            $process = Process::timeout(3600)->start(implode(' ', [
                config('llm.python.path'),
                config('llm.python.scripts_dir') . '/download_model.py',
                "--model={$validated['model_name']}",
                "--size={$validated['model_size']}",
                "--variant={$validated['model_variant']}",
                "--output=" . config('llm.defaults.model_path')
            ]));

            // Cache process ID for status checks
            Cache::put('llm_download_pid', $process->id(), now()->addHour());

            return response()->json(['status' => 'started']);

        } catch (\Exception $e) {
            Log::error('Model download failed: ' . $e->getMessage());
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Check download status
     */
    public function downloadStatus()
    {
        $pid = Cache::get('llm_download_pid');
        if (!$pid) {
            return response()->json(['status' => 'unknown']);
        }

        try {
            $process = Process::running($pid);
            
            if ($process) {
                return response()->json(['status' => 'running']);
            }

            Cache::forget('llm_download_pid');
            return response()->json(['status' => 'completed']);

        } catch (\Exception $e) {
            Cache::forget('llm_download_pid');
            return response()->json([
                'status' => 'failed',
                'error' => $e->getMessage()
            ]);
        }
    }

    /**
     * Cancel download
     */
    public function cancelDownload()
    {
        $pid = Cache::get('llm_download_pid');
        if (!$pid) {
            return response()->json(['status' => 'not_found']);
        }

        try {
            Process::kill($pid);
            Cache::forget('llm_download_pid');
            return response()->json(['status' => 'cancelled']);

        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Test model
     */
    public function test()
    {
        try {
            $response = $this->llmService->generateResponse(
                'Hello! Please respond with a short greeting.',
                ['max_tokens' => 50]
            );

            return response()->json([
                'success' => true,
                'response' => $response
            ]);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Display logs
     */
    public function logs(Request $request)
    {
        $type = $request->get('type', 'requests');
        $date = $request->get('date', now()->format('Y-m-d'));

        $logPath = storage_path("logs/llm/llm-{$date}.log");
        $logs = [];

        if (file_exists($logPath)) {
            $content = file_get_contents($logPath);
            $lines = explode("\n", $content);

            foreach ($lines as $line) {
                if (empty($line)) continue;

                $log = json_decode($line, true);
                if (!$log) continue;

                if ($type === 'requests' && isset($log['message']) && $log['message'] === 'Generated response') {
                    $logs[] = $log;
                } elseif ($type === 'errors' && isset($log['level']) && $log['level'] === 'error') {
                    $logs[] = $log;
                }
            }
        }

        return view('admin.llm-settings.logs', [
            'logs' => $logs,
            'type' => $type,
            'date' => $date
        ]);
    }

    /**
     * Clear logs
     */
    public function clearLogs(Request $request)
    {
        $type = $request->input('type', 'all');

        if ($type === 'all') {
            Storage::deleteDirectory('logs/llm');
        } else {
            $files = Storage::files('logs/llm');
            foreach ($files as $file) {
                $content = Storage::get($file);
                $lines = explode("\n", $content);
                $newLines = [];

                foreach ($lines as $line) {
                    if (empty($line)) continue;

                    $log = json_decode($line, true);
                    if (!$log) continue;

                    if ($type === 'requests' && (!isset($log['message']) || $log['message'] !== 'Generated response')) {
                        $newLines[] = $line;
                    } elseif ($type === 'errors' && (!isset($log['level']) || $log['level'] !== 'error')) {
                        $newLines[] = $line;
                    }
                }

                if (!empty($newLines)) {
                    Storage::put($file, implode("\n", $newLines));
                } else {
                    Storage::delete($file);
                }
            }
        }

        return back()->with('success', 'Logs cleared successfully.');
    }
}
