@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Notifications</h2>
        </div>
        <div class="col-md-4 text-end">
            <div class="btn-group">
                <a href="{{ route('notification-preferences.edit') }}" class="btn btn-outline-primary">
                    <i class="fas fa-cog"></i> Preferences
                </a>
                <form action="{{ route('notification-preferences.mark-all-read') }}" method="POST" class="d-inline">
                    @csrf
                    <button type="submit" class="btn btn-outline-primary">
                        <i class="fas fa-check-double"></i> Mark All Read
                    </button>
                </form>
                <form action="{{ route('notification-preferences.clear-all') }}" method="POST" class="d-inline">
                    @csrf
                    <button type="submit" class="btn btn-outline-danger" 
                            onclick="return confirm('Are you sure you want to clear all notifications?')">
                        <i class="fas fa-trash"></i> Clear All
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    @if($notifications->count() > 0)
                        <div class="list-group">
                            @foreach($notifications as $notification)
                                <div class="list-group-item list-group-item-action {{ $notification->read_at ? '' : 'bg-light' }}">
                                    <div class="d-flex w-100 justify-content-between align-items-center">
                                        <h6 class="mb-1">
                                            @if(!$notification->read_at)
                                                <span class="badge bg-primary">New</span>
                                            @endif
                                            {{ $notification->data['title'] ?? 'Notification' }}
                                        </h6>
                                        <small class="text-muted">{{ $notification->created_at->diffForHumans() }}</small>
                                    </div>
                                    <p class="mb-1">{{ $notification->data['message'] ?? '' }}</p>
                                    <div class="mt-2">
                                        <div class="btn-group">
                                            @if(isset($notification->data['action_url']))
                                                <a href="{{ $notification->data['action_url'] }}" 
                                                   class="btn btn-sm btn-primary">
                                                    {{ $notification->data['action_text'] ?? 'View' }}
                                                </a>
                                            @endif
                                            @if(!$notification->read_at)
                                                <form action="{{ route('notification-preferences.mark-read', $notification->id) }}" 
                                                      method="POST" 
                                                      class="d-inline">
                                                    @csrf
                                                    <button type="submit" class="btn btn-sm btn-outline-primary">
                                                        Mark as Read
                                                    </button>
                                                </form>
                                            @endif
                                            <form action="{{ route('notification-preferences.destroy', $notification->id) }}" 
                                                  method="POST" 
                                                  class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" 
                                                        class="btn btn-sm btn-outline-danger"
                                                        onclick="return confirm('Are you sure you want to delete this notification?')">
                                                    Delete
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>

                        <div class="d-flex justify-content-center mt-4">
                            {{ $notifications->links() }}
                        </div>
                    @else
                        <div class="text-center py-4">
                            <h4>No Notifications</h4>
                            <p class="text-muted mb-0">You don't have any notifications at the moment.</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('styles')
<style>
.list-group-item {
    transition: background-color 0.3s;
}
.list-group-item:hover {
    background-color: #f8f9fa;
}
</style>
@endpush
