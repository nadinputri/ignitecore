<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Service;
use App\Services\OrderService;
use App\Http\Requests\OrderStoreRequest;
use App\Http\Requests\OrderCounterOfferRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Exception;

class OrderController extends Controller
{
    protected $orderService;

    public function __construct(OrderService $orderService)
    {
        $this->middleware(['auth', 'verified']);
        $this->orderService = $orderService;
    }

    /**
     * Display a listing of the user's orders.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $orders = Auth::user()->orders()
            ->with('service')
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('user.orders.index', compact('orders'));
    }

    /**
     * Show the form for creating a new order.
     *
     * @param  \App\Models\Service  $service
     * @return \Illuminate\View\View
     */
    public function create(Service $service)
    {
        return view('user.orders.create', compact('service'));
    }

    /**
     * Store a newly created order in storage.
     *
     * @param  \App\Http\Requests\OrderStoreRequest  $request
     * @param  \App\Models\Service  $service
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(OrderStoreRequest $request, Service $service)
    {
        try {
            $order = $this->orderService->createOrder(
                Auth::user(),
                $service,
                $request->validated()
            );

            return redirect()
                ->route('orders.show', $order)
                ->with('success', 'Order created successfully! We will review and provide a price quote soon.');
        } catch (Exception $e) {
            return back()
                ->withInput()
                ->with('error', 'Failed to create order. ' . $e->getMessage());
        }
    }

    /**
     * Display the specified order.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\View\View
     */
    public function show(Order $order)
    {
        $this->authorize('view', $order);
        
        $order->load(['service', 'transactions']);
        
        return view('user.orders.show', compact('order'));
    }

    /**
     * Submit a counter offer for the order.
     *
     * @param  \App\Http\Requests\OrderCounterOfferRequest  $request
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\RedirectResponse
     */
    public function counterOffer(OrderCounterOfferRequest $request, Order $order)
    {
        try {
            $this->orderService->counterOffer($order, $request->counter_price);

            return redirect()
                ->route('orders.show', $order)
                ->with('success', 'Counter offer submitted successfully.');
        } catch (Exception $e) {
            return back()
                ->with('error', 'Failed to submit counter offer. ' . $e->getMessage());
        }
    }

    /**
     * Accept the offered price for the order.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\RedirectResponse
     */
    public function acceptPrice(Order $order)
    {
        $this->authorize('acceptPrice', $order);

        try {
            $this->orderService->acceptPrice($order);

            return redirect()
                ->route('orders.show', $order)
                ->with('success', 'Price accepted and payment processed successfully.');
        } catch (Exception $e) {
            return back()
                ->with('error', 'Failed to accept price. ' . $e->getMessage());
        }
    }

    /**
     * Cancel the order.
     *
     * @param  \App\Models\Order  $order
     * @return \Illuminate\Http\RedirectResponse
     */
    public function cancel(Order $order)
    {
        $this->authorize('cancel', $order);

        try {
            $this->orderService->cancelOrder($order);

            return redirect()
                ->route('orders.show', $order)
                ->with('success', 'Order cancelled successfully.');
        } catch (Exception $e) {
            return back()
                ->with('error', 'Failed to cancel order. ' . $e->getMessage());
        }
    }
}
