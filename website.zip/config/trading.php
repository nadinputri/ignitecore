<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Trading Configuration
    |--------------------------------------------------------------------------
    |
    | This file contains the configuration settings for the trading functionality
    | including blockchain networks, DEX settings, and trading parameters.
    |
    */

    // Blockchain Network Settings
    'networks' => [
        'ethereum' => [
            'rpc_url' => env('ETH_RPC_URL', 'https://mainnet.infura.io/v3/your-project-id'),
            'chain_id' => env('ETH_CHAIN_ID', 1),
            'explorer' => env('ETH_EXPLORER', 'https://etherscan.io'),
        ],
        'bsc' => [
            'rpc_url' => env('BSC_RPC_URL', 'https://bsc-dataseed.binance.org'),
            'chain_id' => env('BSC_CHAIN_ID', 56),
            'explorer' => env('BSC_EXPLORER', 'https://bscscan.com'),
        ],
    ],

    // DEX Router Addresses
    'dex_routers' => [
        'uniswap_v2' => env('UNISWAP_V2_ROUTER', '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D'),
        'pancakeswap' => env('PANCAKESWAP_ROUTER', '0x10ED43C718714eb63d5aA57B78B54704E256024E'),
    ],

    // Trading Parameters
    'max_slippage' => env('MAX_SLIPPAGE', 5), // Maximum allowed slippage in percentage
    'max_gas_price' => env('MAX_GAS_PRICE', 500), // Maximum gas price in GWEI
    'min_liquidity' => env('MIN_LIQUIDITY', 10000), // Minimum liquidity in USD
    'min_volume' => env('MIN_VOLUME', 5000), // Minimum 24h volume in USD

    // Token Safety Checks
    'max_buy_tax' => env('MAX_BUY_TAX', 10), // Maximum buy tax percentage
    'max_sell_tax' => env('MAX_SELL_TAX', 10), // Maximum sell tax percentage
    'min_holders' => env('MIN_HOLDERS', 100), // Minimum number of holders

    // AI Analysis Settings
    'analysis' => [
        'sentiment_threshold' => env('SENTIMENT_THRESHOLD', 0.6), // Minimum positive sentiment score
        'social_weight' => env('SOCIAL_WEIGHT', 0.3), // Weight of social metrics in analysis
        'technical_weight' => env('TECHNICAL_WEIGHT', 0.4), // Weight of technical analysis
        'risk_weight' => env('RISK_WEIGHT', 0.3), // Weight of risk assessment
    ],

    // API Keys for External Services
    'api_keys' => [
        'etherscan' => env('ETHERSCAN_API_KEY'),
        'bscscan' => env('BSCSCAN_API_KEY'),
        'twitter' => env('TWITTER_API_KEY'),
        'reddit' => env('REDDIT_API_KEY'),
        'telegram' => env('TELEGRAM_API_KEY'),
    ],

    // Monitoring Settings
    'monitoring' => [
        'price_alert_threshold' => env('PRICE_ALERT_THRESHOLD', 5), // Percentage change for price alerts
        'volume_alert_threshold' => env('VOLUME_ALERT_THRESHOLD', 100), // Percentage change for volume alerts
        'update_interval' => env('MONITOR_UPDATE_INTERVAL', 60), // Update interval in seconds
    ],

    // Trading Strategies
    'strategies' => [
        'snipe' => [
            'max_wait_time' => env('SNIPE_MAX_WAIT_TIME', 300), // Maximum time to wait for snipe in seconds
            'min_initial_liquidity' => env('SNIPE_MIN_LIQUIDITY', 5000), // Minimum initial liquidity in USD
            'max_gas_multiplier' => env('SNIPE_GAS_MULTIPLIER', 1.5), // Gas price multiplier for sniping
        ],
        'dca' => [
            'interval' => env('DCA_INTERVAL', 3600), // DCA interval in seconds
            'max_positions' => env('DCA_MAX_POSITIONS', 5), // Maximum number of DCA positions
        ],
    ],

    // Risk Management
    'risk_management' => [
        'max_position_size' => env('MAX_POSITION_SIZE', 0.1), // Maximum position size as fraction of portfolio
        'stop_loss' => env('DEFAULT_STOP_LOSS', 0.2), // Default stop loss percentage
        'take_profit' => env('DEFAULT_TAKE_PROFIT', 0.5), // Default take profit percentage
    ],

    // News Sources
    'news_sources' => [
        'twitter' => [
            'enabled' => true,
            'update_interval' => 300, // 5 minutes
            'min_followers' => 1000,
        ],
        'reddit' => [
            'enabled' => true,
            'update_interval' => 600, // 10 minutes
            'subreddits' => ['CryptoMoonShots', 'CryptoCurrency', 'SatoshiStreetBets'],
        ],
        'telegram' => [
            'enabled' => true,
            'update_interval' => 300, // 5 minutes
            'channels' => [], // Add default channels here
        ],
    ],
];
