<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ActivityLog;
use Illuminate\Http\Request;

class ActivityLogController extends Controller
{
    /**
     * Create a new controller instance.
     */
    public function __construct()
    {
        $this->middleware(['auth', 'admin']);
    }

    /**
     * Display a listing of activity logs.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $query = ActivityLog::with('user')
            ->latest();

        // Filter by event type
        if ($request->has('event')) {
            $query->forEvent($request->event);
        }

        // Filter by model type
        if ($request->has('model_type')) {
            $query->where('model_type', $request->model_type);
        }

        // Filter by user
        if ($request->has('user_id')) {
            $query->forUser($request->user_id);
        }

        // Filter by date range
        if ($request->has('from_date')) {
            $query->whereDate('created_at', '>=', $request->from_date);
        }
        if ($request->has('to_date')) {
            $query->whereDate('created_at', '<=', $request->to_date);
        }

        $logs = $query->paginate(20)
            ->withQueryString();

        // Get unique event types and model types for filters
        $eventTypes = ActivityLog::distinct()
            ->pluck('event')
            ->sort()
            ->values();

        $modelTypes = ActivityLog::distinct()
            ->pluck('model_type')
            ->map(function ($type) {
                return [
                    'value' => $type,
                    'label' => class_basename($type),
                ];
            })
            ->sortBy('label')
            ->values();

        return view('admin.activity-logs.index', compact(
            'logs',
            'eventTypes',
            'modelTypes'
        ));
    }

    /**
     * Display the specified activity log.
     *
     * @param  \App\Models\ActivityLog  $log
     * @return \Illuminate\View\View
     */
    public function show(ActivityLog $log)
    {
        $log->load('user');

        return view('admin.activity-logs.show', compact('log'));
    }

    /**
     * Clear old activity logs.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function clear(Request $request)
    {
        $request->validate([
            'days' => 'required|integer|min:1',
        ]);

        $date = now()->subDays($request->days);
        $count = ActivityLog::where('created_at', '<', $date)->delete();

        return redirect()
            ->route('admin.activity-logs.index')
            ->with('success', "{$count} old activity logs have been cleared.");
    }

    /**
     * Export activity logs to CSV.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Symfony\Component\HttpFoundation\StreamedResponse
     */
    public function export(Request $request)
    {
        $headers = [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="activity-logs.csv"',
        ];

        $callback = function () {
            $file = fopen('php://output', 'w');

            // Add headers
            fputcsv($file, [
                'Date',
                'User',
                'Event',
                'Model',
                'Description',
                'IP Address',
            ]);

            // Add data
            ActivityLog::with('user')
                ->latest()
                ->chunk(1000, function ($logs) use ($file) {
                    foreach ($logs as $log) {
                        fputcsv($file, [
                            $log->created_at->format('Y-m-d H:i:s'),
                            $log->user ? $log->user->name : 'System',
                            $log->event,
                            class_basename($log->model_type),
                            $log->description,
                            $log->ip_address,
                        ]);
                    }
                });

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
}
