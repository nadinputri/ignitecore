# MemeBot Trading System

A sophisticated trading bot system for analyzing and trading meme coins, with GPU acceleration support for machine learning models.

## Features

- Real-time market analysis using machine learning models
- Pump and dump detection with configurable thresholds
- Telegram bot integration for alerts and monitoring
- RESTful API for admin panel integration
- GPU-accelerated model inference
- Rate-limited API integration with major exchanges
- Comprehensive technical analysis tools
- Risk management system

## Requirements

- Python 3.8+
- CUDA-compatible GPU
- Required Python packages (see requirements.txt)
- Telegram Bot API credentials
- Exchange API credentials

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/memecoin-gpu-setup.git
cd memecoin-gpu-setup
```

2. Create and activate a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or
.\venv\Scripts\activate  # Windows
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set up environment variables:
```bash
cp .env.example .env
# Edit .env with your API keys and configuration
```

5. Initialize the system:
```bash
python remote_setup.py
```

## Configuration

1. API Configuration (`config/api_config.json`):
- Exchange API endpoints
- Rate limiting settings
- Authentication credentials

2. Trading Configuration (`config/bot_config.json`):
- Risk management parameters
- Trading thresholds
- Monitoring intervals

3. Telegram Bot Configuration (`config/telegram.json`):
- Bot token
- Admin user IDs
- Alert settings

## Usage

1. Start the API server:
```bash
python api_server.py
```

2. Start the trading bot:
```bash
python main.py
```

3. Monitor via Telegram:
- Send `/start` to your bot
- Use `/help` for available commands
- Subscribe to alerts with `/subscribe`

## Project Structure

```
memecoin-gpu-setup/
├── trading_modules/           # Core trading components
│   ├── __init__.py
│   ├── market_analyzer.py     # Market analysis tools
│   ├── pump_dump_detector.py  # Pump & dump detection
│   ├── telegram_bot.py       # Telegram integration
│   └── trading_strategy.py   # Trading strategies
├── api_integration.py        # External API integration
├── api_server.py            # REST API server
├── main.py                  # Main entry point
├── remote_setup.py          # Setup script
├── requirements.txt         # Python dependencies
└── README.md               # Documentation
```

## API Endpoints

### Public Endpoints

- `GET /health` - Health check
- `GET /market-data/{token_symbol}` - Get market data
- `GET /token-info/{token_symbol}` - Get token information

### Protected Endpoints

- `POST /analyze` - Analyze trading opportunities
- `POST /trade` - Execute trades
- `POST /alert-settings` - Update alert settings
- `GET /monitoring-status` - Get monitoring status
- `POST /monitoring/{action}` - Control monitoring

## Trading Modules

### Market Analyzer
- Technical analysis
- Pattern recognition
- Sentiment analysis
- Price prediction

### Pump & Dump Detector
- Volume analysis
- Price movement analysis
- Risk scoring
- Pattern detection

### Trading Strategy
- Multiple strategy support
- Risk management
- Position sizing
- Entry/exit rules

### Telegram Bot
- Real-time alerts
- Command interface
- Performance reports
- Market updates

## Security

- API authentication using HTTP Basic Auth
- Rate limiting
- IP whitelisting (configurable)
- Secure credential storage
- Request validation

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Disclaimer

This software is for educational purposes only. Use at your own risk. The authors and contributors are not responsible for any financial losses incurred while using this system.
