@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Notification Details</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="{{ route('notification-preferences.index') }}" class="btn btn-outline-secondary">
                Back to Notifications
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <div class="mb-4">
                        <h4>{{ $notification->data['title'] ?? 'Notification' }}</h4>
                        <div class="text-muted">
                            <small>
                                Received {{ $notification->created_at->format('M d, Y H:i') }}
                                ({{ $notification->created_at->diffForHumans() }})
                            </small>
                        </div>
                    </div>

                    <div class="mb-4">
                        <div class="notification-content">
                            @if(isset($notification->data['message']))
                                {!! nl2br(e($notification->data['message'])) !!}
                            @endif

                            @if(isset($notification->data['additional_info']))
                                <div class="mt-3">
                                    <strong>Additional Information:</strong>
                                    <div class="card bg-light mt-2">
                                        <div class="card-body">
                                            {!! nl2br(e($notification->data['additional_info'])) !!}
                                        </div>
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>

                    @if(isset($notification->data['action_url']))
                        <div class="mb-4">
                            <a href="{{ $notification->data['action_url'] }}" 
                               class="btn btn-primary">
                                {{ $notification->data['action_text'] ?? 'View Details' }}
                            </a>
                        </div>
                    @endif

                    <div class="notification-meta">
                        <div class="row">
                            @if(isset($notification->data['type']))
                                <div class="col-md-4">
                                    <small class="text-muted">Type</small>
                                    <div>{{ ucfirst(str_replace('_', ' ', $notification->data['type'])) }}</div>
                                </div>
                            @endif

                            @if($notification->read_at)
                                <div class="col-md-4">
                                    <small class="text-muted">Read At</small>
                                    <div>{{ $notification->read_at->format('M d, Y H:i') }}</div>
                                </div>
                            @endif

                            @if(isset($notification->data['reference_id']))
                                <div class="col-md-4">
                                    <small class="text-muted">Reference ID</small>
                                    <div>#{{ $notification->data['reference_id'] }}</div>
                                </div>
                            @endif
                        </div>
                    </div>

                    <hr>

                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            @if(!$notification->read_at)
                                <form action="{{ route('notification-preferences.mark-read', $notification->id) }}" 
                                      method="POST" 
                                      class="d-inline">
                                    @csrf
                                    <button type="submit" class="btn btn-outline-primary">
                                        Mark as Read
                                    </button>
                                </form>
                            @endif
                        </div>
                        <form action="{{ route('notification-preferences.destroy', $notification->id) }}" 
                              method="POST" 
                              class="d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" 
                                    class="btn btn-outline-danger"
                                    onclick="return confirm('Are you sure you want to delete this notification?')">
                                Delete Notification
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Related Information</h5>

                    @if(isset($notification->data['type']))
                        @switch($notification->data['type'])
                            @case('order_status')
                                @if(isset($notification->data['order_id']))
                                    <div class="mb-3">
                                        <h6>Order Details</h6>
                                        <a href="{{ route('orders.show', $notification->data['order_id']) }}" 
                                           class="btn btn-outline-primary btn-sm d-block">
                                            View Order #{{ $notification->data['order_id'] }}
                                        </a>
                                    </div>
                                @endif
                                @break

                            @case('support_ticket')
                                @if(isset($notification->data['ticket_id']))
                                    <div class="mb-3">
                                        <h6>Support Ticket</h6>
                                        <a href="{{ route('support-tickets.show', $notification->data['ticket_id']) }}" 
                                           class="btn btn-outline-primary btn-sm d-block">
                                            View Ticket #{{ $notification->data['ticket_id'] }}
                                        </a>
                                    </div>
                                @endif
                                @break

                            @case('wallet_update')
                                <div class="mb-3">
                                    <h6>Wallet</h6>
                                    <a href="{{ route('wallet.index') }}" 
                                       class="btn btn-outline-primary btn-sm d-block">
                                        View Wallet
                                    </a>
                                </div>
                                @break
                        @endswitch
                    @endif

                    <div class="mt-4">
                        <h6>Notification Settings</h6>
                        <p class="text-muted small mb-2">
                            You can customize how you receive notifications in your preferences.
                        </p>
                        <a href="{{ route('notification-preferences.edit') }}" 
                           class="btn btn-outline-secondary btn-sm d-block">
                            Manage Preferences
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('styles')
<style>
.notification-content {
    font-size: 1.1em;
    line-height: 1.6;
}
</style>
@endpush
@endsection
