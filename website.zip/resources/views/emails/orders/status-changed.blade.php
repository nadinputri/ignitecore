@component('mail::message')
# Order Status Update

Dear {{ $order->user->name }},

Your order #{{ $order->id }} status has been updated from **{{ ucfirst(str_replace('_', ' ', $previousStatus)) }}** to **{{ ucfirst(str_replace('_', ' ', $newStatus)) }}**.

@if(isset($statusMessages[$newStatus]))
{{ $statusMessages[$newStatus] }}
@endif

## Order Details
- **Service:** {{ $order->service->name }}
@if($order->final_price)
- **Final Price:** ${{ number_format($order->final_price, 2) }}
@elseif($order->counter_price)
- **Counter Offer:** ${{ number_format($order->counter_price, 2) }}
@elseif($order->initial_price)
- **Offered Price:** ${{ number_format($order->initial_price, 2) }}
@endif
- **Created:** {{ $order->created_at->format('M d, Y') }}

@if($additionalMessage)
## Additional Information
{{ $additionalMessage }}
@endif

@if(isset($actionUrls[$newStatus]))
@component('mail::button', ['url' => $actionUrls[$newStatus]])
{{ $actionTexts[$newStatus] }}
@endcomponent
@endif

@if($newStatus === 'price_offered')
You can:
1. Accept the offered price to proceed with the order
2. Make a counter offer if you'd like to negotiate
3. Cancel the order if you're not interested

Please note that the price offer is valid for a limited time.
@endif

@if($newStatus === 'completed')
Thank you for choosing our services! We hope you're satisfied with the results.

If you need any modifications or have questions, please don't hesitate to contact our support team.
@endif

@if($newStatus === 'cancelled')
If you'd like to place a new order or have any questions, our support team is always here to help.
@endif

@if($newStatus === 'refunded')
The refund amount has been credited to your wallet balance. You can use this balance for future orders or request a withdrawal.
@endif

## Need Help?
If you have any questions or concerns, please don't hesitate to:
1. Reply to this email
2. Open a support ticket
3. Contact us through our website

Best regards,<br>
{{ config('app.name') }}

@component('mail::subcopy')
This is an automated message. Please do not reply directly to this email.
For any inquiries, please use our support system or contact us through our website.
@endcomponent
@endcomponent
