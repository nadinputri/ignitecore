<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            CategorySeeder::class,
            ActivityLogSettingsSeeder::class,
            // Add other seeders here
        ]);

        // Create default admin user if not exists
        if (!\App\Models\User::where('email', 'admin@example.com')->exists()) {
            \App\Models\User::factory()->create([
                'name' => 'Admin User',
                'email' => 'admin@example.com',
                'password' => bcrypt('password'), // Change in production!
                'is_admin' => true,
                'email_verified_at' => now(),
            ]);
        }

        // Create default settings if not exists
        $defaultSettings = [
            [
                'key' => 'site_name',
                'value' => 'IgniteHub',
                'type' => 'string',
                'group' => 'general',
                'label' => 'Site Name',
                'description' => 'The name of your website',
                'is_public' => true,
                'is_system' => true,
            ],
            [
                'key' => 'maintenance_mode',
                'value' => '0',
                'type' => 'boolean',
                'group' => 'system',
                'label' => 'Maintenance Mode',
                'description' => 'Enable maintenance mode',
                'is_public' => false,
                'is_system' => true,
            ],
            [
                'key' => 'default_currency',
                'value' => 'USD',
                'type' => 'string',
                'group' => 'payment',
                'label' => 'Default Currency',
                'description' => 'Default currency for payments',
                'is_public' => true,
                'is_system' => true,
            ],
            [
                'key' => 'contact_email',
                'value' => 'contact@example.com',
                'type' => 'string',
                'group' => 'contact',
                'label' => 'Contact Email',
                'description' => 'Email address for contact form submissions',
                'is_public' => true,
                'is_system' => true,
            ],
        ];

        foreach ($defaultSettings as $setting) {
            \App\Models\Setting::firstOrCreate(
                ['key' => $setting['key']],
                $setting
            );
        }

        // Development environment specific seeding
        if (app()->environment('local', 'development')) {
            // Create test users
            \App\Models\User::factory(10)->create();
            
            // Create test services
            \App\Models\Service::factory(20)->create();
            
            // Create test orders
            \App\Models\Order::factory(50)->create();
            
            // Create some test activity logs
            foreach (range(1, 20) as $i) {
                \App\Models\ActivityLog::create([
                    'user_id' => rand(1, 11), // Including admin user
                    'event' => collect(['created', 'updated', 'deleted'])->random(),
                    'model_type' => collect([
                        \App\Models\Service::class,
                        \App\Models\Order::class,
                        \App\Models\Category::class
                    ])->random(),
                    'model_id' => rand(1, 20),
                    'description' => "Test activity log entry #{$i}",
                    'properties' => ['test_data' => true],
                    'ip_address' => '127.0.0.1',
                    'created_at' => now()->subDays(rand(0, 30)),
                ]);
            }
        }
    }
}
