"""
Trading modules for memecoin bot

This package contains modules for market analysis, trading strategy,
pump and dump detection, and Telegram bot integration.
"""

from .market_analyzer import MarketAnalyzer
from .pump_dump_detector import PumpDumpDetector
from .trading_strategy import TradingStrategy
from .telegram_bot import TelegramBot

__all__ = [
    'MarketAnalyzer',
    'PumpDumpDetector',
    'TradingStrategy',
    'TelegramBot'
]

__version__ = '1.0.0'
