<?php

namespace App\Console\Commands;

use App\Models\MemeToken;
use App\Services\TokenAnalysisService;
use App\Services\TradingExecutionService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Telegram\Bot\Api;

class MonitorTokens extends Command
{
    protected $signature = 'tokens:monitor';
    protected $description = 'Monitor meme tokens for price changes and trading opportunities';

    protected $tokenAnalysisService;
    protected $tradingExecutionService;
    protected $telegram;

    public function __construct(
        TokenAnalysisService $tokenAnalysisService,
        TradingExecutionService $tradingExecutionService
    ) {
        parent::__construct();
        $this->tokenAnalysisService = $tokenAnalysisService;
        $this->tradingExecutionService = $tradingExecutionService;
    }

    public function handle()
    {
        $this->info('Starting token monitoring...');

        try {
            // Get active tokens
            MemeToken::active()->chunk(10, function ($tokens) {
                foreach ($tokens as $token) {
                    $this->monitorToken($token);
                }
            });

            $this->info('Monitoring cycle completed.');
        } catch (\Exception $e) {
            Log::error('Token monitoring failed: ' . $e->getMessage());
            $this->error('Monitoring failed: ' . $e->getMessage());
        }
    }

    protected function monitorToken(MemeToken $token)
    {
        try {
            $this->info("Monitoring {$token->symbol}...");

            // Get previous analysis
            $previousAnalysis = $token->analyses()->latest()->first();

            // Perform new analysis
            $newAnalysis = $this->tokenAnalysisService->analyzeToken($token);

            // Check for significant changes
            $this->checkPriceChanges($token, $previousAnalysis, $newAnalysis);
            $this->checkVolumeChanges($token, $previousAnalysis, $newAnalysis);
            $this->checkSentimentChanges($token, $previousAnalysis, $newAnalysis);
            $this->checkTradingOpportunities($token, $newAnalysis);

            // Update token status
            $token->update([
                'current_price' => $newAnalysis->technical_indicators['current_price'] ?? null,
                'market_cap' => $newAnalysis->technical_indicators['market_cap'] ?? null,
                'holder_count' => $newAnalysis->technical_indicators['holders'] ?? null
            ]);

        } catch (\Exception $e) {
            Log::error("Failed to monitor {$token->symbol}: " . $e->getMessage());
            $this->error("Failed to monitor {$token->symbol}: " . $e->getMessage());
        }
    }

    protected function checkPriceChanges($token, $previous, $new)
    {
        if (!$previous) return;

        $priceThreshold = config('trading.monitoring.price_alert_threshold');
        $oldPrice = $previous->technical_indicators['current_price'] ?? 0;
        $newPrice = $new->technical_indicators['current_price'] ?? 0;

        if ($oldPrice > 0) {
            $change = (($newPrice - $oldPrice) / $oldPrice) * 100;

            if (abs($change) >= $priceThreshold) {
                $direction = $change > 0 ? 'increased' : 'decreased';
                $this->sendAlert($token, "Price {$direction} by " . abs($change) . "%", [
                    'Old Price' => $this->formatPrice($oldPrice),
                    'New Price' => $this->formatPrice($newPrice),
                    'Change' => round($change, 2) . '%'
                ]);
            }
        }
    }

    protected function checkVolumeChanges($token, $previous, $new)
    {
        if (!$previous) return;

        $volumeThreshold = config('trading.monitoring.volume_alert_threshold');
        $oldVolume = $previous->technical_indicators['volume_24h'] ?? 0;
        $newVolume = $new->technical_indicators['volume_24h'] ?? 0;

        if ($oldVolume > 0) {
            $change = (($newVolume - $oldVolume) / $oldVolume) * 100;

            if (abs($change) >= $volumeThreshold) {
                $direction = $change > 0 ? 'increased' : 'decreased';
                $this->sendAlert($token, "Volume {$direction} significantly", [
                    'Old Volume' => $this->formatUsd($oldVolume),
                    'New Volume' => $this->formatUsd($newVolume),
                    'Change' => round($change, 2) . '%'
                ]);
            }
        }
    }

    protected function checkSentimentChanges($token, $previous, $new)
    {
        if (!$previous) return;

        $oldSentiment = $previous->sentiment_analysis['overall'] ?? 'neutral';
        $newSentiment = $new->sentiment_analysis['overall'] ?? 'neutral';

        if ($oldSentiment !== $newSentiment) {
            $this->sendAlert($token, "Sentiment changed from {$oldSentiment} to {$newSentiment}", [
                'Social Score' => $new->social_metrics['score'] ?? 'N/A',
                'News Impact' => $new->sentiment_analysis['news_impact'] ?? 'N/A',
                'Community Mood' => $new->sentiment_analysis['community_mood'] ?? 'N/A'
            ]);
        }
    }

    protected function checkTradingOpportunities($token, $analysis)
    {
        // Check if AI score indicates a strong opportunity
        if ($analysis->ai_score >= 80) {
            $this->sendAlert($token, "Strong trading opportunity detected", [
                'AI Score' => $analysis->ai_score,
                'Risk Level' => $analysis->risk_level,
                'Recommendation' => $analysis->trade_recommendation
            ]);
        }

        // Check for specific technical patterns
        if (isset($analysis->technical_indicators['patterns'])) {
            foreach ($analysis->technical_indicators['patterns'] as $pattern) {
                if ($pattern['strength'] === 'strong') {
                    $this->sendAlert($token, "Technical pattern detected: {$pattern['name']}", [
                        'Pattern' => $pattern['name'],
                        'Direction' => $pattern['direction'],
                        'Confidence' => $pattern['confidence'] . '%'
                    ]);
                }
            }
        }
    }

    protected function sendAlert($token, $message, $data = [])
    {
        $text = "🚨 *Alert for {$token->symbol}*\n\n";
        $text .= "{$message}\n\n";

        foreach ($data as $key => $value) {
            $text .= "*{$key}:* {$value}\n";
        }

        try {
            // Send to all active bot instances monitoring this token
            $token->telegramBots()->each(function ($bot) use ($text) {
                if (!$this->telegram) {
                    $this->telegram = new Api($bot->token);
                }

                $this->telegram->sendMessage([
                    'chat_id' => $bot->chat_id,
                    'text' => $text,
                    'parse_mode' => 'Markdown'
                ]);
            });
        } catch (\Exception $e) {
            Log::error("Failed to send alert: " . $e->getMessage());
        }
    }

    protected function formatPrice($price)
    {
        return '$' . number_format($price, 8);
    }

    protected function formatUsd($amount)
    {
        return '$' . number_format($amount, 2);
    }
}
