# Local LLM Integration

The Local LLM (Large Language Model) integration allows you to run AI models locally for enhanced privacy, reduced latency, and cost efficiency. This feature is particularly useful for processing sensitive data and ensuring reliable operation without external API dependencies.

## Table of Contents
- [Overview](#overview)
- [System Requirements](#system-requirements)
- [Installation](#installation)
- [Configuration](#configuration)
- [Models](#models)
- [Usage](#usage)
- [Monitoring](#monitoring)
- [Troubleshooting](#troubleshooting)

## Overview

The Local LLM integration provides:
- Local model execution for privacy and control
- Support for popular open-source models
- Model quantization for efficient resource usage
- Performance monitoring and optimization
- Fallback mechanisms for reliability
- Comprehensive logging and analytics

## System Requirements

### Hardware Requirements
- **CPU**: Modern multi-core processor (8+ cores recommended)
- **RAM**: 
  - Minimum: 16GB
  - Recommended: 32GB or more
  - For 70B models: 64GB+ recommended
- **Storage**: 
  - 20GB minimum for base models
  - Additional space for model variants and caches
- **GPU** (Optional but recommended):
  - NVIDIA GPU with 8GB+ VRAM
  - CUDA support
  - For larger models: 16GB+ VRAM recommended

### Software Requirements
- Python 3.8 or higher
- CUDA Toolkit 11.7+ (for GPU support)
- Required Python packages (installed automatically):
  - torch
  - transformers
  - accelerate
  - bitsandbytes
  - sentencepiece
  - protobuf
  - safetensors

## Installation

1. **Setup Python Environment**
   ```bash
   cd scripts
   ./setup_llm.sh
   ```

2. **Install Model**
   - Through Admin Panel:
     1. Navigate to Admin → LLM Settings
     2. Select desired model and configuration
     3. Click "Download Model"
   
   - Through CLI:
   ```bash
   php artisan llm:manage install --model=llama2 --size=7B --variant=chat
   ```

## Configuration

### Admin Panel Settings

1. **Model Selection**
   - Choose between available models (Llama 2, Mistral)
   - Select model size and variant
   - Configure quantization level

2. **Performance Settings**
   - Batch size: Number of tokens to process in parallel
   - Threads: CPU thread allocation
   - GPU Layers: Layer distribution between GPU/CPU
   - Context Window: Maximum token context

3. **Safety Settings**
   - Rate limiting
   - Content filtering
   - Maximum token limits
   - Blocked words/phrases

4. **Monitoring Settings**
   - Request logging
   - Performance metrics
   - Error tracking
   - Resource usage monitoring

### Environment Variables

```env
LLM_MODEL_NAME=llama2
LLM_MODEL_SIZE=7B
LLM_MODEL_VARIANT=chat
LLM_QUANTIZATION=4-bit
LLM_MAX_TOKENS=2048
LLM_TEMPERATURE=0.7
LLM_MODELS_PATH=/path/to/models
LLM_PYTHON_PATH=/path/to/python
LLM_CACHE_ENABLED=true
LLM_MONITORING_ENABLED=true
```

## Models

### Supported Models

1. **Llama 2**
   - Sizes: 7B, 13B, 70B
   - Variants: chat, instruct, base
   - Best for: General purpose, chat, instruction following

2. **Mistral**
   - Sizes: 7B
   - Variants: instruct, base
   - Best for: Efficient inference, specific tasks

### Quantization

Available quantization levels:
- 4-bit: Best balance of size/performance
- 8-bit: Higher accuracy, more memory
- None: Full precision, highest resource usage

## Usage

### API Integration

```php
use App\Services\LlmService;

public function generateResponse(Request $request)
{
    $llm = app(LlmService::class);
    
    $response = $llm->generateResponse(
        $request->prompt,
        [
            'max_tokens' => 1000,
            'temperature' => 0.7
        ]
    );
    
    return response()->json(['response' => $response]);
}
```

### Command Line

```bash
# Generate response
php artisan llm:generate "Your prompt here"

# Check model status
php artisan llm:manage status

# Monitor performance
php artisan llm:monitor --watch
```

## Monitoring

### Performance Metrics
- CPU/Memory usage
- GPU utilization
- Response times
- Token throughput
- Error rates

### Logs
- Request/response logs
- Error logs
- Performance logs
- System health logs

Access logs through:
1. Admin Panel → LLM Settings → Logs
2. Storage location: `storage/logs/llm/`

## Troubleshooting

### Common Issues

1. **High Memory Usage**
   - Reduce batch size
   - Use higher quantization level
   - Decrease context window size

2. **Slow Response Times**
   - Enable GPU acceleration
   - Increase thread count
   - Optimize context window

3. **GPU Out of Memory**
   - Reduce GPU layers
   - Use smaller model
   - Increase quantization level

### Diagnostics

Run health check:
```bash
php artisan llm:manage status --verbose
```

Check system compatibility:
```bash
php artisan llm:manage check-requirements
```

### Support

For additional support:
1. Check error logs in `storage/logs/llm/`
2. Run diagnostics using admin panel
3. Contact support with diagnostic results

## Best Practices

1. **Resource Management**
   - Monitor system resources
   - Use appropriate model size
   - Enable caching when possible

2. **Performance Optimization**
   - Balance CPU/GPU usage
   - Adjust batch size for workload
   - Use appropriate quantization

3. **Security**
   - Regular security updates
   - Content filtering
   - Rate limiting
   - Access control

4. **Maintenance**
   - Regular model updates
   - Log rotation
   - Cache cleanup
   - Performance monitoring

## Updates and Maintenance

1. **Model Updates**
   ```bash
   php artisan llm:manage update --model=llama2
   ```

2. **Cache Management**
   ```bash
   php artisan llm:manage cleanup
   ```

3. **Log Rotation**
   ```bash
   php artisan llm:manage cleanup-logs --days=30
   ```

Remember to monitor system resources and adjust settings based on usage patterns and requirements.
