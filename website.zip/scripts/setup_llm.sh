#!/bin/bash

# Exit on error
set -e

echo "Setting up LLM environment..."

# Check Python version
python_version=$(python3 -c 'import sys; print(".".join(map(str, sys.version_info[:2])))')
if (( $(echo "$python_version < 3.8" | bc -l) )); then
    echo "Error: Python 3.8 or higher is required (found $python_version)"
    exit 1
fi

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate

# Upgrade pip
echo "Upgrading pip..."
pip install --upgrade pip

# Install dependencies
echo "Installing Python dependencies..."
pip install -r scripts/requirements.txt

# Check CUDA availability
echo "Checking CUDA availability..."
python3 -c "import torch; print('CUDA available:', torch.cuda.is_available())"
if [ $? -eq 0 ]; then
    echo "CUDA is available"
    # Print CUDA version and device info
    python3 -c "import torch; print('CUDA version:', torch.version.cuda); print('Device count:', torch.cuda.device_count()); [print(f'Device {i}: {torch.cuda.get_device_name(i)}') for i in range(torch.cuda.device_count())]"
else
    echo "Warning: CUDA is not available. Using CPU only mode."
fi

# Create necessary directories
echo "Creating directories..."
mkdir -p storage/app/models
mkdir -p storage/logs/llm

# Set permissions
echo "Setting permissions..."
chmod +x scripts/*.py
chmod +x scripts/*.sh

# Create symbolic links
echo "Creating symbolic links..."
if [ ! -L public/storage ]; then
    php artisan storage:link
fi

# Update .env file if needed
if ! grep -q "LLM_" .env; then
    echo "Updating .env file with LLM settings..."
    cat >> .env << EOL

# LLM Settings
LLM_MODEL_NAME=llama2
LLM_MODEL_SIZE=7B
LLM_MODEL_VARIANT=chat
LLM_QUANTIZATION=4-bit
LLM_MAX_TOKENS=2048
LLM_TEMPERATURE=0.7
LLM_MODELS_PATH="${PWD}/storage/app/models"
LLM_PYTHON_PATH="${PWD}/venv/bin/python3"
LLM_CACHE_ENABLED=true
LLM_MONITORING_ENABLED=true
LLM_MAX_REQUESTS_PER_MINUTE=60
LLM_CONTENT_FILTERING=true
LLM_FALLBACK_ENABLED=true
EOL
fi

# Configure logging channels
if ! grep -q "llm" config/logging.php; then
    echo "Configuring logging channels..."
    sed -i "/'channels' => \[/a\        'llm' => [\n            'driver' => 'daily',\n            'path' => storage_path('logs/llm/llm.log'),\n            'level' => env('LOG_LEVEL', 'debug'),\n            'days' => 14,\n        ]," config/logging.php
fi

# Clear cache
echo "Clearing cache..."
php artisan config:clear
php artisan cache:clear

# Run database migrations
echo "Running database migrations..."
php artisan migrate

# Set up cron job for monitoring
if ! crontab -l | grep -q "llm:monitor"; then
    echo "Setting up cron job for LLM monitoring..."
    (crontab -l 2>/dev/null; echo "*/5 * * * * cd ${PWD} && php artisan llm:monitor") | crontab -
fi

# Create log rotation config
if [ ! -f "/etc/logrotate.d/llm" ]; then
    echo "Setting up log rotation..."
    sudo tee /etc/logrotate.d/llm > /dev/null << EOL
${PWD}/storage/logs/llm/*.log {
    daily
    missingok
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 www-data www-data
}
EOL
fi

echo "Setup complete!"
echo ""
echo "Next steps:"
echo "1. Configure your LLM settings in .env"
echo "2. Download a model using: php artisan llm:manage install"
echo "3. Test the setup using: php artisan llm:generate 'Hello, world!'"
echo ""
echo "For more information, see docs/local-llm.md"

# Optional: Download default model
read -p "Would you like to download the default model (Llama 2 7B Chat)? [y/N] " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    php artisan llm:manage install --model=llama2 --size=7B --variant=chat
fi
