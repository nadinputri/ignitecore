<?php

namespace App\Policies;

use App\Models\User;
use App\Models\Order;
use Illuminate\Auth\Access\HandlesAuthorization;

class OrderPolicy
{
    use HandlesAuthorization;

    /**
     * Perform pre-authorization checks.
     *
     * @param  \App\Models\User  $user
     * @param  string  $ability
     * @return bool|null
     */
    public function before(User $user, $ability)
    {
        if ($user->isAdmin()) {
            return true;
        }
    }

    /**
     * Determine whether the user can view any orders.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function viewAny(User $user)
    {
        return true;
    }

    /**
     * Determine whether the user can view the order.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Order  $order
     * @return bool
     */
    public function view(User $user, Order $order)
    {
        return $user->id === $order->user_id;
    }

    /**
     * Determine whether the user can create orders.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function create(User $user)
    {
        return true;
    }

    /**
     * Determine whether the user can update the order.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Order  $order
     * @return bool
     */
    public function update(User $user, Order $order)
    {
        return $user->id === $order->user_id && 
               in_array($order->status, ['pending', 'price_offered', 'price_countered']);
    }

    /**
     * Determine whether the user can cancel the order.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Order  $order
     * @return bool
     */
    public function cancel(User $user, Order $order)
    {
        return $user->id === $order->user_id && 
               in_array($order->status, ['pending', 'price_offered', 'price_countered']);
    }

    /**
     * Determine whether the user can counter offer on the order.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Order  $order
     * @return bool
     */
    public function counterOffer(User $user, Order $order)
    {
        return $user->id === $order->user_id && 
               $order->status === 'price_offered';
    }

    /**
     * Determine whether the user can accept the price.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Order  $order
     * @return bool
     */
    public function acceptPrice(User $user, Order $order)
    {
        return $user->id === $order->user_id && 
               in_array($order->status, ['price_offered']) &&
               $user->wallet->canAfford($order->initial_price);
    }

    /**
     * Determine whether the user can view order history.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\Order  $order
     * @return bool
     */
    public function viewHistory(User $user, Order $order)
    {
        return $user->id === $order->user_id;
    }
}
