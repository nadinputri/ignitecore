<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Cache\RateLimiter;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

class AdminRateLimiter
{
    /**
     * The rate limiter instance.
     *
     * @var \Illuminate\Cache\RateLimiter
     */
    protected $limiter;

    /**
     * Create a new middleware instance.
     *
     * @param  \Illuminate\Cache\RateLimiter  $limiter
     * @return void
     */
    public function __construct(RateLimiter $limiter)
    {
        $this->limiter = $limiter;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // Generate a unique key for the rate limiter based on the user and action
        $key = sprintf(
            'admin:%s:%s',
            $request->user() ? $request->user()->id : $request->ip(),
            Str::slug($request->route()->getName() ?? 'unknown')
        );

        // Define limits based on the route
        $maxAttempts = $this->getMaxAttempts($request);
        $decayMinutes = 1;

        // Check if the request exceeds the rate limit
        if ($this->limiter->tooManyAttempts($key, $maxAttempts)) {
            return $this->buildResponse($key);
        }

        // Increment the counter
        $this->limiter->hit($key, $decayMinutes * 60);

        $response = $next($request);

        // Add rate limit headers to the response
        return $this->addHeaders(
            $response,
            $maxAttempts,
            $this->limiter->remaining($key, $maxAttempts)
        );
    }

    /**
     * Get the maximum number of attempts based on the route.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return int
     */
    protected function getMaxAttempts(Request $request): int
    {
        // Define different limits for different admin actions
        $routeName = $request->route()->getName();
        
        return match (true) {
            // Allow more requests for viewing
            Str::contains($routeName, ['index', 'show']) => 60,
            
            // Limit potentially resource-intensive operations
            Str::contains($routeName, ['export', 'clear']) => 5,
            
            // Default limit for other admin actions
            default => 30,
        };
    }

    /**
     * Build the rate limit exceeded response.
     *
     * @param  string  $key
     * @return \Illuminate\Http\Response
     */
    protected function buildResponse($key)
    {
        $retryAfter = $this->limiter->availableIn($key);

        return response()->json([
            'message' => 'Too many requests. Please try again later.',
            'retry_after' => $retryAfter,
        ], Response::HTTP_TOO_MANY_REQUESTS)->headers->add([
            'Retry-After' => $retryAfter,
            'X-RateLimit-Reset' => time() + $retryAfter,
        ]);
    }

    /**
     * Add the rate limit headers to the response.
     *
     * @param  \Symfony\Component\HttpFoundation\Response  $response
     * @param  int  $maxAttempts
     * @param  int  $remainingAttempts
     * @return \Symfony\Component\HttpFoundation\Response
     */
    protected function addHeaders($response, $maxAttempts, $remainingAttempts)
    {
        $response->headers->add([
            'X-RateLimit-Limit' => $maxAttempts,
            'X-RateLimit-Remaining' => $remainingAttempts,
        ]);

        return $response;
    }
}
