<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\TelegramBot;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class TelegramBotController extends Controller
{
    public function index()
    {
        $bots = TelegramBot::with('user')
            ->latest()
            ->paginate(15);
            
        return view('admin.telegram-bots.index', compact('bots'));
    }

    public function show(TelegramBot $bot)
    {
        $creditHistory = $bot->credits()
            ->with('user')
            ->latest()
            ->paginate(15);
            
        return view('admin.telegram-bots.show', compact('bot', 'creditHistory'));
    }

    public function edit(TelegramBot $bot)
    {
        return view('admin.telegram-bots.edit', compact('bot'));
    }

    public function update(Request $request, TelegramBot $bot)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'status' => 'required|in:active,inactive',
            'settings' => 'nullable|array'
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $bot->update([
            'name' => $request->name,
            'status' => $request->status,
            'settings' => $request->settings ?? $bot->settings
        ]);

        return redirect()->route('admin.telegram-bots.show', $bot)
            ->with('success', 'Telegram bot updated successfully.');
    }

    public function destroy(TelegramBot $bot)
    {
        $bot->delete();

        return redirect()->route('admin.telegram-bots.index')
            ->with('success', 'Telegram bot deleted successfully.');
    }

    public function creditHistory(TelegramBot $bot)
    {
        $credits = $bot->credits()
            ->with('user')
            ->latest()
            ->paginate(20);
            
        return view('admin.telegram-bots.credits', compact('bot', 'credits'));
    }

    public function settings()
    {
        $settings = [
            'credit_cost_per_message' => setting('telegram_bot_credit_cost_per_message', 1),
            'max_bots_per_user' => setting('telegram_bot_max_bots_per_user', 5),
            'allowed_commands' => setting('telegram_bot_allowed_commands', ['start', 'help', 'settings']),
        ];
        
        return view('admin.telegram-bots.settings', compact('settings'));
    }

    public function updateSettings(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'credit_cost_per_message' => 'required|integer|min:1',
            'max_bots_per_user' => 'required|integer|min:1',
            'allowed_commands' => 'required|array'
        ]);

        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        setting([
            'telegram_bot_credit_cost_per_message' => $request->credit_cost_per_message,
            'telegram_bot_max_bots_per_user' => $request->max_bots_per_user,
            'telegram_bot_allowed_commands' => $request->allowed_commands
        ])->save();

        return back()->with('success', 'Settings updated successfully.');
    }
}
