<div {{ $attributes->merge(['class' => 'user-status-badge']) }}>
    <span class="badge {{ $getBadgeClass() }}">
        {{ $getStatusText() }}
    </span>

    @if($detailed)
        <div class="mt-1 small text-muted">
            @if($user->isSuspended())
                Suspended until {{ $user->suspended_until->format('M d, Y H:i') }}
            @elseif($user->status === 'active' && !$user->isOnline())
                Last active {{ $user->getLastActivityForHumans() }}
            @endif
        </div>

        @if($user->isSuspended() && config('users.support.allow_suspended_tickets', true))
            <div class="mt-2">
                <a href="{{ route('support-tickets.create') }}" class="btn btn-sm btn-outline-primary">
                    Contact Support
                </a>
            </div>
        @endif
    @endif
</div>

@pushOnce('styles')
<style>
.user-status-badge {
    display: inline-block;
}

.user-status-badge .badge {
    font-size: 0.875rem;
    padding: 0.35em 0.65em;
}

.user-status-badge .btn-sm {
    font-size: 0.75rem;
    padding: 0.25rem 0.5rem;
}

.user-status-badge .text-muted {
    font-size: 0.8125rem;
}

/* Status badge animations */
.user-status-badge .badge {
    transition: all 0.3s ease;
}

.user-status-badge .bg-success {
    position: relative;
}

/* Online status pulse animation */
.user-status-badge .bg-success::after {
    content: '';
    position: absolute;
    top: 50%;
    right: -4px;
    transform: translateY(-50%);
    width: 6px;
    height: 6px;
    background-color: #198754;
    border-radius: 50%;
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0% {
        box-shadow: 0 0 0 0 rgba(25, 135, 84, 0.4);
    }
    70% {
        box-shadow: 0 0 0 6px rgba(25, 135, 84, 0);
    }
    100% {
        box-shadow: 0 0 0 0 rgba(25, 135, 84, 0);
    }
}

/* Suspended status warning animation */
.user-status-badge .bg-warning {
    animation: warning-pulse 2s infinite;
}

@keyframes warning-pulse {
    0%, 100% {
        opacity: 1;
    }
    50% {
        opacity: 0.7;
    }
}

/* Banned status danger animation */
.user-status-badge .bg-danger {
    animation: danger-shake 0.5s ease-in-out;
}

@keyframes danger-shake {
    0%, 100% { transform: translateX(0); }
    25% { transform: translateX(-2px); }
    75% { transform: translateX(2px); }
}
</style>
@endPushOnce
