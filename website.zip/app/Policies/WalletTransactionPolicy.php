<?php

namespace App\Policies;

use App\Models\User;
use App\Models\WalletTransaction;
use Illuminate\Auth\Access\HandlesAuthorization;

class WalletTransactionPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view the transaction.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\WalletTransaction  $transaction
     * @return bool
     */
    public function view(User $user, WalletTransaction $transaction)
    {
        // User can only view their own wallet transactions
        return $user->id === $transaction->wallet->user_id;
    }

    /**
     * Determine whether the user can view any transactions.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function viewAny(User $user)
    {
        // Users can view their own transactions list
        return true;
    }

    /**
     * Determine whether the user can create transactions.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function create(User $user)
    {
        // Users can create transactions (top up their wallet)
        return true;
    }

    /**
     * Determine whether the admin can manage all transactions.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function manage(User $user)
    {
        return $user->isAdmin();
    }
}
