<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Traits\LogsActivity;

class SupportTicketReply extends Model
{
    use HasFactory, LogsActivity;

    protected $fillable = [
        'ticket_id',
        'user_id',
        'message',
        'is_admin_reply'
    ];

    protected $casts = [
        'is_admin_reply' => 'boolean'
    ];

    protected static $logAttributes = [
        'message',
        'is_admin_reply'
    ];

    protected static function booted()
    {
        static::created(function ($reply) {
            // Update ticket status when admin replies
            if ($reply->is_admin_reply && $reply->ticket->status === 'open') {
                $reply->ticket->markAsInProgress();
            }
        });
    }

    public function ticket()
    {
        return $this->belongsTo(SupportTicket::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function attachments()
    {
        return $this->hasMany(SupportTicketAttachment::class, 'reply_id');
    }

    public function scopeAdminReplies($query)
    {
        return $query->where('is_admin_reply', true);
    }

    public function scopeUserReplies($query)
    {
        return $query->where('is_admin_reply', false);
    }

    public function isFromAdmin()
    {
        return $this->is_admin_reply;
    }

    public function isFromUser()
    {
        return !$this->is_admin_reply;
    }

    public function getFormattedCreatedAtAttribute()
    {
        return $this->created_at->format('M d, Y H:i');
    }
}
