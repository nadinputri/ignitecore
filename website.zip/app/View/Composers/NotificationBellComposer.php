<?php

namespace App\View\Composers;

use Illuminate\View\View;
use Illuminate\Support\Facades\Auth;

class NotificationBellComposer
{
    /**
     * Bind data to the view.
     *
     * @param  \Illuminate\View\View  $view
     * @return void
     */
    public function compose(View $view)
    {
        $user = Auth::user();

        if (!$user) {
            $view->with([
                'unreadCount' => 0,
                'notifications' => collect(),
                'hasMore' => false,
            ]);
            return;
        }

        // Get recent notifications (last 5)
        $notifications = $user->notifications()
            ->latest()
            ->limit(5)
            ->get();

        // Get total unread count
        $unreadCount = $user->unreadNotifications()->count();

        // Check if there are more notifications than shown in dropdown
        $hasMore = $user->notifications()->count() > 5;

        $view->with([
            'unreadCount' => $unreadCount,
            'notifications' => $notifications,
            'hasMore' => $hasMore,
        ]);
    }
}
