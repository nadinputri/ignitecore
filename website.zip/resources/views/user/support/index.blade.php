@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Support Tickets</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="{{ route('support-tickets.create') }}" class="btn btn-primary">
                <i class="fas fa-plus"></i> New Ticket
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    @if($tickets->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Ticket #</th>
                                        <th>Subject</th>
                                        <th>Status</th>
                                        <th>Priority</th>
                                        <th>Last Updated</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($tickets as $ticket)
                                    <tr>
                                        <td>{{ $ticket->ticket_number }}</td>
                                        <td>
                                            <a href="{{ route('support-tickets.show', $ticket) }}" class="text-decoration-none">
                                                {{ $ticket->subject }}
                                            </a>
                                            @if($ticket->replies_count > 0)
                                                <span class="badge bg-info">{{ $ticket->replies_count }} {{ Str::plural('reply', $ticket->replies_count) }}</span>
                                            @endif
                                        </td>
                                        <td>
                                            <span class="badge bg-{{ 
                                                $ticket->status === 'open' ? 'warning' : 
                                                ($ticket->status === 'in_progress' ? 'info' : 
                                                ($ticket->status === 'resolved' ? 'success' : 'secondary'))
                                            }}">
                                                {{ ucfirst(str_replace('_', ' ', $ticket->status)) }}
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge bg-{{ 
                                                $ticket->priority === 'high' ? 'danger' : 
                                                ($ticket->priority === 'medium' ? 'warning' : 'info')
                                            }}">
                                                {{ ucfirst($ticket->priority) }}
                                            </span>
                                        </td>
                                        <td>{{ $ticket->updated_at->diffForHumans() }}</td>
                                        <td>
                                            <a href="{{ route('support-tickets.show', $ticket) }}" 
                                               class="btn btn-sm btn-outline-primary">
                                                View
                                            </a>
                                            @if(in_array($ticket->status, ['resolved', 'closed']))
                                                <form action="{{ route('support-tickets.reopen', $ticket) }}" 
                                                      method="POST" 
                                                      class="d-inline">
                                                    @csrf
                                                    <button type="submit" class="btn btn-sm btn-outline-success">
                                                        Reopen
                                                    </button>
                                                </form>
                                            @elseif(!in_array($ticket->status, ['resolved', 'closed']))
                                                <form action="{{ route('support-tickets.close', $ticket) }}" 
                                                      method="POST" 
                                                      class="d-inline">
                                                    @csrf
                                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                                        Close
                                                    </button>
                                                </form>
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <div class="d-flex justify-content-center mt-4">
                            {{ $tickets->links() }}
                        </div>
                    @else
                        <div class="text-center py-4">
                            <h4>No Support Tickets Found</h4>
                            <p class="text-muted">Create a new ticket if you need assistance.</p>
                            <a href="{{ route('support-tickets.create') }}" class="btn btn-primary">
                                Create New Ticket
                            </a>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
