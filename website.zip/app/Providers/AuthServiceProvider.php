<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;
use Illuminate\Notifications\DatabaseNotification;
use App\Policies\NotificationPolicy;
use App\Policies\OrderPolicy;
use App\Policies\SupportTicketPolicy;
use App\Policies\WalletTransactionPolicy;
use App\Policies\TelegramBotPolicy;
use App\Models\Order;
use App\Models\SupportTicket;
use App\Models\WalletTransaction;
use App\Models\TelegramBot;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The model to policy mappings for the application.
     *
     * @var array<class-string, class-string>
     */
    protected $policies = [
        DatabaseNotification::class => NotificationPolicy::class,
        Order::class => OrderPolicy::class,
        SupportTicket::class => SupportTicketPolicy::class,
        WalletTransaction::class => WalletTransactionPolicy::class,
        TelegramBot::class => TelegramBotPolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        $this->registerPolicies();

        // Define admin gate
        Gate::define('admin', function ($user) {
            return $user->isAdmin();
        });

        // Define support agent gate
        Gate::define('support-agent', function ($user) {
            return $user->isSupportAgent();
        });

        // Define verified user gate
        Gate::define('verified-user', function ($user) {
            return $user->hasVerifiedEmail();
        });

        // Define active user gate
        Gate::define('active-user', function ($user) {
            return !$user->isBanned() && !$user->isSuspended();
        });

        // Define wallet access gate
        Gate::define('access-wallet', function ($user) {
            return $user->hasVerifiedEmail() && !$user->isBanned();
        });

        // Define order creation gate
        Gate::define('create-order', function ($user) {
            return $user->hasVerifiedEmail() && 
                   !$user->isBanned() && 
                   !$user->hasReachedOrderLimit();
        });

        // Define support ticket creation gate
        Gate::define('create-support-ticket', function ($user) {
            return $user->hasVerifiedEmail() && !$user->isBanned();
        });

        // Define telegram bot creation gate
        Gate::define('create-telegram-bot', function ($user) {
            return $user->hasVerifiedEmail() && 
                   !$user->isBanned() && 
                   $user->telegramBots()->count() < setting('telegram_bot_max_bots_per_user', 5);
        });

        // Define telegram bot credit usage gate
        Gate::define('use-telegram-bot-credits', function ($user) {
            return $user->hasVerifiedEmail() && 
                   !$user->isBanned() && 
                   $user->wallet->balance > 0;
        });
    }
}
