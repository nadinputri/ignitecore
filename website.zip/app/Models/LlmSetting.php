<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class LlmSetting extends Model
{
    protected $fillable = [
        'model_name',
        'model_size',
        'model_variant',
        'model_path',
        'quantization',
        'batch_size',
        'threads',
        'gpu_layers',
        'context_window',
        'max_tokens',
        'temperature',
        'cache_enabled',
        'cache_ttl',
        'max_requests_per_minute',
        'max_tokens_per_request',
        'content_filtering',
        'blocked_words',
        'fallback_enabled',
        'fallback_max_retries',
        'fallback_timeout',
        'fallback_response',
        'monitoring_enabled',
        'log_requests',
        'log_responses',
        'log_errors',
        'metrics_enabled',
        'health_status',
        'last_health_check',
        'system_metrics'
    ];

    protected $casts = [
        'blocked_words' => 'array',
        'system_metrics' => 'array',
        'cache_enabled' => 'boolean',
        'content_filtering' => 'boolean',
        'fallback_enabled' => 'boolean',
        'monitoring_enabled' => 'boolean',
        'log_requests' => 'boolean',
        'log_responses' => 'boolean',
        'log_errors' => 'boolean',
        'metrics_enabled' => 'boolean',
        'last_health_check' => 'datetime',
        'temperature' => 'float'
    ];

    /**
     * Get the singleton configuration instance
     */
    public static function getConfig(): self
    {
        $settings = Cache::remember('llm_settings', 3600, function () {
            return self::firstOrCreate([], [
                'model_name' => config('llm.defaults.model_name'),
                'model_size' => config('llm.defaults.model_size'),
                'model_variant' => config('llm.defaults.model_variant'),
                'quantization' => config('llm.defaults.quantization'),
                'batch_size' => config('llm.performance.batch_size'),
                'threads' => config('llm.performance.threads'),
                'gpu_layers' => config('llm.performance.gpu_layers'),
                'context_window' => config('llm.performance.context_window'),
                'max_tokens' => config('llm.defaults.max_tokens'),
                'temperature' => config('llm.defaults.temperature'),
                'cache_enabled' => config('llm.cache.enabled'),
                'cache_ttl' => config('llm.cache.ttl'),
                'max_requests_per_minute' => config('llm.safety.max_requests_per_minute'),
                'max_tokens_per_request' => config('llm.safety.max_tokens_per_request'),
                'content_filtering' => config('llm.safety.content_filtering'),
                'blocked_words' => config('llm.safety.blocked_words'),
                'fallback_enabled' => config('llm.fallback.enabled'),
                'fallback_max_retries' => config('llm.fallback.max_retries'),
                'fallback_timeout' => config('llm.fallback.timeout'),
                'fallback_response' => config('llm.fallback.response'),
                'monitoring_enabled' => config('llm.monitoring.enabled'),
                'log_requests' => config('llm.monitoring.log_requests'),
                'log_responses' => config('llm.monitoring.log_responses'),
                'log_errors' => config('llm.monitoring.log_errors'),
                'metrics_enabled' => config('llm.monitoring.metrics_enabled'),
                'health_status' => 'unknown'
            ]);
        });

        return $settings;
    }

    /**
     * Clear settings cache
     */
    public static function clearCache(): void
    {
        Cache::forget('llm_settings');
    }

    /**
     * Check if the LLM is ready for use
     */
    public function isReady(): bool
    {
        return $this->model_path && 
               file_exists($this->model_path) && 
               $this->health_status !== 'critical';
    }

    /**
     * Get HTML status badge
     */
    public function getHealthStatusBadgeAttribute(): string
    {
        return get_llm_status_badge($this->health_status);
    }

    /**
     * Get performance metrics
     */
    public function getPerformanceMetrics(): array
    {
        return [
            'batch_size' => $this->batch_size,
            'threads' => $this->threads,
            'gpu_layers' => $this->gpu_layers,
            'context_window' => $this->context_window,
            'quantization' => $this->quantization
        ];
    }

    /**
     * Get model configuration
     */
    public function getModelConfig(): array
    {
        return [
            'name' => $this->model_name,
            'size' => $this->model_size,
            'variant' => $this->model_variant,
            'path' => $this->model_path,
            'quantization' => $this->quantization
        ];
    }

    /**
     * Get generation settings
     */
    public function getGenerationSettings(): array
    {
        return [
            'max_tokens' => $this->max_tokens,
            'temperature' => $this->temperature,
            'batch_size' => $this->batch_size,
            'threads' => $this->threads,
            'gpu_layers' => $this->gpu_layers,
            'context_window' => $this->context_window
        ];
    }

    /**
     * Get safety settings
     */
    public function getSafetySettings(): array
    {
        return [
            'max_requests_per_minute' => $this->max_requests_per_minute,
            'max_tokens_per_request' => $this->max_tokens_per_request,
            'content_filtering' => $this->content_filtering,
            'blocked_words' => $this->blocked_words
        ];
    }

    /**
     * Get monitoring settings
     */
    public function getMonitoringSettings(): array
    {
        return [
            'enabled' => $this->monitoring_enabled,
            'log_requests' => $this->log_requests,
            'log_responses' => $this->log_responses,
            'log_errors' => $this->log_errors,
            'metrics_enabled' => $this->metrics_enabled
        ];
    }

    /**
     * Get fallback settings
     */
    public function getFallbackSettings(): array
    {
        return [
            'enabled' => $this->fallback_enabled,
            'max_retries' => $this->fallback_max_retries,
            'timeout' => $this->fallback_timeout,
            'response' => $this->fallback_response
        ];
    }

    /**
     * Get cache settings
     */
    public function getCacheSettings(): array
    {
        return [
            'enabled' => $this->cache_enabled,
            'ttl' => $this->cache_ttl
        ];
    }

    /**
     * Get system status
     */
    public function getSystemStatus(): array
    {
        return [
            'health_status' => $this->health_status,
            'last_health_check' => $this->last_health_check?->diffForHumans(),
            'metrics' => $this->system_metrics
        ];
    }

    /**
     * Update settings with validation
     */
    public function updateSettings(array $settings): bool
    {
        // Validate model configuration
        if (isset($settings['model_name'], $settings['model_size'], $settings['model_variant'])) {
            if (!validate_model_config(
                $settings['model_name'],
                $settings['model_size'],
                $settings['model_variant']
            )) {
                return false;
            }
        }

        // Validate system requirements
        if (isset($settings['model_size']) && !check_system_requirements($settings['model_size'])) {
            return false;
        }

        // Update settings
        $this->update($settings);

        // Clear cache
        self::clearCache();

        return true;
    }
}
