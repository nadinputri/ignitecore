import numpy as np
import pandas as pd
import logging
from datetime import datetime, timedelta
import torch
import torch.nn as nn
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

class PumpDumpDetector:
    """Detects potential pump and dump schemes in cryptocurrency trading"""
    
    def __init__(self, 
                 volume_threshold: float = 3.0,
                 price_threshold: float = 2.0,
                 time_window: int = 24):
        """
        Initialize the detector with configurable thresholds
        
        Args:
            volume_threshold: Multiple of average volume to trigger alert
            price_threshold: Multiple of average price movement to trigger alert
            time_window: Hours to look back for analysis
        """
        self.volume_threshold = volume_threshold
        self.price_threshold = price_threshold
        self.time_window = time_window
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
    def analyze_token(self, 
                     price_data: pd.DataFrame,
                     volume_data: pd.DataFrame) -> Dict:
        """
        Analyze token data for pump and dump patterns
        
        Args:
            price_data: DataFrame with price history
            volume_data: DataFrame with volume history
            
        Returns:
            Dictionary containing analysis results
        """
        try:
            # Calculate baseline metrics
            avg_volume = volume_data['volume'].rolling(window=24).mean()
            avg_price = price_data['close'].rolling(window=24).mean()
            
            # Detect unusual patterns
            volume_spikes = self._detect_volume_spikes(volume_data, avg_volume)
            price_spikes = self._detect_price_spikes(price_data, avg_price)
            
            # Analyze patterns
            risk_score = self._calculate_risk_score(volume_spikes, price_spikes)
            pattern_type = self._classify_pattern(price_data, volume_data)
            
            return {
                'timestamp': datetime.now().isoformat(),
                'risk_score': risk_score,
                'pattern_type': pattern_type,
                'volume_anomalies': volume_spikes,
                'price_anomalies': price_spikes,
                'analysis_window': self.time_window
            }
            
        except Exception as e:
            logger.error(f"Error analyzing token: {str(e)}")
            return None
            
    def _detect_volume_spikes(self, 
                            volume_data: pd.DataFrame,
                            baseline: pd.Series) -> List[Dict]:
        """Detect unusual volume activity"""
        spikes = []
        try:
            for i in range(len(volume_data)):
                if volume_data.iloc[i]['volume'] > baseline.iloc[i] * self.volume_threshold:
                    spikes.append({
                        'timestamp': volume_data.index[i],
                        'volume': volume_data.iloc[i]['volume'],
                        'baseline': baseline.iloc[i],
                        'deviation': volume_data.iloc[i]['volume'] / baseline.iloc[i]
                    })
            return spikes
            
        except Exception as e:
            logger.error(f"Error detecting volume spikes: {str(e)}")
            return []
            
    def _detect_price_spikes(self, 
                           price_data: pd.DataFrame,
                           baseline: pd.Series) -> List[Dict]:
        """Detect unusual price movements"""
        spikes = []
        try:
            for i in range(len(price_data)):
                price_change = abs(price_data.iloc[i]['close'] - baseline.iloc[i])
                if price_change > baseline.iloc[i] * self.price_threshold:
                    spikes.append({
                        'timestamp': price_data.index[i],
                        'price': price_data.iloc[i]['close'],
                        'baseline': baseline.iloc[i],
                        'deviation': price_change / baseline.iloc[i]
                    })
            return spikes
            
        except Exception as e:
            logger.error(f"Error detecting price spikes: {str(e)}")
            return []
            
    def _calculate_risk_score(self,
                            volume_spikes: List[Dict],
                            price_spikes: List[Dict]) -> float:
        """Calculate overall risk score based on detected patterns"""
        try:
            if not volume_spikes and not price_spikes:
                return 0.0
                
            # Weight factors
            volume_weight = 0.6
            price_weight = 0.4
            
            # Calculate component scores
            volume_score = sum(spike['deviation'] for spike in volume_spikes) / len(volume_spikes) if volume_spikes else 0
            price_score = sum(spike['deviation'] for spike in price_spikes) / len(price_spikes) if price_spikes else 0
            
            # Normalize scores to 0-1 range
            volume_score = min(volume_score / 10, 1.0)
            price_score = min(price_score / 5, 1.0)
            
            # Calculate weighted average
            risk_score = (volume_score * volume_weight) + (price_score * price_weight)
            
            return round(risk_score, 2)
            
        except Exception as e:
            logger.error(f"Error calculating risk score: {str(e)}")
            return 0.0
            
    def _classify_pattern(self,
                         price_data: pd.DataFrame,
                         volume_data: pd.DataFrame) -> str:
        """Classify the type of pattern detected"""
        try:
            # Get recent data
            recent_prices = price_data['close'].tail(self.time_window)
            recent_volumes = volume_data['volume'].tail(self.time_window)
            
            # Calculate metrics
            price_change = (recent_prices.iloc[-1] - recent_prices.iloc[0]) / recent_prices.iloc[0]
            volume_change = (recent_volumes.iloc[-1] - recent_volumes.iloc[0]) / recent_volumes.iloc[0]
            
            # Classify pattern
            if price_change > 0.5 and volume_change > 2.0:
                return "potential_pump"
            elif price_change < -0.3 and volume_change > 1.5:
                return "potential_dump"
            elif abs(price_change) > 0.2 and volume_change > 1.0:
                return "suspicious_activity"
            else:
                return "normal_trading"
                
        except Exception as e:
            logger.error(f"Error classifying pattern: {str(e)}")
            return "unknown"
            
    def monitor_realtime(self,
                        price_feed: pd.DataFrame,
                        alert_threshold: float = 0.7) -> Optional[Dict]:
        """
        Monitor real-time data for potential pump and dump activity
        
        Args:
            price_feed: Real-time price and volume data
            alert_threshold: Risk score threshold for generating alerts
            
        Returns:
            Alert dictionary if risk threshold exceeded, None otherwise
        """
        try:
            # Analyze latest data
            analysis = self.analyze_token(
                price_feed[['open', 'high', 'low', 'close']],
                price_feed[['volume']]
            )
            
            if analysis and analysis['risk_score'] >= alert_threshold:
                return {
                    'timestamp': datetime.now().isoformat(),
                    'alert_type': 'pump_dump_warning',
                    'risk_score': analysis['risk_score'],
                    'pattern_type': analysis['pattern_type'],
                    'details': {
                        'price': price_feed['close'].iloc[-1],
                        'volume': price_feed['volume'].iloc[-1],
                        'time_window': self.time_window
                    }
                }
            return None
            
        except Exception as e:
            logger.error(f"Error monitoring real-time data: {str(e)}")
            return None
            
    def generate_report(self,
                       token_data: pd.DataFrame,
                       time_range: Tuple[datetime, datetime]) -> Dict:
        """
        Generate a comprehensive analysis report
        
        Args:
            token_data: Historical price and volume data
            time_range: Start and end times for analysis
            
        Returns:
            Dictionary containing detailed analysis results
        """
        try:
            # Filter data for time range
            mask = (token_data.index >= time_range[0]) & (token_data.index <= time_range[1])
            period_data = token_data[mask]
            
            # Perform analysis
            analysis = self.analyze_token(
                period_data[['open', 'high', 'low', 'close']],
                period_data[['volume']]
            )
            
            if not analysis:
                return {
                    'status': 'error',
                    'message': 'Failed to analyze token data'
                }
                
            # Add additional metrics
            analysis['metrics'] = {
                'total_volume': period_data['volume'].sum(),
                'price_volatility': period_data['close'].std() / period_data['close'].mean(),
                'max_price': period_data['high'].max(),
                'min_price': period_data['low'].min(),
                'volume_concentration': self._calculate_volume_concentration(period_data)
            }
            
            # Add recommendations
            analysis['recommendations'] = self._generate_recommendations(analysis)
            
            return analysis
            
        except Exception as e:
            logger.error(f"Error generating report: {str(e)}")
            return {
                'status': 'error',
                'message': str(e)
            }
            
    def _calculate_volume_concentration(self, data: pd.DataFrame) -> float:
        """Calculate volume concentration ratio"""
        try:
            top_volume = data.nlargest(int(len(data) * 0.1), 'volume')['volume'].sum()
            total_volume = data['volume'].sum()
            return round(top_volume / total_volume, 2)
        except Exception as e:
            logger.error(f"Error calculating volume concentration: {str(e)}")
            return 0.0
            
    def _generate_recommendations(self, analysis: Dict) -> List[str]:
        """Generate trading recommendations based on analysis"""
        recommendations = []
        
        try:
            risk_score = analysis['risk_score']
            pattern_type = analysis['pattern_type']
            
            if risk_score > 0.8:
                recommendations.append("HIGH RISK: Extreme caution advised. Potential pump and dump in progress.")
            elif risk_score > 0.6:
                recommendations.append("MEDIUM RISK: Suspicious activity detected. Monitor closely.")
            elif risk_score > 0.4:
                recommendations.append("LOW RISK: Some unusual patterns detected. Exercise normal caution.")
                
            if pattern_type == "potential_pump":
                recommendations.append("Warning: Indicators suggest artificial price inflation.")
            elif pattern_type == "potential_dump":
                recommendations.append("Warning: Rapid sell-off may be imminent.")
                
            return recommendations
            
        except Exception as e:
            logger.error(f"Error generating recommendations: {str(e)}")
            return ["Error generating recommendations"]
