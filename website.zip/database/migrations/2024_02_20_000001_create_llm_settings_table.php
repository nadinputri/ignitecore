<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('llm_settings', function (Blueprint $table) {
            $table->id();
            
            // Model Configuration
            $table->string('model_name')->default('llama2');
            $table->string('model_size')->default('7B');
            $table->string('model_variant')->default('chat');
            $table->string('model_path')->nullable();
            $table->string('quantization')->default('4-bit');

            // Performance Settings
            $table->integer('batch_size')->default(32);
            $table->integer('threads')->default(4);
            $table->integer('gpu_layers')->default(-1);
            $table->integer('context_window')->default(4096);
            $table->integer('max_tokens')->default(2048);
            $table->float('temperature')->default(0.7);

            // Cache Settings
            $table->boolean('cache_enabled')->default(true);
            $table->integer('cache_ttl')->default(3600);

            // Safety Settings
            $table->integer('max_requests_per_minute')->default(60);
            $table->integer('max_tokens_per_request')->default(4096);
            $table->boolean('content_filtering')->default(true);
            $table->json('blocked_words')->nullable();

            // Fallback Settings
            $table->boolean('fallback_enabled')->default(true);
            $table->integer('fallback_max_retries')->default(3);
            $table->integer('fallback_timeout')->default(30);
            $table->string('fallback_response')->nullable();

            // Monitoring Settings
            $table->boolean('monitoring_enabled')->default(true);
            $table->boolean('log_requests')->default(true);
            $table->boolean('log_responses')->default(true);
            $table->boolean('log_errors')->default(true);
            $table->boolean('metrics_enabled')->default(true);

            // System Status
            $table->string('health_status')->default('unknown');
            $table->timestamp('last_health_check')->nullable();
            $table->json('system_metrics')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('llm_settings');
    }
};
