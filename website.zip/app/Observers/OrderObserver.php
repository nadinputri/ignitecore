<?php

namespace App\Observers;

use App\Models\Order;
use App\Notifications\OrderStatusChanged;
use Illuminate\Support\Facades\Log;

class OrderObserver
{
    /**
     * Handle the Order "created" event.
     *
     * @param  \App\Models\Order  $order
     * @return void
     */
    public function created(Order $order)
    {
        activity()
            ->performedOn($order)
            ->log('Order created');
    }

    /**
     * Handle the Order "updating" event.
     *
     * @param  \App\Models\Order  $order
     * @return void
     */
    public function updating(Order $order)
    {
        // Store the original status before it changes
        $order->previousStatus = $order->getOriginal('status');
    }

    /**
     * Handle the Order "updated" event.
     *
     * @param  \App\Models\Order  $order
     * @return void
     */
    public function updated(Order $order)
    {
        // Check if status has changed
        if ($order->wasChanged('status')) {
            $previousStatus = $order->previousStatus;
            $newStatus = $order->status;

            // Log the status change
            activity()
                ->performedOn($order)
                ->withProperties([
                    'old_status' => $previousStatus,
                    'new_status' => $newStatus,
                ])
                ->log('Order status changed');

            // Prepare additional message based on status
            $additionalMessage = null;

            switch ($newStatus) {
                case 'price_offered':
                    $additionalMessage = "We've offered a price of $" . number_format($order->initial_price, 2) . " for your order.";
                    break;

                case 'accepted':
                    $additionalMessage = "Your payment of $" . number_format($order->final_price, 2) . " has been processed successfully.";
                    break;

                case 'completed':
                    $additionalMessage = "Your order has been completed successfully. Please review the deliverables.";
                    break;

                case 'cancelled':
                    $additionalMessage = "Your order has been cancelled. No payment has been processed.";
                    break;

                case 'refunded':
                    $additionalMessage = "A refund of $" . number_format($order->final_price, 2) . " has been processed to your wallet.";
                    break;
            }

            try {
                // Send notification to user
                $order->user->notify(new OrderStatusChanged(
                    $order,
                    $previousStatus,
                    $newStatus,
                    $additionalMessage
                ));
            } catch (\Exception $e) {
                Log::error('Failed to send order status notification', [
                    'order_id' => $order->id,
                    'error' => $e->getMessage()
                ]);
            }
        }

        // Log price changes
        if ($order->wasChanged('initial_price')) {
            activity()
                ->performedOn($order)
                ->withProperties([
                    'old_price' => $order->getOriginal('initial_price'),
                    'new_price' => $order->initial_price,
                ])
                ->log('Initial price set');
        }

        if ($order->wasChanged('counter_price')) {
            activity()
                ->performedOn($order)
                ->withProperties([
                    'old_price' => $order->getOriginal('counter_price'),
                    'new_price' => $order->counter_price,
                ])
                ->log('Counter price offered');
        }

        if ($order->wasChanged('final_price')) {
            activity()
                ->performedOn($order)
                ->withProperties([
                    'old_price' => $order->getOriginal('final_price'),
                    'new_price' => $order->final_price,
                ])
                ->log('Final price set');
        }

        // Log admin notes changes
        if ($order->wasChanged('admin_notes')) {
            activity()
                ->performedOn($order)
                ->withProperties([
                    'old_notes' => $order->getOriginal('admin_notes'),
                    'new_notes' => $order->admin_notes,
                ])
                ->log('Admin notes updated');
        }
    }

    /**
     * Handle the Order "deleted" event.
     *
     * @param  \App\Models\Order  $order
     * @return void
     */
    public function deleted(Order $order)
    {
        activity()
            ->performedOn($order)
            ->log('Order deleted');
    }

    /**
     * Handle the Order "restored" event.
     *
     * @param  \App\Models\Order  $order
     * @return void
     */
    public function restored(Order $order)
    {
        activity()
            ->performedOn($order)
            ->log('Order restored');
    }

    /**
     * Handle the Order "force deleted" event.
     *
     * @param  \App\Models\Order  $order
     * @return void
     */
    public function forceDeleted(Order $order)
    {
        activity()
            ->performedOn($order)
            ->log('Order permanently deleted');
    }
}
