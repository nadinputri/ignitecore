<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Traits\LogsActivity;

class TelegramBotCredit extends Model
{
    use HasFactory, LogsActivity;

    protected $fillable = [
        'telegram_bot_id',
        'user_id',
        'credits_used',
        'action_type',
        'metadata'
    ];

    protected $casts = [
        'metadata' => 'array'
    ];

    protected static $logAttributes = [
        'credits_used',
        'action_type',
        'metadata'
    ];

    public function telegramBot()
    {
        return $this->belongsTo(TelegramBot::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public static function deductCredits($bot, $amount, $action, $metadata = [])
    {
        $user = $bot->user;
        
        if ($user->wallet->balance < $amount) {
            throw new \Exception('Insufficient credits');
        }

        // Create wallet transaction
        $user->wallet->withdraw($amount, 'Telegram Bot Credit Usage: ' . $action);

        // Log credit usage
        return self::create([
            'telegram_bot_id' => $bot->id,
            'user_id' => $user->id,
            'credits_used' => $amount,
            'action_type' => $action,
            'metadata' => $metadata
        ]);
    }
}
