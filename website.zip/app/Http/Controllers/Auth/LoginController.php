<?php

namespace App\Http\Controllers\Auth;

use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Services\SecurityService;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    /**
     * Handle a login request to the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response|\Illuminate\Http\JsonResponse
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function login(Request $request)
    {
        $this->validateLogin($request);

        // Check if the user exists and is locked
        $user = $this->guard()->getProvider()->retrieveByCredentials([
            $this->username() => $request->{$this->username()}
        ]);

        if ($user && $user->isLocked()) {
            return $this->sendLockedAccountResponse($request, $user);
        }

        // If the class is using the ThrottlesLogins trait, we can automatically throttle
        // the login attempts for this application. We'll key this by the username and
        // the IP address of the client making these requests into this application.
        if (method_exists($this, 'hasTooManyLoginAttempts') &&
            $this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);

            return $this->sendLockoutResponse($request);
        }

        if ($this->attemptLogin($request)) {
            if ($request->hasSession()) {
                $request->session()->put('auth.password_confirmed_at', time());
            }
            
            // Reset login attempts on successful login
            if ($user) {
                $user->resetLoginAttempts();
                $user->last_login_ip = $request->ip();
                $user->save();
                
                // Log the successful login
                app(SecurityService::class)->logSecurityEvent(
                    'login_success',
                    'User logged in successfully',
                    ['ip' => $request->ip(), 'user_agent' => $request->userAgent()]
                );
            }

            return $this->sendLoginResponse($request);
        }

        // If the login attempt was unsuccessful we will increment the number of attempts
        // to login and redirect the user back to the login form. Of course, when this
        // user surpasses their maximum number of attempts they will get locked out.
        $this->incrementLoginAttempts($request);
        
        // Increment user-specific login attempts counter
        if ($user) {
            $user->incrementLoginAttempts();
            
            // Log the failed login attempt
            app(SecurityService::class)->logSecurityEvent(
                'login_failed',
                'Failed login attempt',
                ['ip' => $request->ip(), 'user_agent' => $request->userAgent()]
            );
        }

        return $this->sendFailedLoginResponse($request);
    }
    
    /**
     * Send the response after the user was authenticated.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\JsonResponse
     */
    protected function sendLoginResponse(Request $request)
    {
        $request->session()->regenerate();

        $this->clearLoginAttempts($request);

        if ($response = $this->authenticated($request, $this->guard()->user())) {
            return $response;
        }

        return $request->wantsJson()
                    ? new JsonResponse([], 204)
                    : redirect()->intended($this->redirectPath());
    }

    /**
     * Get the needed authorization credentials from the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected function credentials(Request $request)
    {
        return $request->only($this->username(), 'password');
    }

    /**
     * Send the response after the user was locked out.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    protected function sendLockoutResponse(Request $request)
    {
        $seconds = $this->limiter()->availableIn(
            $this->throttleKey($request)
        );

        $message = 'Too many login attempts. Please try again in ' . $seconds . ' seconds.';

        $user = $this->guard()->getProvider()->retrieveByCredentials([
            $this->username() => $request->{$this->username()}
        ]);

        if ($user) {
            app(SecurityService::class)->logSecurityEvent(
                'login_locked_out',
                'User account locked out due to too many failed login attempts',
                ['user_id' => $user->id, 'ip' => $request->ip()]
            );
        }

        return $this->throwFailedLoginException($request, $message);
    }

    /**
     * Send the response for a locked account.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\RedirectResponse
     */
    protected function sendLockedAccountResponse(Request $request, $user)
    {
        $message = 'Your account is locked. Please try again in ' . $user->locked_until->diffInMinutes() . ' minutes.';

        app(SecurityService::class)->logSecurityEvent(
            'login_locked_account',
            'User attempted to login to a locked account',
            ['user_id' => $user->id, 'ip' => $request->ip()]
        );

        return $this->throwFailedLoginException($request, $message);
    }
}
