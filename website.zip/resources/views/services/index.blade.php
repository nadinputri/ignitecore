@extends('layouts.app')

@section('styles')
<style>
.services-header {
    padding: 6rem 0;
    position: relative;
    overflow: hidden;
    background: linear-gradient(45deg, var(--background-dark), var(--background-light));
}

.services-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: 
        linear-gradient(90deg, var(--grid-color) 1px, transparent 1px),
        linear-gradient(var(--grid-color) 1px, transparent 1px);
    background-size: 30px 30px;
    transform: perspective(500px) rotateX(60deg);
    animation: grid-move 20s linear infinite;
}

.category-filter {
    margin-bottom: 4rem;
    position: relative;
    z-index: 1;
}

.category-btn {
    background: transparent;
    border: 2px solid var(--primary-color);
    color: var(--primary-color);
    padding: 0.5rem 1.5rem;
    margin: 0.5rem;
    font-family: 'Press Start 2P', cursive;
    font-size: 0.8rem;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.category-btn::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 300%;
    height: 300%;
    background: var(--primary-color);
    transition: all 0.5s ease;
    transform: translate(-50%, -50%) rotate(45deg) scale(0);
    z-index: -1;
}

.category-btn:hover::before,
.category-btn.active::before {
    transform: translate(-50%, -50%) rotate(45deg) scale(1);
}

.category-btn:hover,
.category-btn.active {
    color: var(--background-dark);
}

.service-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 2rem;
    padding: 2rem 0;
}

.service-card {
    position: relative;
    height: 400px;
    perspective: 1000px;
    cursor: pointer;
}

.service-card-inner {
    position: relative;
    width: 100%;
    height: 100%;
    transition: transform 0.8s;
    transform-style: preserve-3d;
}

.service-card:hover .service-card-inner {
    transform: rotateY(180deg);
}

.service-card-front,
.service-card-back {
    position: absolute;
    width: 100%;
    height: 100%;
    backface-visibility: hidden;
    padding: 2rem;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    border: 2px solid var(--primary-color);
    background: linear-gradient(45deg, var(--background-dark), var(--background-light));
}

.service-card-back {
    transform: rotateY(180deg);
    background: linear-gradient(45deg, var(--background-light), var(--background-dark));
}

.service-icon {
    font-size: 3rem;
    color: var(--accent-color);
    margin-bottom: 1.5rem;
}

.service-price {
    font-family: 'Press Start 2P', cursive;
    color: var(--secondary-color);
    font-size: 1.5rem;
    margin: 1rem 0;
}

.service-features {
    list-style: none;
    padding: 0;
    margin: 1rem 0;
}

.service-features li {
    margin: 0.5rem 0;
    color: var(--accent-color);
}

.service-features li::before {
    content: '>';
    color: var(--primary-color);
    margin-right: 0.5rem;
}

.order-btn {
    position: relative;
    overflow: hidden;
    margin-top: auto;
}

.order-btn::after {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: linear-gradient(45deg, transparent, rgba(255,255,255,0.1), transparent);
    transform: rotate(45deg);
    animation: shine 3s infinite;
}

@keyframes shine {
    0% { transform: translateX(-100%) rotate(45deg); }
    100% { transform: translateX(100%) rotate(45deg); }
}

.search-box {
    position: relative;
    margin-bottom: 2rem;
}

.search-input {
    width: 100%;
    padding: 1rem;
    background: transparent;
    border: 2px solid var(--primary-color);
    color: var(--text-color);
    font-family: 'VT323', monospace;
    font-size: 1.2rem;
}

.search-input:focus {
    outline: none;
    border-color: var(--accent-color);
    box-shadow: 0 0 15px var(--accent-color);
}

.no-results {
    text-align: center;
    padding: 3rem;
    font-size: 1.5rem;
    color: var(--accent-color);
}

/* Loading animation */
.loading-services {
    position: relative;
    height: 200px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.loading-services::after {
    content: 'Loading Services...';
    font-family: 'Press Start 2P', cursive;
    color: var(--primary-color);
    animation: blink 1s infinite;
}

@keyframes blink {
    0%, 100% { opacity: 1; }
    50% { opacity: 0; }
}

/* Responsive design */
@media (max-width: 768px) {
    .service-grid {
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    }

    .service-card {
        height: 350px;
    }

    .category-btn {
        font-size: 0.7rem;
        padding: 0.4rem 1rem;
    }
}
</style>
@endsection

@section('content')
<section class="services-header">
    <div class="container">
        <h1 class="text-center mb-5 glitch" data-text="Our Services">Our Services</h1>
        
        <!-- Search Box -->
        <div class="search-box">
            <input type="text" class="search-input" placeholder="Search services..." id="searchInput">
        </div>

        <!-- Category Filter -->
        <div class="category-filter text-center">
            <button class="category-btn active" data-category="all">All</button>
            @foreach($categories as $category)
                <button class="category-btn" data-category="{{ $category->id }}">
                    {{ $category->name }}
                </button>
            @endforeach
        </div>
    </div>
</section>

<div class="container py-5">
    <div class="service-grid" id="serviceGrid">
        @foreach($services as $service)
        <div class="service-card" data-category="{{ $service->category_id }}" data-name="{{ strtolower($service->name) }}">
            <div class="service-card-inner">
                <div class="service-card-front">
                    <i class="fas fa-{{ $service->icon ?? 'star' }} service-icon"></i>
                    <h3>{{ $service->name }}</h3>
                    <div class="service-price">{{ $service->formatted_price }}</div>
                    <p>{{ Str::limit($service->description, 100) }}</p>
                </div>
                <div class="service-card-back">
                    <h3>Features</h3>
                    <ul class="service-features">
                        @foreach(explode("\n", $service->features ?? '') as $feature)
                            @if(trim($feature))
                                <li>{{ trim($feature) }}</li>
                            @endif
                        @endforeach
                    </ul>
                    <a href="{{ route('services.show', $service) }}" class="btn btn-primary order-btn">
                        Learn More
                    </a>
                </div>
            </div>
        </div>
        @endforeach
    </div>

    <div class="no-results" style="display: none;">
        <i class="fas fa-search mb-3" style="font-size: 3rem;"></i>
        <p>No services found matching your criteria.</p>
    </div>
</div>
@endsection

@section('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const serviceGrid = document.getElementById('serviceGrid');
    const searchInput = document.getElementById('searchInput');
    const categoryBtns = document.querySelectorAll('.category-btn');
    const noResults = document.querySelector('.no-results');
    let currentCategory = 'all';

    // Filter functions
    function filterServices() {
        const searchTerm = searchInput.value.toLowerCase();
        const services = document.querySelectorAll('.service-card');
        let visibleCount = 0;

        services.forEach(service => {
            const name = service.dataset.name;
            const category = service.dataset.category;
            const matchesSearch = name.includes(searchTerm);
            const matchesCategory = currentCategory === 'all' || category === currentCategory;

            if (matchesSearch && matchesCategory) {
                service.style.display = '';
                visibleCount++;
            } else {
                service.style.display = 'none';
            }
        });

        noResults.style.display = visibleCount === 0 ? 'block' : 'none';
    }

    // Event listeners
    searchInput.addEventListener('input', filterServices);

    categoryBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            categoryBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            currentCategory = this.dataset.category;
            filterServices();
        });
    });

    // Animation on scroll
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    });

    document.querySelectorAll('.service-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.5s ease';
        observer.observe(card);
    });
});
</script>
@endsection
