@extends('layouts.admin')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Admin Dashboard</h2>
        </div>
    </div>

    <!-- Stats Overview -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5 class="card-title">Total Users</h5>
                    <div class="h2">{{ \App\Models\User::count() }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5 class="card-title">Active Orders</h5>
                    <div class="h2">{{ \App\Models\Order::active()->count() }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <h5 class="card-title">Active Bots</h5>
                    <div class="h2">{{ \App\Models\TelegramBot::where('status', 'active')->count() }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h5 class="card-title">Open Tickets</h5>
                    <div class="h2">{{ \App\Models\SupportTicket::open()->count() }}</div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Quick Actions -->
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Quick Actions</h5>
                </div>
                <div class="card-body">
                    <div class="list-group">
                        <a href="{{ route('admin.services.index') }}" class="list-group-item list-group-item-action">
                            <i class="fas fa-cube"></i> Manage Services
                        </a>
                        <a href="{{ route('admin.telegram-bots.index') }}" class="list-group-item list-group-item-action">
                            <i class="fab fa-telegram"></i> Manage Telegram Bots
                        </a>
                        <a href="{{ route('admin.telegram-bots.settings') }}" class="list-group-item list-group-item-action">
                            <i class="fas fa-cog"></i> Bot Settings
                        </a>
                        <a href="{{ route('admin.orders.index') }}" class="list-group-item list-group-item-action">
                            <i class="fas fa-shopping-cart"></i> View Orders
                        </a>
                        <a href="{{ route('admin.support.index') }}" class="list-group-item list-group-item-action">
                            <i class="fas fa-ticket-alt"></i> Support Tickets
                        </a>
                        <a href="{{ route('admin.activity-logs.index') }}" class="list-group-item list-group-item-action">
                            <i class="fas fa-history"></i> Activity Logs
                        </a>
                        <a href="{{ route('admin.settings.index') }}" class="list-group-item list-group-item-action">
                            <i class="fas fa-cogs"></i> System Settings
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="col-md-8 mb-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Recent Activity</h5>
                    <a href="{{ route('admin.activity-logs.index') }}" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Action</th>
                                    <th>Details</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach(\App\Models\ActivityLog::with('user')->latest()->take(10)->get() as $log)
                                    <tr>
                                        <td>{{ $log->user->name ?? 'System' }}</td>
                                        <td>{{ $log->action }}</td>
                                        <td>{{ Str::limit($log->details, 50) }}</td>
                                        <td>{{ $log->created_at->diffForHumans() }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('styles')
<style>
.card {
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    transition: box-shadow 0.3s ease-in-out;
}

.card:hover {
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.list-group-item-action {
    transition: all 0.2s;
}

.list-group-item-action:hover {
    transform: translateX(5px);
}

.list-group-item-action i {
    width: 20px;
    text-align: center;
    margin-right: 10px;
}
</style>
@endpush
