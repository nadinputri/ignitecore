<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Services\SecurityService;

class ApiSecurity
{
    /**
     * The security service instance.
     *
     * @var \App\Services\SecurityService
     */
    protected $securityService;

    /**
     * Create a new middleware instance.
     *
     * @param  \App\Services\SecurityService  $securityService
     * @return void
     */
    public function __construct(SecurityService $securityService)
    {
        $this->securityService = $securityService;
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // Check for suspicious IP
        if ($this->securityService->isSuspiciousIp($request->ip())) {
            $this->securityService->logSecurityEvent(
                'api_blocked',
                'API request blocked from suspicious IP',
                ['ip' => $request->ip(), 'endpoint' => $request->path()]
            );
            
            return response()->json([
                'error' => 'Access denied',
                'message' => 'Your request has been blocked for security reasons.'
            ], 403);
        }
        
        // Add security headers to API responses
        $response = $next($request);
        
        // Add security headers
        $response->headers->set('X-Content-Type-Options', 'nosniff');
        $response->headers->set('X-Frame-Options', 'DENY');
        $response->headers->set('X-XSS-Protection', '1; mode=block');
        $response->headers->set('Referrer-Policy', 'strict-origin-when-cross-origin');
        
        // Add API-specific headers
        $response->headers->set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        $response->headers->set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
        
        // Log API access for sensitive endpoints
        if (in_array($request->path(), ['api/user', 'api/wallet', 'api/orders'])) {
            $this->securityService->logSecurityEvent(
                'api_access',
                'Sensitive API endpoint accessed',
                [
                    'endpoint' => $request->path(),
                    'method' => $request->method(),
                    'user_id' => Auth::id(),
                    'ip' => $request->ip()
                ]
            );
        }
        
        return $response;
    }
}
