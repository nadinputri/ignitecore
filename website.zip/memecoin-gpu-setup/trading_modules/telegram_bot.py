import os
import sys
import logging
import asyncio
import aiohttp
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Union
from telethon import TelegramClient
from telethon.tl.custom import Message
import json

logger = logging.getLogger(__name__)

class TelegramBot:
    """Handles Telegram bot operations for trading alerts and monitoring"""
    
    def __init__(self, config_path: str = "config/telegram.json"):
        """
        Initialize the Telegram bot
        
        Args:
            config_path: Path to configuration file
        """
        self.config = self._load_config(config_path)
        self.client = None
        self.alert_channels = set()
        self.monitoring_active = False
        
    def _load_config(self, config_path: str) -> Dict:
        """Load bot configuration from file"""
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
            return config
        except Exception as e:
            logger.error(f"Error loading config: {str(e)}")
            return {
                'api_id': os.getenv('TELEGRAM_API_ID'),
                'api_hash': os.getenv('TELEGRAM_API_HASH'),
                'bot_token': os.getenv('TELEGRAM_BOT_TOKEN'),
                'alert_chat_ids': []
            }
            
    async def start(self):
        """Start the Telegram bot"""
        try:
            self.client = TelegramClient(
                'memecoin_bot_session',
                self.config['api_id'],
                self.config['api_hash']
            )
            await self.client.start(bot_token=self.config['bot_token'])
            logger.info("Telegram bot started successfully")
            
            # Register message handlers
            self.client.add_event_handler(self._handle_message)
            
            # Initialize alert channels
            self.alert_channels = set(self.config.get('alert_chat_ids', []))
            
        except Exception as e:
            logger.error(f"Error starting Telegram bot: {str(e)}")
            raise
            
    async def stop(self):
        """Stop the Telegram bot"""
        if self.client:
            await self.client.disconnect()
            logger.info("Telegram bot stopped")
            
    async def _handle_message(self, event: Message):
        """Handle incoming messages"""
        try:
            if not event.is_private:
                return
                
            text = event.text.lower()
            chat_id = event.chat_id
            
            if text.startswith('/start'):
                await self._send_welcome_message(chat_id)
            elif text.startswith('/help'):
                await self._send_help_message(chat_id)
            elif text.startswith('/subscribe'):
                await self._handle_subscribe(chat_id)
            elif text.startswith('/unsubscribe'):
                await self._handle_unsubscribe(chat_id)
            elif text.startswith('/status'):
                await self._send_status(chat_id)
                
        except Exception as e:
            logger.error(f"Error handling message: {str(e)}")
            
    async def _send_welcome_message(self, chat_id: int):
        """Send welcome message to new users"""
        welcome_text = """
🚀 Welcome to MemeBot Trading Assistant! 🚀

I'm here to help you monitor and analyze meme coin trading activities.

Available commands:
/help - Show available commands
/subscribe - Subscribe to trading alerts
/unsubscribe - Unsubscribe from alerts
/status - Check current monitoring status

Stay safe and happy trading! 📈
"""
        await self.client.send_message(chat_id, welcome_text)
        
    async def _send_help_message(self, chat_id: int):
        """Send help message with available commands"""
        help_text = """
📚 Available Commands:

/start - Start the bot
/help - Show this help message
/subscribe - Get trading alerts
/unsubscribe - Stop receiving alerts
/status - Check monitoring status

For more information, visit our documentation at:
https://docs.memecoin-bot.com
"""
        await self.client.send_message(chat_id, help_text)
        
    async def _handle_subscribe(self, chat_id: int):
        """Handle subscription requests"""
        if chat_id in self.alert_channels:
            await self.client.send_message(
                chat_id,
                "✅ You're already subscribed to trading alerts!"
            )
        else:
            self.alert_channels.add(chat_id)
            self._save_subscribers()
            await self.client.send_message(
                chat_id,
                "🎉 Successfully subscribed to trading alerts!"
            )
            
    async def _handle_unsubscribe(self, chat_id: int):
        """Handle unsubscription requests"""
        if chat_id in self.alert_channels:
            self.alert_channels.remove(chat_id)
            self._save_subscribers()
            await self.client.send_message(
                chat_id,
                "👋 You've been unsubscribed from trading alerts."
            )
        else:
            await self.client.send_message(
                chat_id,
                "ℹ️ You're not currently subscribed to alerts."
            )
            
    def _save_subscribers(self):
        """Save current subscribers to config"""
        try:
            self.config['alert_chat_ids'] = list(self.alert_channels)
            with open(self.config_path, 'w') as f:
                json.dump(self.config, f, indent=4)
        except Exception as e:
            logger.error(f"Error saving subscribers: {str(e)}")
            
    async def _send_status(self, chat_id: int):
        """Send current monitoring status"""
        status_text = f"""
📊 Current Status:

Monitoring Active: {'✅' if self.monitoring_active else '❌'}
Subscribed Users: {len(self.alert_channels)}
Last Update: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        await self.client.send_message(chat_id, status_text)
        
    async def send_alert(self, 
                        alert_data: Dict,
                        chart_path: Optional[str] = None):
        """
        Send trading alert to subscribed users
        
        Args:
            alert_data: Dictionary containing alert information
            chart_path: Optional path to chart image
        """
        try:
            alert_text = self._format_alert(alert_data)
            
            for chat_id in self.alert_channels:
                try:
                    if chart_path and os.path.exists(chart_path):
                        await self.client.send_file(
                            chat_id,
                            chart_path,
                            caption=alert_text
                        )
                    else:
                        await self.client.send_message(chat_id, alert_text)
                except Exception as e:
                    logger.error(f"Error sending alert to {chat_id}: {str(e)}")
                    
        except Exception as e:
            logger.error(f"Error sending alerts: {str(e)}")
            
    def _format_alert(self, alert_data: Dict) -> str:
        """Format alert data into readable message"""
        try:
            alert_type = alert_data.get('type', 'UNKNOWN')
            symbol = alert_data.get('symbol', 'UNKNOWN')
            price = alert_data.get('price', 0.0)
            change = alert_data.get('change', 0.0)
            volume = alert_data.get('volume', 0)
            
            alert_text = f"""
🚨 {alert_type.upper()} ALERT 🚨

Symbol: {symbol}
Price: ${price:.8f}
24h Change: {change:+.2f}%
Volume: ${volume:,.2f}

{self._get_alert_recommendation(alert_data)}

⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} UTC
"""
            return alert_text
            
        except Exception as e:
            logger.error(f"Error formatting alert: {str(e)}")
            return "Error formatting alert message"
            
    def _get_alert_recommendation(self, alert_data: Dict) -> str:
        """Generate trading recommendation based on alert data"""
        try:
            alert_type = alert_data.get('type', '').lower()
            risk_score = alert_data.get('risk_score', 0.5)
            
            if 'pump' in alert_type:
                if risk_score > 0.7:
                    return "⚠️ High risk of pump and dump. Extreme caution advised."
                else:
                    return "📈 Potential upward movement detected. Monitor closely."
            elif 'dump' in alert_type:
                return "📉 Significant price drop detected. Consider securing positions."
            else:
                return "👀 Unusual market activity detected. Stay vigilant."
                
        except Exception as e:
            logger.error(f"Error generating recommendation: {str(e)}")
            return "Unable to generate recommendation"
            
    async def send_chart(self,
                        chat_id: int,
                        chart_data: pd.DataFrame,
                        title: str = "Price Chart"):
        """
        Generate and send a price chart
        
        Args:
            chat_id: Telegram chat ID
            chart_data: DataFrame with price/volume data
            title: Chart title
        """
        try:
            # Create chart
            plt.figure(figsize=(10, 6))
            plt.plot(chart_data.index, chart_data['close'])
            plt.title(title)
            plt.xlabel('Time')
            plt.ylabel('Price')
            plt.grid(True)
            
            # Save chart
            chart_path = f"temp_chart_{chat_id}.png"
            plt.savefig(chart_path)
            plt.close()
            
            # Send chart
            await self.client.send_file(chat_id, chart_path)
            
            # Clean up
            os.remove(chart_path)
            
        except Exception as e:
            logger.error(f"Error sending chart: {str(e)}")
            await self.client.send_message(
                chat_id,
                "Sorry, there was an error generating the chart."
            )
            
    async def broadcast_message(self,
                              message: str,
                              exclude_ids: Optional[List[int]] = None):
        """
        Broadcast message to all subscribers
        
        Args:
            message: Message to broadcast
            exclude_ids: List of chat IDs to exclude
        """
        exclude_ids = exclude_ids or []
        
        for chat_id in self.alert_channels:
            if chat_id not in exclude_ids:
                try:
                    await self.client.send_message(chat_id, message)
                except Exception as e:
                    logger.error(f"Error broadcasting to {chat_id}: {str(e)}")
                    
    async def start_monitoring(self):
        """Start monitoring process"""
        self.monitoring_active = True
        await self.broadcast_message("🟢 Monitoring system activated")
        
    async def stop_monitoring(self):
        """Stop monitoring process"""
        self.monitoring_active = False
        await self.broadcast_message("🔴 Monitoring system deactivated")
