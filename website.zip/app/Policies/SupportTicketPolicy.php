<?php

namespace App\Policies;

use App\Models\User;
use App\Models\SupportTicket;
use Illuminate\Auth\Access\HandlesAuthorization;

class SupportTicketPolicy
{
    use HandlesAuthorization;

    /**
     * Perform pre-authorization checks.
     *
     * @param  \App\Models\User  $user
     * @param  string  $ability
     * @return bool|null
     */
    public function before(User $user, $ability)
    {
        if ($user->isAdmin()) {
            return true;
        }
    }

    /**
     * Determine whether the user can view any tickets.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function viewAny(User $user)
    {
        return true;
    }

    /**
     * Determine whether the user can view the ticket.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\SupportTicket  $ticket
     * @return bool
     */
    public function view(User $user, SupportTicket $ticket)
    {
        return $user->id === $ticket->user_id;
    }

    /**
     * Determine whether the user can create tickets.
     *
     * @param  \App\Models\User  $user
     * @return bool
     */
    public function create(User $user)
    {
        return true;
    }

    /**
     * Determine whether the user can reply to the ticket.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\SupportTicket  $ticket
     * @return bool
     */
    public function reply(User $user, SupportTicket $ticket)
    {
        return $user->id === $ticket->user_id && !in_array($ticket->status, ['resolved', 'closed']);
    }

    /**
     * Determine whether the user can update the ticket.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\SupportTicket  $ticket
     * @return bool
     */
    public function update(User $user, SupportTicket $ticket)
    {
        return $user->id === $ticket->user_id && !in_array($ticket->status, ['resolved', 'closed']);
    }

    /**
     * Determine whether the user can close the ticket.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\SupportTicket  $ticket
     * @return bool
     */
    public function close(User $user, SupportTicket $ticket)
    {
        return $user->id === $ticket->user_id && !in_array($ticket->status, ['resolved', 'closed']);
    }

    /**
     * Determine whether the user can reopen the ticket.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\SupportTicket  $ticket
     * @return bool
     */
    public function reopen(User $user, SupportTicket $ticket)
    {
        return $user->id === $ticket->user_id && in_array($ticket->status, ['resolved', 'closed']);
    }

    /**
     * Determine whether the user can download ticket attachments.
     *
     * @param  \App\Models\User  $user
     * @param  \App\Models\SupportTicket  $ticket
     * @return bool
     */
    public function downloadAttachments(User $user, SupportTicket $ticket)
    {
        return $user->id === $ticket->user_id;
    }
}
