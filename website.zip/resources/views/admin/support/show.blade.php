@extends('layouts.admin')

@section('content')
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="mb-0">Ticket #{{ $ticket->ticket_number }}</h5>
                            <p class="text-muted mb-0">{{ $ticket->subject }}</p>
                        </div>
                        <div>
                            <a href="{{ route('admin.support-tickets.index') }}" class="btn btn-outline-secondary btn-sm">
                                Back to Tickets
                            </a>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <!-- Ticket Controls -->
                    <div class="row mb-4">
                        <div class="col-md-8">
                            <!-- Status and Priority Badges -->
                            <span class="badge bg-{{ 
                                $ticket->status === 'open' ? 'warning' : 
                                ($ticket->status === 'in_progress' ? 'info' : 
                                ($ticket->status === 'resolved' ? 'success' : 'secondary'))
                            }} me-2">
                                {{ ucfirst(str_replace('_', ' ', $ticket->status)) }}
                            </span>
                            <span class="badge bg-{{ 
                                $ticket->priority === 'high' ? 'danger' : 
                                ($ticket->priority === 'medium' ? 'warning' : 'info')
                            }} me-2">
                                Priority: {{ ucfirst($ticket->priority) }}
                            </span>
                            <span class="ms-3 text-muted">
                                Created {{ $ticket->created_at->diffForHumans() }}
                            </span>
                        </div>
                        <div class="col-md-4 text-end">
                            <div class="btn-group">
                                <button type="button" 
                                        class="btn btn-primary btn-sm dropdown-toggle" 
                                        data-bs-toggle="dropdown">
                                    Actions
                                </button>
                                <ul class="dropdown-menu">
                                    <li>
                                        <button type="button" 
                                                class="dropdown-item" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#assignTicketModal">
                                            Assign Ticket
                                        </button>
                                    </li>
                                    <li>
                                        <button type="button" 
                                                class="dropdown-item" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#updateStatusModal">
                                            Update Status
                                        </button>
                                    </li>
                                    <li>
                                        <button type="button" 
                                                class="dropdown-item" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#updatePriorityModal">
                                            Update Priority
                                        </button>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Ticket Information -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6>Customer Information</h6>
                            <p class="mb-1"><strong>Name:</strong> {{ $ticket->user->name }}</p>
                            <p class="mb-1"><strong>Email:</strong> {{ $ticket->user->email }}</p>
                            <p class="mb-0"><strong>Member Since:</strong> {{ $ticket->user->created_at->format('M d, Y') }}</p>
                        </div>
                        <div class="col-md-6">
                            <h6>Ticket Details</h6>
                            <p class="mb-1">
                                <strong>Assigned To:</strong> 
                                {{ $ticket->assignedTo ? $ticket->assignedTo->name : 'Unassigned' }}
                            </p>
                            <p class="mb-1">
                                <strong>Last Updated:</strong> 
                                {{ $ticket->updated_at->format('M d, Y H:i') }}
                            </p>
                            <p class="mb-0">
                                <strong>Total Replies:</strong> 
                                {{ $ticket->replies->count() }}
                            </p>
                        </div>
                    </div>

                    <!-- Original Ticket -->
                    <div class="ticket-message mb-4">
                        <div class="d-flex">
                            <div class="flex-shrink-0">
                                <div class="avatar">
                                    {{ substr($ticket->user->name, 0, 1) }}
                                </div>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <div class="mb-1">
                                    <strong>{{ $ticket->user->name }}</strong>
                                    <small class="text-muted ms-2">{{ $ticket->created_at->format('M d, Y H:i') }}</small>
                                </div>
                                <div class="message-content">
                                    {!! nl2br(e($ticket->description)) !!}
                                </div>
                                @if($ticket->attachments->count() > 0)
                                    <div class="attachments mt-3">
                                        <h6>Attachments:</h6>
                                        <div class="list-group">
                                            @foreach($ticket->attachments as $attachment)
                                                <a href="{{ route('admin.support-tickets.attachments.download', $attachment) }}" 
                                                   class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                                    <div>
                                                        <i class="fas fa-{{ $attachment->getIconClass() }} me-2"></i>
                                                        {{ $attachment->filename }}
                                                    </div>
                                                    <span class="badge bg-primary rounded-pill">
                                                        {{ $attachment->getFormattedSize() }}
                                                    </span>
                                                </a>
                                            @endforeach
                                        </div>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>

                    <!-- Replies -->
                    @foreach($ticket->replies as $reply)
                        <div class="ticket-reply mb-4 {{ $reply->is_admin_reply ? 'admin-reply' : '' }}">
                            <div class="d-flex">
                                <div class="flex-shrink-0">
                                    <div class="avatar {{ $reply->is_admin_reply ? 'admin-avatar' : '' }}">
                                        {{ substr($reply->user->name, 0, 1) }}
                                    </div>
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <div class="mb-1">
                                        <strong>{{ $reply->user->name }}</strong>
                                        @if($reply->is_admin_reply)
                                            <span class="badge bg-info ms-1">Staff</span>
                                        @endif
                                        <small class="text-muted ms-2">{{ $reply->created_at->format('M d, Y H:i') }}</small>
                                    </div>
                                    <div class="message-content">
                                        {!! nl2br(e($reply->message)) !!}
                                    </div>
                                    @if($reply->attachments->count() > 0)
                                        <div class="attachments mt-3">
                                            <h6>Attachments:</h6>
                                            <div class="list-group">
                                                @foreach($reply->attachments as $attachment)
                                                    <a href="{{ route('admin.support-tickets.attachments.download', $attachment) }}" 
                                                       class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                                                        <div>
                                                            <i class="fas fa-{{ $attachment->getIconClass() }} me-2"></i>
                                                            {{ $attachment->filename }}
                                                        </div>
                                                        <span class="badge bg-primary rounded-pill">
                                                            {{ $attachment->getFormattedSize() }}
                                                        </span>
                                                    </a>
                                                @endforeach
                                            </div>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                    @endforeach

                    <!-- Reply Form -->
                    @if(!in_array($ticket->status, ['resolved', 'closed']))
                        <div class="reply-form mt-4">
                            <h5>Add Reply</h5>
                            <form action="{{ route('admin.support-tickets.reply', $ticket) }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="mb-3">
                                    <textarea class="form-control @error('message') is-invalid @enderror" 
                                              name="message" 
                                              rows="4" 
                                              required>{{ old('message') }}</textarea>
                                    @error('message')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3">
                                    <label for="attachments" class="form-label">Attachments (Optional)</label>
                                    <input type="file" 
                                           class="form-control @error('attachments.*') is-invalid @enderror" 
                                           id="attachments" 
                                           name="attachments[]" 
                                           multiple>
                                    @error('attachments.*')
                                        <div class="invalid-feedback">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="mb-3" id="attachment-preview">
                                    <!-- Preview selected files here via JavaScript -->
                                </div>

                                <button type="submit" class="btn btn-primary">
                                    Send Reply
                                </button>
                            </form>
                        </div>
                    @else
                        <div class="alert alert-info">
                            This ticket is {{ $ticket->status }}. You cannot add new replies.
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Assign Ticket Modal -->
<div class="modal fade" id="assignTicketModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.support-tickets.assign', $ticket) }}" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Assign Ticket</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Assign to Admin</label>
                        <select name="admin_id" class="form-select" required>
                            <option value="">Select Admin</option>
                            @foreach($admins as $admin)
                                <option value="{{ $admin->id }}" 
                                        {{ $ticket->assigned_to === $admin->id ? 'selected' : '' }}>
                                    {{ $admin->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Assign</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Update Status Modal -->
<div class="modal fade" id="updateStatusModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.support-tickets.update-status', $ticket) }}" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Update Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select" required>
                            <option value="open" {{ $ticket->status === 'open' ? 'selected' : '' }}>Open</option>
                            <option value="in_progress" {{ $ticket->status === 'in_progress' ? 'selected' : '' }}>In Progress</option>
                            <option value="resolved" {{ $ticket->status === 'resolved' ? 'selected' : '' }}>Resolved</option>
                            <option value="closed" {{ $ticket->status === 'closed' ? 'selected' : '' }}>Closed</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Update Priority Modal -->
<div class="modal fade" id="updatePriorityModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.support-tickets.update-priority', $ticket) }}" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Update Priority</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Priority</label>
                        <select name="priority" class="form-select" required>
                            <option value="low" {{ $ticket->priority === 'low' ? 'selected' : '' }}>Low</option>
                            <option value="medium" {{ $ticket->priority === 'medium' ? 'selected' : '' }}>Medium</option>
                            <option value="high" {{ $ticket->priority === 'high' ? 'selected' : '' }}>High</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div>
    </div>
</div>

@push('styles')
<style>
.avatar {
    width: 40px;
    height: 40px;
    background-color: #007bff;
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
}

.admin-avatar {
    background-color: #28a745;
}

.admin-reply {
    background-color: #f8f9fa;
    padding: 1rem;
    border-radius: 0.25rem;
}

.message-content {
    white-space: pre-wrap;
}
</style>
@endpush

@push('scripts')
<script>
document.getElementById('attachments')?.addEventListener('change', function(e) {
    const preview = document.getElementById('attachment-preview');
    preview.innerHTML = '';

    if (this.files.length > 0) {
        const list = document.createElement('div');
        list.className = 'list-group mt-2';

        Array.from(this.files).forEach(file => {
            const item = document.createElement('div');
            item.className = 'list-group-item d-flex justify-content-between align-items-center';
            
            const name = document.createElement('span');
            name.textContent = file.name;
            
            const size = document.createElement('span');
            size.className = 'badge bg-primary rounded-pill';
            size.textContent = Math.round(file.size / 1024) + ' KB';
            
            item.appendChild(name);
            item.appendChild(size);
            list.appendChild(item);
        });

        preview.appendChild(list);
    }
});
</script>
@endpush
@endsection
