<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Services\SecurityService;

class PasswordChangeController extends Controller
{
    protected $securityService;
    
    /**
     * Create a new controller instance.
     *
     * @param SecurityService $securityService
     * @return void
     */
    public function __construct(SecurityService $securityService)
    {
        $this->middleware('auth');
        $this->securityService = $securityService;
    }
    
    /**
     * Show the change password form.
     *
     * @return \Illuminate\View\View
     */
    public function showChangeForm()
    {
        return view('auth.passwords.change');
    }
    
    /**
     * Change the user's password.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function change(Request $request)
    {
        $user = Auth::user();
        
        $validator = Validator::make($request->all(), [
            'current_password' => 'required',
            'password' => [
                'required',
                'confirmed',
                'min:' . config('security.passwords.min_length', 8),
                function ($attribute, $value, $fail) use ($user) {
                    // Check if new password is different from current
                    if (Hash::check($value, $user->password)) {
                        $fail('The new password must be different from your current password.');
                    }
                    
                    // Check password complexity
                    if (config('security.passwords.require_uppercase') && !preg_match('/[A-Z]/', $value)) {
                        $fail('The password must contain at least one uppercase letter.');
                    }
                    
                    if (config('security.passwords.require_numeric') && !preg_match('/[0-9]/', $value)) {
                        $fail('The password must contain at least one number.');
                    }
                    
                    if (config('security.passwords.require_special_char') && !preg_match('/[^A-Za-z0-9]/', $value)) {
                        $fail('The password must contain at least one special character.');
                    }
                    
                    // Check for common passwords if enabled
                    if (config('security.passwords.prevent_common') && $this->isCommonPassword($value)) {
                        $fail('This password is too common. Please choose a more secure password.');
                    }
                },
            ],
        ]);
        
        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }
        
        // Verify current password
        if (!Hash::check($request->current_password, $user->password)) {
            return redirect()->back()
                ->withErrors(['current_password' => 'The current password is incorrect.'])
                ->withInput();
        }
        
        // Update password
        $user->password = Hash::make($request->password);
        $user->password_changed_at = now();
        $user->force_password_change = false;
        $user->save();
        
        // Log the password change
        $this->securityService->logSecurityEvent(
            'password_changed',
            'User changed their password',
            ['user_id' => $user->id, 'ip' => $request->ip()]
        );
        
        return redirect()->route('dashboard')
            ->with('success', 'Your password has been changed successfully.');
    }
    
    /**
     * Check if a password is in the common passwords list.
     *
     * @param string $password
     * @return bool
     */
    protected function isCommonPassword($password)
    {
        $commonPasswords = [
            'password', '123456', '12345678', 'qwerty', 'abc123',
            'monkey', '1234567', 'letmein', 'trustno1', 'dragon',
            'baseball', '111111', 'iloveyou', 'master', 'sunshine',
            'ashley', 'bailey', 'passw0rd', 'shadow', '123123',
            'football', 'michael', 'password1', 'superman', 'welcome',
            // Add more common passwords as needed
        ];
        
        return in_array(strtolower($password), $commonPasswords);
    }
}
