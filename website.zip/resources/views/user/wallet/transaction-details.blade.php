@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Transaction Details</h4>
                    <a href="{{ route('wallet.transactions') }}" class="btn btn-outline-primary btn-sm">
                        Back to Transactions
                    </a>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Transaction ID:</strong> #{{ $transaction->id }}</p>
                            <p><strong>Date:</strong> {{ $transaction->created_at->format('M d, Y H:i') }}</p>
                            <p>
                                <strong>Type:</strong>
                                <span class="badge bg-{{ $transaction->type === 'credit' ? 'success' : 'danger' }}">
                                    {{ ucfirst($transaction->type) }}
                                </span>
                            </p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Amount:</strong> ${{ number_format($transaction->amount, 2) }}</p>
                            <p>
                                <strong>Status:</strong>
                                <span class="badge bg-{{ $transaction->status === 'completed' ? 'success' : 'warning' }}">
                                    {{ ucfirst($transaction->status) }}
                                </span>
                            </p>
                            <p><strong>Description:</strong> {{ $transaction->description }}</p>
                        </div>
                    </div>

                    <hr>

                    <div class="mt-4">
                        <h5>Balance Impact</h5>
                        <div class="alert alert-{{ $transaction->type === 'credit' ? 'success' : 'danger' }}">
                            <p class="mb-0">
                                This transaction {{ $transaction->type === 'credit' ? 'added' : 'deducted' }}
                                <strong>${{ number_format($transaction->amount, 2) }}</strong>
                                {{ $transaction->type === 'credit' ? 'to' : 'from' }} your wallet.
                            </p>
                        </div>
                    </div>

                    @if($transaction->status !== 'completed')
                    <div class="mt-4">
                        <div class="alert alert-warning">
                            <h6 class="alert-heading">Transaction Pending</h6>
                            <p class="mb-0">This transaction is still being processed. Please check back later.</p>
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
