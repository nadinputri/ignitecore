@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Account Settings</h2>
        </div>
        <div class="col-md-4 text-end">
            <x-user-status-badge :user="auth()->user()" />
        </div>
    </div>

    <div class="row">
        <!-- Profile Settings -->
        <div class="col-md-8 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Profile Information</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('user.settings.update') }}" method="POST">
                        @csrf
                        @method('PUT')

                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" 
                                   class="form-control @error('name') is-invalid @enderror" 
                                   id="name" 
                                   name="name" 
                                   value="{{ old('name', $user->name) }}"
                                   required>
                            @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" 
                                   class="form-control @error('email') is-invalid @enderror" 
                                   id="email" 
                                   name="email" 
                                   value="{{ old('email', $user->email) }}"
                                   required>
                            @error('email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <button type="submit" class="btn btn-primary">
                            Update Profile
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Security Settings -->
        <div class="col-md-4 mb-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Security</h5>
                </div>
                <div class="card-body">
                    <!-- Two-Factor Authentication -->
                    <div class="mb-4">
                        <h6>Two-Factor Authentication</h6>
                        @if($requires2fa)
                            <p class="text-muted small">Two-factor authentication is required for all accounts.</p>
                        @endif

                        @if(auth()->user()->two_factor_secret)
                            <div class="d-grid">
                                <a href="{{ route('two-factor.disable') }}" 
                                   class="btn btn-danger">
                                    Disable 2FA
                                </a>
                            </div>
                        @else
                            <div class="d-grid">
                                <a href="{{ route('two-factor.enable') }}" 
                                   class="btn btn-success">
                                    Enable 2FA
                                </a>
                            </div>
                        @endif
                    </div>

                    <!-- Session Management -->
                    @if($allowsMultipleSessions)
                        <div class="mb-4">
                            <h6>Active Sessions</h6>
                            <p class="text-muted small">Manage your active sessions on other browsers and devices.</p>
                            <div class="d-grid">
                                <a href="{{ route('user.sessions') }}" 
                                   class="btn btn-outline-primary">
                                    Manage Sessions
                                </a>
                            </div>
                        </div>
                    @endif

                    <!-- Password Change -->
                    <div>
                        <h6>Password</h6>
                        <p class="text-muted small">Ensure your account is using a long, random password to stay secure.</p>
                        <div class="d-grid">
                            <a href="{{ route('password.change') }}" 
                               class="btn btn-outline-primary">
                                Change Password
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Delete Account -->
            <div class="card border-danger">
                <div class="card-header bg-danger text-white">
                    <h5 class="card-title mb-0">Delete Account</h5>
                </div>
                <div class="card-body">
                    <p class="text-muted small">Once your account is deleted, all of its resources and data will be permanently deleted.</p>
                    <div class="d-grid">
                        <button type="button" 
                                class="btn btn-danger" 
                                data-bs-toggle="modal" 
                                data-bs-target="#deleteAccountModal">
                            Delete Account
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Notification Preferences -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Notification Preferences</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('notification-preferences.update') }}" method="POST">
                        @csrf

                        <!-- Order Notifications -->
                        <div class="mb-4">
                            <h6>Order Updates</h6>
                            <div class="form-check form-switch mb-2">
                                <input type="checkbox" 
                                       class="form-check-input" 
                                       name="preferences[order_status_email]" 
                                       id="order_status_email"
                                       {{ $preferences['order_status_email'] ? 'checked' : '' }}>
                                <label class="form-check-label" for="order_status_email">
                                    Email notifications for order status changes
                                </label>
                            </div>
                            <div class="form-check form-switch">
                                <input type="checkbox" 
                                       class="form-check-input" 
                                       name="preferences[price_updates_email]" 
                                       id="price_updates_email"
                                       {{ $preferences['price_updates_email'] ? 'checked' : '' }}>
                                <label class="form-check-label" for="price_updates_email">
                                    Email notifications for price updates
                                </label>
                            </div>
                        </div>

                        <!-- Support Notifications -->
                        <div class="mb-4">
                            <h6>Support Updates</h6>
                            <div class="form-check form-switch">
                                <input type="checkbox" 
                                       class="form-check-input" 
                                       name="preferences[support_ticket_email]" 
                                       id="support_ticket_email"
                                       {{ $preferences['support_ticket_email'] ? 'checked' : '' }}>
                                <label class="form-check-label" for="support_ticket_email">
                                    Email notifications for support ticket updates
                                </label>
                            </div>
                        </div>

                        <!-- Wallet Notifications -->
                        <div class="mb-4">
                            <h6>Wallet Updates</h6>
                            <div class="form-check form-switch">
                                <input type="checkbox" 
                                       class="form-check-input" 
                                       name="preferences[wallet_updates_email]" 
                                       id="wallet_updates_email"
                                       {{ $preferences['wallet_updates_email'] ? 'checked' : '' }}>
                                <label class="form-check-label" for="wallet_updates_email">
                                    Email notifications for wallet transactions
                                </label>
                            </div>
                        </div>

                        <!-- Security Notifications -->
                        <div class="mb-4">
                            <h6>Security Alerts</h6>
                            <div class="form-check form-switch">
                                <input type="checkbox" 
                                       class="form-check-input" 
                                       name="preferences[security_alerts_email]" 
                                       id="security_alerts_email"
                                       {{ $preferences['security_alerts_email'] ? 'checked' : '' }}
                                       disabled>
                                <label class="form-check-label" for="security_alerts_email">
                                    Email notifications for security alerts (required)
                                </label>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            Save Preferences
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Account Modal -->
<div class="modal fade" id="deleteAccountModal" tabindex="-1" aria-labelledby="deleteAccountModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteAccountModalLabel">Delete Account</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete your account? This action cannot be undone.</p>
                <form id="deleteAccountForm" action="{{ route('user.delete') }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <div class="mb-3">
                        <label for="password" class="form-label">Please enter your password to confirm:</label>
                        <input type="password" 
                               class="form-control" 
                               id="password" 
                               name="password" 
                               required>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" 
                        form="deleteAccountForm" 
                        class="btn btn-danger">
                    Delete Account
                </button>
            </div>
        </div>
    </div>
</div>

@push('styles')
<style>
.form-switch {
    padding-left: 3em;
}
.form-switch .form-check-input {
    width: 3em;
}
.form-switch .form-check-input:checked {
    background-color: #198754;
    border-color: #198754;
}
</style>
@endpush
