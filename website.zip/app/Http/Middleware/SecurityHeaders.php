<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class SecurityHeaders
{
    /**
     * Security headers to be added to all responses
     *
     * @var array
     */
    protected $securityHeaders = [
        'X-Frame-Options' => 'SAMEORIGIN',
        'X-XSS-Protection' => '1; mode=block',
        'X-Content-Type-Options' => 'nosniff',
        'Referrer-Policy' => 'strict-origin-when-cross-origin',
        'Permissions-Policy' => 'camera=(), microphone=(), geolocation=(), payment=()',
        'X-Permitted-Cross-Domain-Policies' => 'none',
        'Cross-Origin-Embedder-Policy' => 'require-corp',
        'Cross-Origin-Opener-Policy' => 'same-origin',
        'Cross-Origin-Resource-Policy' => 'same-origin'
    ];

    /**
     * Content Security Policy directives
     *
     * @var array
     */
    protected $cspDirectives = [
        'default-src' => "'self'",
        'script-src' => "'self' 'unsafe-inline' 'unsafe-eval'", // Consider removing unsafe-inline/eval
        'style-src' => "'self' 'unsafe-inline'",
        'img-src' => "'self' data: https:",
        'font-src' => "'self'",
        'form-action' => "'self'",
        'frame-ancestors' => "'self'",
        'base-uri' => "'self'",
        'object-src' => "'none'",
        'upgrade-insecure-requests' => '',
    ];

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $response = $next($request);

        // Add security headers
        foreach ($this->securityHeaders as $key => $value) {
            $response->headers->set($key, $value);
        }

        // Build CSP header
        $csp = [];
        foreach ($this->cspDirectives as $directive => $value) {
            if ($value !== '') {
                $csp[] = $directive . ' ' . $value;
            } else {
                $csp[] = $directive;
            }
        }

        // Add CSP header
        $response->headers->set('Content-Security-Policy', implode('; ', $csp));

        // Add HSTS header if using HTTPS
        if ($request->secure()) {
            $response->headers->set(
                'Strict-Transport-Security',
                'max-age=31536000; includeSubDomains; preload'
            );
        }

        // Prevent clickjacking
        $response->headers->set('X-Frame-Options', 'SAMEORIGIN');

        // Clear sensitive headers
        $response->headers->remove('X-Powered-By');
        $response->headers->remove('Server');

        return $response;
    }

    /**
     * Add custom CSP directives
     *
     * @param array $directives
     * @return void
     */
    public function addCspDirectives(array $directives)
    {
        $this->cspDirectives = array_merge($this->cspDirectives, $directives);
    }

    /**
     * Add custom security headers
     *
     * @param array $headers
     * @return void
     */
    public function addSecurityHeaders(array $headers)
    {
        $this->securityHeaders = array_merge($this->securityHeaders, $headers);
    }
}
