<?php

namespace App\Mail;

use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class OrderStatusChanged extends Mailable
{
    use Queueable, SerializesModels;

    public $order;
    public $previousStatus;
    public $newStatus;
    public $additionalMessage;

    /**
     * Create a new message instance.
     *
     * @param  \App\Models\Order  $order
     * @param  string  $previousStatus
     * @param  string  $newStatus
     * @param  string|null  $additionalMessage
     * @return void
     */
    public function __construct(Order $order, string $previousStatus, string $newStatus, ?string $additionalMessage = null)
    {
        $this->order = $order;
        $this->previousStatus = $previousStatus;
        $this->newStatus = $newStatus;
        $this->additionalMessage = $additionalMessage;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $subject = "Order #{$this->order->id} Status Update";

        return $this->subject($subject)
            ->markdown('emails.orders.status-changed', [
                'order' => $this->order,
                'previousStatus' => $this->previousStatus,
                'newStatus' => $this->newStatus,
                'additionalMessage' => $this->additionalMessage,
                'statusMessages' => [
                    'pending' => 'Your order is pending review.',
                    'price_offered' => 'We have offered a price for your order. Please review and accept or make a counter offer.',
                    'price_countered' => 'Your counter offer has been received and is under review.',
                    'accepted' => 'Your order has been accepted and is awaiting processing.',
                    'in_progress' => 'Work has begun on your order.',
                    'completed' => 'Your order has been completed! Please review the deliverables.',
                    'cancelled' => 'Your order has been cancelled.',
                    'refunded' => 'Your order has been refunded.',
                ],
                'actionUrls' => [
                    'price_offered' => route('orders.show', $this->order),
                    'accepted' => route('orders.show', $this->order),
                    'completed' => route('orders.show', $this->order),
                ],
                'actionTexts' => [
                    'price_offered' => 'Review Price Offer',
                    'accepted' => 'View Order Details',
                    'completed' => 'View Completed Order',
                ]
            ]);
    }
}
