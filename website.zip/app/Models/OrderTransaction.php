<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class OrderTransaction extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_id',
        'wallet_transaction_id',
        'type'
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Get the order associated with the transaction.
     */
    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    /**
     * Get the wallet transaction associated with this order transaction.
     */
    public function walletTransaction()
    {
        return $this->belongsTo(WalletTransaction::class);
    }

    /**
     * Scope a query to only include payment transactions.
     */
    public function scopePayments($query)
    {
        return $query->where('type', 'payment');
    }

    /**
     * Scope a query to only include refund transactions.
     */
    public function scopeRefunds($query)
    {
        return $query->where('type', 'refund');
    }

    /**
     * Check if this is a payment transaction.
     */
    public function isPayment()
    {
        return $this->type === 'payment';
    }

    /**
     * Check if this is a refund transaction.
     */
    public function isRefund()
    {
        return $this->type === 'refund';
    }

    /**
     * Get the amount of the transaction.
     */
    public function getAmount()
    {
        return $this->walletTransaction->amount;
    }

    /**
     * Get the formatted amount of the transaction.
     */
    public function getFormattedAmount()
    {
        return '$' . number_format($this->getAmount(), 2);
    }

    /**
     * Get the description of the transaction.
     */
    public function getDescription()
    {
        return $this->walletTransaction->description;
    }

    /**
     * Get the date of the transaction.
     */
    public function getDate()
    {
        return $this->created_at->format('M d, Y H:i');
    }
}
