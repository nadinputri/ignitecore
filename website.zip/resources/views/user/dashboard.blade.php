@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Dashboard</h2>
        </div>
        <div class="col-md-4 text-end">
            <x-user-status-badge :user="auth()->user()" :detailed="true" />
        </div>
    </div>

    <div class="row">
        <!-- Account Overview -->
        <div class="col-md-4 mb-4">
            <div class="card h-100">
                <div class="card-header">
                    <h5 class="card-title mb-0">Account Overview</h5>
                </div>
                <div class="card-body">
                    <div class="d-flex align-items-center mb-3">
                        <div class="flex-shrink-0">
                            <div class="avatar-circle">
                                {{ strtoupper(substr(auth()->user()->name, 0, 2)) }}
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h6 class="mb-0">{{ auth()->user()->name }}</h6>
                            <small class="text-muted">{{ auth()->user()->email }}</small>
                        </div>
                    </div>

                    <hr>

                    <div class="mb-3">
                        <label class="small text-muted d-block">Wallet Balance</label>
                        <h4 class="mb-0">${{ number_format(auth()->user()->wallet->balance, 2) }}</h4>
                        <a href="{{ route('wallet.index') }}" class="btn btn-sm btn-outline-primary mt-2">
                            Manage Wallet
                        </a>
                    </div>

                    <hr>

                    @can('create-telegram-bot')
                    <div class="mb-3">
                        <label class="small text-muted d-block">Telegram Bots</label>
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="mb-0">{{ auth()->user()->telegramBots()->count() }}</h4>
                            <a href="{{ route('user.telegram-bots.index') }}" class="btn btn-sm btn-outline-primary">
                                <i class="fab fa-telegram"></i> Manage Bots
                            </a>
                        </div>
                    </div>
                    <hr>
                    @endcan

                    <div class="small">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Member Since</span>
                            <span>{{ auth()->user()->created_at->format('M d, Y') }}</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Total Orders</span>
                            <span>{{ auth()->user()->orders()->count() }}</span>
                        </div>
                        <div class="d-flex justify-content-between">
                            <span>Total Spent</span>
                            <span>${{ number_format(auth()->user()->getTotalSpent(), 2) }}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Active Orders -->
        <div class="col-md-8 mb-4">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Active Orders</h5>
                    <a href="{{ route('orders.index') }}" class="btn btn-sm btn-outline-primary">View All Orders</a>
                </div>
                <div class="card-body">
                    @if($activeOrders = auth()->user()->activeOrders()->latest()->take(5)->get())
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Service</th>
                                        <th>Status</th>
                                        <th>Price</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($activeOrders as $order)
                                        <tr>
                                            <td>#{{ $order->id }}</td>
                                            <td>{{ $order->service->name }}</td>
                                            <td>
                                                <span class="badge bg-{{ $order->getStatusBadgeClass() }}">
                                                    {{ $order->getStatusLabel() }}
                                                </span>
                                            </td>
                                            <td>${{ $order->getFormattedCurrentPrice() }}</td>
                                            <td>
                                                <a href="{{ route('orders.show', $order) }}" class="btn btn-sm btn-outline-secondary">
                                                    View
                                                </a>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="5" class="text-center py-4">
                                                <p class="text-muted mb-0">No active orders</p>
                                                <a href="{{ route('services.index') }}" class="btn btn-primary mt-2">
                                                    Browse Services
                                                </a>
                                            </td>
                                        </tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Support Tickets -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Support Tickets</h5>
                    <div>
                        @if(auth()->user()->canCreateSupportTicket())
                            <a href="{{ route('support-tickets.create') }}" class="btn btn-sm btn-outline-primary me-2">
                                New Ticket
                            </a>
                        @endif
                        <a href="{{ route('support-tickets.index') }}" class="btn btn-sm btn-outline-secondary">
                            View All
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    @if($tickets = auth()->user()->supportTickets()->latest()->take(5)->get())
                        <div class="list-group list-group-flush">
                            @forelse($tickets as $ticket)
                                <a href="{{ route('support-tickets.show', $ticket) }}" 
                                   class="list-group-item list-group-item-action">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1">{{ $ticket->title }}</h6>
                                        <small class="text-muted">{{ $ticket->created_at->diffForHumans() }}</small>
                                    </div>
                                    <p class="mb-1 small text-truncate">{{ $ticket->description }}</p>
                                    <small class="text-muted">
                                        Status: 
                                        <span class="badge bg-{{ $ticket->status === 'open' ? 'success' : 'secondary' }}">
                                            {{ ucfirst($ticket->status) }}
                                        </span>
                                    </small>
                                </a>
                            @empty
                                <div class="text-center py-4">
                                    <p class="text-muted mb-0">No support tickets</p>
                                </div>
                            @endforelse
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Recent Notifications -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Recent Notifications</h5>
                    <div>
                        <a href="{{ route('notification-preferences.edit') }}" class="btn btn-sm btn-outline-primary me-2">
                            Settings
                        </a>
                        <a href="{{ route('notification-preferences.index') }}" class="btn btn-sm btn-outline-secondary">
                            View All
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    @if($notifications = auth()->user()->notifications()->latest()->take(5)->get())
                        <div class="list-group list-group-flush">
                            @forelse($notifications as $notification)
                                <a href="{{ route('notification-preferences.show', $notification->id) }}" 
                                   class="list-group-item list-group-item-action {{ !$notification->read_at ? 'bg-light' : '' }}">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h6 class="mb-1">{{ $notification->data['title'] ?? 'Notification' }}</h6>
                                        <small class="text-muted">{{ $notification->created_at->diffForHumans() }}</small>
                                    </div>
                                    <p class="mb-1 small text-truncate">{{ $notification->data['message'] ?? '' }}</p>
                                </a>
                            @empty
                                <div class="text-center py-4">
                                    <p class="text-muted mb-0">No notifications</p>
                                </div>
                            @endforelse
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@push('styles')
<style>
.avatar-circle {
    width: 48px;
    height: 48px;
    background-color: #6c757d;
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
    font-weight: 500;
}

.card {
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
    transition: box-shadow 0.3s ease-in-out;
}

.card:hover {
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
}

.list-group-item-action:hover {
    transform: translateX(4px);
    transition: transform 0.2s ease-in-out;
}
</style>
@endpush
