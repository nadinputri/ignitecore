<?php

return [
    /*
    |--------------------------------------------------------------------------
    | User Activity Settings
    |--------------------------------------------------------------------------
    |
    | Configure settings related to user activity tracking and inactivity handling.
    |
    */

    'activity' => [
        // Number of minutes of inactivity before user is considered offline
        'offline_after' => env('USER_OFFLINE_MINUTES', 5),

        // Number of days of inactivity before marking user as inactive
        'inactive_after' => env('USER_INACTIVE_DAYS', 90),

        // Number of days of inactivity before suspending user
        'suspend_after' => env('USER_SUSPEND_DAYS', 180),

        // Duration of suspension in days
        'suspension_duration' => env('USER_SUSPENSION_DURATION', 30),

        // Whether to send notifications before marking users as inactive
        'notify_before_inactive' => env('USER_NOTIFY_BEFORE_INACTIVE', true),

        // Number of days before inactivity to send warning notification
        'notify_days_before' => env('USER_NOTIFY_DAYS_BEFORE', 7),
    ],

    /*
    |--------------------------------------------------------------------------
    | Order Limits
    |--------------------------------------------------------------------------
    |
    | Configure limits related to user orders.
    |
    */

    'orders' => [
        // Maximum number of active orders a user can have
        'max_active' => env('USER_MAX_ACTIVE_ORDERS', 5),

        // Maximum number of orders per day
        'max_per_day' => env('USER_MAX_ORDERS_PER_DAY', 10),

        // Maximum total value of active orders
        'max_active_value' => env('USER_MAX_ACTIVE_ORDERS_VALUE', 1000),
    ],

    /*
    |--------------------------------------------------------------------------
    | Default Notification Preferences
    |--------------------------------------------------------------------------
    |
    | Default notification settings for new users.
    |
    */

    'notifications' => [
        'defaults' => [
            'order_status_email' => true,
            'order_status_database' => true,
            'price_updates_email' => true,
            'price_updates_database' => true,
            'support_ticket_email' => true,
            'support_ticket_database' => true,
            'wallet_updates_email' => true,
            'wallet_updates_database' => true,
            'security_alerts_email' => true,
            'security_alerts_database' => true,
            'marketing_email' => false,
            'marketing_database' => false,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | User Status Settings
    |--------------------------------------------------------------------------
    |
    | Configure settings related to user statuses.
    |
    */

    'status' => [
        // Available user statuses
        'types' => [
            'active',
            'inactive',
            'suspended',
            'banned',
        ],

        // Default status for new users
        'default' => 'active',

        // Whether to require email verification before activating account
        'require_verification' => env('USER_REQUIRE_VERIFICATION', true),
    ],

    /*
    |--------------------------------------------------------------------------
    | Security Settings
    |--------------------------------------------------------------------------
    |
    | Configure security-related settings for users.
    |
    */

    'security' => [
        // Whether to enforce strong passwords
        'require_strong_password' => env('USER_REQUIRE_STRONG_PASSWORD', true),

        // Whether to enforce two-factor authentication
        'require_2fa' => env('USER_REQUIRE_2FA', false),

        // Whether to allow multiple sessions
        'allow_multiple_sessions' => env('USER_ALLOW_MULTIPLE_SESSIONS', true),

        // Maximum number of failed login attempts before lockout
        'max_login_attempts' => env('USER_MAX_LOGIN_ATTEMPTS', 5),

        // Lockout duration in minutes
        'lockout_duration' => env('USER_LOCKOUT_DURATION', 15),
    ],

    /*
    |--------------------------------------------------------------------------
    | Support Settings
    |--------------------------------------------------------------------------
    |
    | Configure settings related to user support.
    |
    */

    'support' => [
        // Maximum number of open support tickets per user
        'max_open_tickets' => env('USER_MAX_OPEN_TICKETS', 3),

        // Whether to allow suspended users to create support tickets
        'allow_suspended_tickets' => env('USER_ALLOW_SUSPENDED_TICKETS', true),

        // Whether to automatically create support ticket when user is suspended
        'auto_ticket_on_suspend' => env('USER_AUTO_TICKET_ON_SUSPEND', true),
    ],
];
