#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored messages
print_message() {
    echo -e "${2}${1}${NC}"
}

# Function to check command status
check_status() {
    if [ $? -eq 0 ]; then
        print_message "✓ $1" "$GREEN"
    else
        print_message "✗ $1" "$RED"
        exit 1
    fi
}

print_message "Starting MemeBot Trading System Quick Setup..." "$YELLOW"

# Check Python version
print_message "\nChecking Python version..." "$YELLOW"
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
PYTHON_MAJOR=$(echo $PYTHON_VERSION | cut -d. -f1)
PYTHON_MINOR=$(echo $PYTHON_VERSION | cut -d. -f2)

if [ "$PYTHON_MAJOR" -lt 3 ] || [ "$PYTHON_MINOR" -lt 8 ]; then
    print_message "Python 3.8 or higher is required (found $PYTHON_VERSION)" "$RED"
    exit 1
fi
check_status "Python version check passed ($PYTHON_VERSION)"

# Check CUDA availability
print_message "\nChecking CUDA installation..." "$YELLOW"
if ! command -v nvcc &> /dev/null; then
    print_message "CUDA not found. Please run install.sh for full installation" "$RED"
    exit 1
fi
CUDA_VERSION=$(nvcc --version | grep "release" | awk '{print $6}' | cut -c2-)
check_status "CUDA version $CUDA_VERSION detected"

# Create virtual environment
print_message "\nSetting up Python virtual environment..." "$YELLOW"
if [ ! -d "venv" ]; then
    python3 -m venv venv
    check_status "Virtual environment created"
else
    print_message "Using existing virtual environment" "$GREEN"
fi

# Activate virtual environment
source venv/bin/activate
check_status "Virtual environment activated"

# Upgrade pip
print_message "\nUpgrading pip..." "$YELLOW"
pip install --upgrade pip
check_status "Pip upgraded"

# Install Python dependencies
print_message "\nInstalling Python dependencies..." "$YELLOW"
pip install -r requirements.txt
check_status "Python dependencies installed"

# Create necessary directories
print_message "\nCreating necessary directories..." "$YELLOW"
mkdir -p config logs models
check_status "Directories created"

# Set up configuration files
print_message "\nSetting up configuration files..." "$YELLOW"

# Create config files if they don't exist
if [ ! -f config/api_config.json ]; then
    cat > config/api_config.json << EOF
{
    "base_urls": {
        "binance": "https://api.binance.com",
        "coingecko": "https://api.coingecko.com/api/v3"
    },
    "api_keys": {
        "binance": "",
        "binance_secret": ""
    },
    "rate_limits": {
        "binance": {"requests": 1200, "period": 60},
        "coingecko": {"requests": 50, "period": 60}
    }
}
EOF
fi

if [ ! -f config/bot_config.json ]; then
    cat > config/bot_config.json << EOF
{
    "risk_level": "medium",
    "monitoring_interval": 300,
    "alert_threshold": 0.7,
    "max_position_size": 0.1,
    "stop_loss_pct": 0.05,
    "take_profit_pct": 0.15
}
EOF
fi

if [ ! -f config/telegram.json ]; then
    cat > config/telegram.json << EOF
{
    "bot_token": "",
    "api_id": "",
    "api_hash": "",
    "alert_chat_ids": []
}
EOF
fi
check_status "Configuration files created"

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    print_message "\nCreating .env file..." "$YELLOW"
    cat > .env << EOF
# API Credentials
API_USERNAME=admin
API_PASSWORD=changeme

# Telegram Bot
TELEGRAM_BOT_TOKEN=
TELEGRAM_API_ID=
TELEGRAM_API_HASH=

# Exchange API Keys
BINANCE_API_KEY=
BINANCE_SECRET_KEY=

# Security
JWT_SECRET=changeme
EOF
    check_status ".env file created"
fi

# Set file permissions
print_message "\nSetting file permissions..." "$YELLOW"
chmod +x main.py api_server.py
chmod 600 .env config/*.json
check_status "File permissions set"

# Create log files
print_message "\nInitializing log files..." "$YELLOW"
touch logs/trading_bot.log logs/api_server.log
check_status "Log files initialized"

print_message "\nSetup completed successfully!" "$GREEN"
print_message "\nNext steps:" "$YELLOW"
print_message "1. Edit .env file with your credentials:" "$YELLOW"
print_message "   nano .env" "$NC"
print_message "2. Edit configuration files:" "$YELLOW"
print_message "   nano config/api_config.json" "$NC"
print_message "   nano config/bot_config.json" "$NC"
print_message "   nano config/telegram.json" "$NC"
print_message "3. Start the API server:" "$YELLOW"
print_message "   python api_server.py" "$NC"
print_message "4. Start the trading bot:" "$YELLOW"
print_message "   python main.py" "$NC"
print_message "\nFor more information, see README.md" "$YELLOW"

# Deactivate virtual environment
deactivate
