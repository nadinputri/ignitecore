@extends('layouts.app')

@section('styles')
<style>
.hero-section {
    min-height: 100vh;
    display: flex;
    align-items: center;
    position: relative;
    overflow: hidden;
    padding: 4rem 0;
}

.hero-grid {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: 
        linear-gradient(90deg, var(--grid-color) 1px, transparent 1px),
        linear-gradient(var(--grid-color) 1px, transparent 1px);
    background-size: 50px 50px;
    transform: perspective(500px) rotateX(60deg);
    animation: grid-move 20s linear infinite;
}

@keyframes grid-move {
    0% { transform: perspective(500px) rotateX(60deg) translateY(0); }
    100% { transform: perspective(500px) rotateX(60deg) translateY(50px); }
}

.hero-content {
    position: relative;
    z-index: 1;
}

.hero-title {
    font-size: 3.5rem;
    margin-bottom: 2rem;
    position: relative;
    display: inline-block;
}

.hero-subtitle {
    font-size: 1.5rem;
    color: var(--accent-color);
    margin-bottom: 3rem;
}

.features-section {
    padding: 6rem 0;
    position: relative;
}

.feature-card {
    height: 100%;
    border-color: var(--accent-color);
    background: linear-gradient(45deg, var(--background-dark), var(--background-light));
}

.feature-card:hover {
    border-color: var(--secondary-color);
    box-shadow: 0 0 30px var(--secondary-color);
}

.feature-icon {
    font-size: 3rem;
    margin-bottom: 1.5rem;
    color: var(--accent-color);
    transition: all 0.3s ease;
}

.feature-card:hover .feature-icon {
    color: var(--secondary-color);
    transform: scale(1.2);
}

.services-preview {
    padding: 6rem 0;
    background: linear-gradient(to bottom, var(--background-dark), var(--background-light));
}

.service-card {
    position: relative;
    overflow: hidden;
    cursor: pointer;
}

.service-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
    opacity: 0;
    transition: all 0.3s ease;
}

.service-card:hover::before {
    opacity: 0.1;
}

.cta-section {
    padding: 6rem 0;
    position: relative;
    background: linear-gradient(45deg, var(--background-dark), var(--background-light));
}

.cta-box {
    border: 2px solid var(--primary-color);
    padding: 3rem;
    text-align: center;
    position: relative;
    overflow: hidden;
}

.cta-box::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: linear-gradient(45deg, transparent, var(--primary-color), transparent);
    opacity: 0.1;
    animation: cta-shine 3s linear infinite;
}

@keyframes cta-shine {
    0% { transform: translateX(-100%) translateY(-100%) rotate(45deg); }
    100% { transform: translateX(100%) translateY(100%) rotate(45deg); }
}

.stats-section {
    padding: 4rem 0;
}

.stat-card {
    text-align: center;
    padding: 2rem;
}

.stat-number {
    font-size: 3rem;
    font-family: 'Press Start 2P', cursive;
    color: var(--primary-color);
    margin-bottom: 1rem;
}

.testimonials-section {
    padding: 6rem 0;
}

.testimonial-card {
    padding: 2rem;
    margin: 1rem;
    position: relative;
}

.testimonial-quote {
    font-size: 1.2rem;
    font-style: italic;
    margin-bottom: 1.5rem;
}

.testimonial-author {
    color: var(--accent-color);
}

/* Responsive design */
@media (max-width: 768px) {
    .hero-title {
        font-size: 2rem;
    }

    .hero-subtitle {
        font-size: 1.2rem;
    }

    .stat-number {
        font-size: 2rem;
    }
}

/* Animations */
.fade-in {
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.6s ease;
}

.fade-in.visible {
    opacity: 1;
    transform: translateY(0);
}

.typing-effect::after {
    content: '|';
    animation: blink 1s infinite;
}

@keyframes blink {
    0%, 100% { opacity: 1; }
    50% { opacity: 0; }
}
</style>
@endsection

@section('content')
<!-- Hero Section -->
<section class="hero-section">
    <div class="hero-grid"></div>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="hero-content">
                    <h1 class="hero-title glitch" data-text="Welcome to the Future">Welcome to the Future</h1>
                    <p class="hero-subtitle typing-effect">Digital Solutions for Tomorrow's Challenges</p>
                    <div class="d-flex gap-3">
                        <a href="{{ route('services.index') }}" class="btn btn-primary">Explore Services</a>
                        <a href="{{ route('contact.show') }}" class="btn btn-secondary">Get in Touch</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Features Section -->
<section class="features-section">
    <div class="container">
        <h2 class="text-center mb-5 glitch" data-text="Why Choose Us">Why Choose Us</h2>
        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card feature-card fade-in">
                    <div class="card-body text-center">
                        <i class="fas fa-rocket feature-icon"></i>
                        <h3>Fast & Efficient</h3>
                        <p>Lightning-fast solutions for your digital needs</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card feature-card fade-in">
                    <div class="card-body text-center">
                        <i class="fas fa-shield-alt feature-icon"></i>
                        <h3>Secure & Reliable</h3>
                        <p>Your security is our top priority</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card feature-card fade-in">
                    <div class="card-body text-center">
                        <i class="fas fa-code feature-icon"></i>
                        <h3>Cutting Edge</h3>
                        <p>Using the latest technologies</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Services Preview -->
<section class="services-preview">
    <div class="container">
        <h2 class="text-center mb-5 glitch" data-text="Our Services">Our Services</h2>
        <div class="row">
            @foreach($services->take(3) as $service)
            <div class="col-md-4 mb-4">
                <div class="card service-card fade-in">
                    <div class="card-body">
                        <h3>{{ $service->name }}</h3>
                        <p>{{ Str::limit($service->description, 100) }}</p>
                        <a href="{{ route('services.show', $service) }}" class="btn btn-primary">Learn More</a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>

<!-- Stats Section -->
<section class="stats-section">
    <div class="container">
        <div class="row">
            <div class="col-md-3 mb-4">
                <div class="stat-card fade-in">
                    <div class="stat-number" data-count="100">0</div>
                    <div class="stat-label">Happy Clients</div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="stat-card fade-in">
                    <div class="stat-number" data-count="500">0</div>
                    <div class="stat-label">Projects Completed</div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="stat-card fade-in">
                    <div class="stat-number" data-count="50">0</div>
                    <div class="stat-label">Team Members</div>
                </div>
            </div>
            <div class="col-md-3 mb-4">
                <div class="stat-card fade-in">
                    <div class="stat-number" data-count="24">0</div>
                    <div class="stat-label">Awards Won</div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="cta-section">
    <div class="container">
        <div class="cta-box fade-in">
            <h2 class="mb-4 glitch" data-text="Ready to Get Started?">Ready to Get Started?</h2>
            <p class="mb-4">Join us in shaping the future of digital technology</p>
            <a href="{{ route('contact.show') }}" class="btn btn-primary">Contact Us Now</a>
        </div>
    </div>
</section>
@endsection

@section('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Fade in animation
    const fadeElements = document.querySelectorAll('.fade-in');
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    });

    fadeElements.forEach(element => {
        observer.observe(element);
    });

    // Typing effect
    const texts = ['Digital Solutions for Tomorrow\'s Challenges', 'Innovative. Reliable. Secure.'];
    let textIndex = 0;
    let charIndex = 0;
    const typingElement = document.querySelector('.typing-effect');
    
    function type() {
        if (charIndex < texts[textIndex].length) {
            typingElement.textContent = texts[textIndex].substring(0, charIndex + 1);
            charIndex++;
            setTimeout(type, 100);
        } else {
            setTimeout(erase, 2000);
        }
    }

    function erase() {
        if (charIndex > 0) {
            typingElement.textContent = texts[textIndex].substring(0, charIndex - 1);
            charIndex--;
            setTimeout(erase, 50);
        } else {
            textIndex = (textIndex + 1) % texts.length;
            setTimeout(type, 500);
        }
    }

    type();

    // Animate stats
    const stats = document.querySelectorAll('.stat-number');
    stats.forEach(stat => {
        const target = parseInt(stat.getAttribute('data-count'));
        let current = 0;
        const increment = target / 50;
        const timer = setInterval(() => {
            current += increment;
            stat.textContent = Math.round(current);
            if (current >= target) {
                stat.textContent = target;
                clearInterval(timer);
            }
        }, 50);
    });
});
</script>
@endsection
