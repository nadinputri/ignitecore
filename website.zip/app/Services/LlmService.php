<?php

namespace App\Services;

use App\Models\LlmSetting;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Process;
use Illuminate\Support\Str;

class LlmService
{
    protected $settings;

    public function __construct()
    {
        $this->settings = LlmSetting::getConfig();
    }

    /**
     * Generate response using local LLM
     */
    public function generateResponse(string $prompt, array $options = [], callable $callback = null): string
    {
        // Check if LLM is ready
        if (!$this->settings->isReady()) {
            throw new \Exception('LLM is not ready. Please check settings and model installation.');
        }

        // Check rate limit
        $this->checkRateLimit();

        // Check content filtering
        if ($this->settings->content_filtering) {
            $this->validateContent($prompt);
        }

        // Check cache
        if ($this->settings->cache_enabled) {
            $cacheKey = $this->getCacheKey($prompt, $options);
            if ($cached = Cache::get($cacheKey)) {
                return $cached;
            }
        }

        try {
            // Merge options with defaults
            $options = array_merge([
                'max_tokens' => $this->settings->max_tokens,
                'temperature' => $this->settings->temperature,
                'stream' => false
            ], $options);

            // Generate response
            $response = $this->executeGeneration($prompt, $options, $callback);

            // Cache response
            if ($this->settings->cache_enabled) {
                Cache::put($cacheKey, $response, $this->settings->cache_ttl);
            }

            // Log request if enabled
            if ($this->settings->log_requests) {
                $this->logRequest($prompt, $response, $options);
            }

            return $response;

        } catch (\Exception $e) {
            // Try fallback if enabled
            if ($this->settings->fallback_enabled) {
                return $this->handleFallback($prompt, $e);
            }

            throw $e;
        }
    }

    /**
     * Execute model generation
     */
    protected function executeGeneration(string $prompt, array $options, ?callable $callback): string
    {
        $pythonPath = config('llm.python.path');
        $scriptsPath = config('llm.python.scripts_dir');

        $command = [
            $pythonPath,
            "{$scriptsPath}/generate.py",
            "--model={$this->settings->model_path}",
            "--prompt=" . escapeshellarg($prompt),
            "--max-tokens={$options['max_tokens']}",
            "--temperature={$options['temperature']}",
            "--batch-size={$this->settings->batch_size}",
            "--threads={$this->settings->threads}",
            "--gpu-layers={$this->settings->gpu_layers}",
            "--ctx-size={$this->settings->context_window}"
        ];

        if ($options['stream']) {
            $command[] = '--stream';
        }

        $process = Process::timeout(60)->start(implode(' ', $command));

        $output = '';
        $process->waitUntil(function ($type, $line) use (&$output, $callback) {
            if ($type === 'out') {
                if ($callback) {
                    $callback($line);
                }
                $output .= $line;
            }
            return false;
        });

        if (!$process->successful()) {
            throw new \Exception('Generation failed: ' . $process->errorOutput());
        }

        return trim($output);
    }

    /**
     * Handle fallback when generation fails
     */
    protected function handleFallback(string $prompt, \Exception $error): string
    {
        Log::warning('LLM generation failed, using fallback', [
            'prompt' => $prompt,
            'error' => $error->getMessage()
        ]);

        // Try fallback response
        if ($this->settings->fallback_response) {
            return $this->settings->fallback_response;
        }

        // Try with different settings
        $fallbackOptions = [
            ['temperature' => 0.1],
            ['max_tokens' => 512],
            ['gpu_layers' => 0],
            ['batch_size' => 1]
        ];

        foreach ($fallbackOptions as $options) {
            try {
                return $this->executeGeneration($prompt, $options, null);
            } catch (\Exception $e) {
                continue;
            }
        }

        throw new \Exception('All fallback attempts failed');
    }

    /**
     * Check rate limiting
     */
    protected function checkRateLimit(): void
    {
        $key = 'llm_requests_' . date('YmdH');
        $requests = Cache::get($key, 0);
        
        if ($requests >= $this->settings->max_requests_per_minute) {
            throw new \Exception('Rate limit exceeded');
        }

        Cache::increment($key);
    }

    /**
     * Validate content against blocked words
     */
    protected function validateContent(string $content): void
    {
        if (!empty($this->settings->blocked_words)) {
            foreach ($this->settings->blocked_words as $word) {
                if (stripos($content, $word) !== false) {
                    throw new \Exception('Content contains blocked words');
                }
            }
        }
    }

    /**
     * Get cache key for prompt and options
     */
    protected function getCacheKey(string $prompt, array $options): string
    {
        $key = 'llm_response_' . md5($prompt);
        
        if (!empty($options)) {
            $key .= '_' . md5(json_encode($options));
        }

        return $key;
    }

    /**
     * Log request details
     */
    protected function logRequest(string $prompt, string $response, array $options): void
    {
        $metrics = [
            'memory_usage' => memory_get_usage(true),
            'peak_memory' => memory_get_peak_usage(true),
            'cpu_usage' => sys_getloadavg()[0],
            'gpu_info' => get_gpu_status()
        ];

        Log::channel('llm')->info('Generated response', [
            'prompt' => $prompt,
            'response' => $response,
            'options' => $options,
            'metrics' => $metrics,
            'settings' => $this->settings->getGenerationSettings()
        ]);
    }

    /**
     * Clear all LLM-related caches
     */
    public function clearCache(): void
    {
        Cache::tags(['llm'])->flush();
        LlmSetting::clearCache();
    }

    /**
     * Get system metrics
     */
    public function getMetrics(): array
    {
        return [
            'memory_usage' => memory_get_usage(true),
            'peak_memory' => memory_get_peak_usage(true),
            'cpu_usage' => sys_getloadavg()[0],
            'gpu_info' => get_gpu_status(),
            'cache_hits' => Cache::tags(['llm'])->get('cache_hits', 0),
            'cache_misses' => Cache::tags(['llm'])->get('cache_misses', 0),
            'total_requests' => Cache::get('llm_requests_' . date('YmdH'), 0),
            'errors' => Cache::tags(['llm'])->get('error_count', 0)
        ];
    }

    /**
     * Check if Python environment is properly set up
     */
    public function checkEnvironment(): bool
    {
        return check_python_environment();
    }

    /**
     * Validate model configuration
     */
    public function validateModelConfig(string $model, string $size, string $variant): bool
    {
        return validate_model_config($model, $size, $variant);
    }

    /**
     * Check system requirements for model
     */
    public function checkSystemRequirements(string $size): bool
    {
        return check_system_requirements($size);
    }
}
