@extends('layouts.admin')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Orders Management</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="{{ route('admin.orders.create') }}" class="btn btn-primary">
                <i class="fas fa-plus"></i> Create Order
            </a>
        </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form action="{{ route('admin.orders.index') }}" method="GET" class="row g-3">
                <div class="col-md-4">
                    <div class="input-group">
                        <input type="text" 
                               name="search" 
                               class="form-control" 
                               placeholder="Search orders..."
                               value="{{ request('search') }}">
                        <button class="btn btn-outline-secondary" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
                <div class="col-md-3">
                    <select name="status" class="form-select" onchange="this.form.submit()">
                        <option value="">All Statuses</option>
                        <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>Pending</option>
                        <option value="price_offered" {{ request('status') === 'price_offered' ? 'selected' : '' }}>Price Offered</option>
                        <option value="price_countered" {{ request('status') === 'price_countered' ? 'selected' : '' }}>Price Countered</option>
                        <option value="accepted" {{ request('status') === 'accepted' ? 'selected' : '' }}>Accepted</option>
                        <option value="in_progress" {{ request('status') === 'in_progress' ? 'selected' : '' }}>In Progress</option>
                        <option value="completed" {{ request('status') === 'completed' ? 'selected' : '' }}>Completed</option>
                        <option value="cancelled" {{ request('status') === 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <a href="{{ route('admin.orders.index') }}" class="btn btn-outline-secondary">
                        Clear Filters
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Orders List -->
    <div class="card">
        <div class="card-body">
            @if($orders->count() > 0)
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Service</th>
                                <th>Status</th>
                                <th>Price</th>
                                <th>Created</th>
                                <th>Last Updated</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($orders as $order)
                                <tr>
                                    <td>#{{ $order->id }}</td>
                                    <td>
                                        <div>{{ $order->user->name }}</div>
                                        <small class="text-muted">{{ $order->user->email }}</small>
                                    </td>
                                    <td>{{ $order->service->name }}</td>
                                    <td>
                                        <span class="badge bg-{{ 
                                            $order->status === 'pending' ? 'warning' : 
                                            ($order->status === 'price_offered' ? 'info' : 
                                            ($order->status === 'price_countered' ? 'primary' : 
                                            ($order->status === 'accepted' ? 'success' : 
                                            ($order->status === 'in_progress' ? 'info' : 
                                            ($order->status === 'completed' ? 'success' : 'secondary')))))
                                        }}">
                                            {{ ucfirst(str_replace('_', ' ', $order->status)) }}
                                        </span>
                                    </td>
                                    <td>
                                        @if($order->final_price)
                                            ${{ number_format($order->final_price, 2) }}
                                        @elseif($order->counter_price)
                                            <span class="text-warning">
                                                ${{ number_format($order->counter_price, 2) }}
                                                <small>(Counter)</small>
                                            </span>
                                        @elseif($order->initial_price)
                                            <span class="text-info">
                                                ${{ number_format($order->initial_price, 2) }}
                                                <small>(Offered)</small>
                                            </span>
                                        @else
                                            <span class="text-muted">Not Set</span>
                                        @endif
                                    </td>
                                    <td>{{ $order->created_at->format('M d, Y') }}</td>
                                    <td>{{ $order->updated_at->diffForHumans() }}</td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="{{ route('admin.orders.show', $order) }}" 
                                               class="btn btn-sm btn-outline-primary">
                                                View
                                            </a>
                                            <button type="button" 
                                                    class="btn btn-sm btn-outline-primary dropdown-toggle dropdown-toggle-split"
                                                    data-bs-toggle="dropdown">
                                            </button>
                                            <ul class="dropdown-menu">
                                                @if($order->status === 'pending')
                                                    <li>
                                                        <button type="button"
                                                                class="dropdown-item"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#offerPriceModal"
                                                                data-order-id="{{ $order->id }}">
                                                            Offer Price
                                                        </button>
                                                    </li>
                                                @endif
                                                @if($order->status === 'accepted')
                                                    <li>
                                                        <form action="{{ route('admin.orders.update-status', $order) }}" method="POST">
                                                            @csrf
                                                            <input type="hidden" name="status" value="in_progress">
                                                            <button type="submit" class="dropdown-item">
                                                                Start Work
                                                            </button>
                                                        </form>
                                                    </li>
                                                @endif
                                                @if($order->status === 'in_progress')
                                                    <li>
                                                        <form action="{{ route('admin.orders.update-status', $order) }}" method="POST">
                                                            @csrf
                                                            <input type="hidden" name="status" value="completed">
                                                            <button type="submit" class="dropdown-item">
                                                                Mark Completed
                                                            </button>
                                                        </form>
                                                    </li>
                                                @endif
                                                @if(in_array($order->status, ['pending', 'price_offered', 'price_countered']))
                                                    <li>
                                                        <form action="{{ route('admin.orders.update-status', $order) }}" method="POST">
                                                            @csrf
                                                            <input type="hidden" name="status" value="cancelled">
                                                            <button type="submit" 
                                                                    class="dropdown-item text-danger"
                                                                    onclick="return confirm('Are you sure you want to cancel this order?')">
                                                                Cancel Order
                                                            </button>
                                                        </form>
                                                    </li>
                                                @endif
                                            </ul>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <div class="d-flex justify-content-center mt-4">
                    {{ $orders->links() }}
                </div>
            @else
                <div class="text-center py-4">
                    <h4>No Orders Found</h4>
                    <p class="text-muted">No orders match your search criteria.</p>
                </div>
            @endif
        </div>
    </div>
</div>

<!-- Offer Price Modal -->
<div class="modal fade" id="offerPriceModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="offerPriceForm" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Offer Price</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="price" class="form-label">Price Amount</label>
                        <div class="input-group">
                            <span class="input-group-text">$</span>
                            <input type="number" 
                                   class="form-control @error('price') is-invalid @enderror" 
                                   id="price" 
                                   name="price" 
                                   step="0.01" 
                                   min="0" 
                                   required>
                        </div>
                        @error('price')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Offer Price</button>
                </div>
            </form>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const offerPriceModal = document.getElementById('offerPriceModal');
    if (offerPriceModal) {
        offerPriceModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const orderId = button.dataset.orderId;
            
            const form = this.querySelector('#offerPriceForm');
            form.action = `/admin/orders/${orderId}/offer-price`;
        });
    }
});
</script>
@endpush
@endsection
