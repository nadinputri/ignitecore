<?php

if (!function_exists('format_bytes')) {
    /**
     * Format bytes to human readable format
     */
    function format_bytes($bytes, $precision = 2)
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];

        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);

        $bytes /= pow(1024, $pow);

        return round($bytes, $precision) . ' ' . $units[$pow];
    }
}

if (!function_exists('get_llm_status_badge')) {
    /**
     * Get HTML badge for LLM status
     */
    function get_llm_status_badge($status)
    {
        $badges = [
            'healthy' => '<span class="status-badge healthy">Healthy</span>',
            'warning' => '<span class="status-badge warning">Warning</span>',
            'critical' => '<span class="status-badge critical">Critical</span>',
            'degraded' => '<span class="status-badge degraded">Degraded</span>',
            'unknown' => '<span class="status-badge unknown">Unknown</span>'
        ];

        return $badges[$status] ?? $badges['unknown'];
    }
}

if (!function_exists('get_llm_model_info')) {
    /**
     * Get information about installed models
     */
    function get_llm_model_info()
    {
        $modelPath = config('llm.defaults.model_path');
        if (!file_exists($modelPath)) {
            return [];
        }

        $models = [];
        $directories = glob($modelPath . '/*', GLOB_ONLYDIR);

        foreach ($directories as $dir) {
            $infoFile = $dir . '/model_info.json';
            if (file_exists($infoFile)) {
                $info = json_decode(file_get_contents($infoFile), true);
                $models[basename($dir)] = $info;
            }
        }

        return $models;
    }
}

if (!function_exists('get_gpu_status')) {
    /**
     * Get GPU status information
     */
    function get_gpu_status()
    {
        if (!extension_loaded('cuda')) {
            return null;
        }

        try {
            $gpus = [];
            $deviceCount = cuda_get_device_count();

            for ($i = 0; $i < $deviceCount; $i++) {
                cuda_set_device($i);
                $props = cuda_get_device_properties($i);
                
                $gpus[] = [
                    'id' => $i,
                    'name' => $props['name'],
                    'compute_capability' => $props['major'] . '.' . $props['minor'],
                    'total_memory' => $props['total_memory'],
                    'multi_processor_count' => $props['multi_processor_count']
                ];
            }

            return $gpus;
        } catch (\Exception $e) {
            return null;
        }
    }
}

if (!function_exists('memory_get_total')) {
    /**
     * Get total system memory in bytes
     */
    function memory_get_total()
    {
        if (PHP_OS_FAMILY === 'Linux') {
            $meminfo = file_get_contents('/proc/meminfo');
            preg_match('/MemTotal:\s+(\d+)\skB/', $meminfo, $matches);
            return $matches[1] * 1024; // Convert KB to bytes
        }

        // Fallback for other OS
        return php_uname('Windows') ? shell_exec('wmic computersystem get totalphysicalmemory') : 0;
    }
}

if (!function_exists('disk_free_space_recursive')) {
    /**
     * Get free disk space recursively
     */
    function disk_free_space_recursive($path)
    {
        $free = disk_free_space($path);
        if ($free === false) {
            return 0;
        }

        // Check parent directory if current directory is full
        if ($free === 0 && dirname($path) !== $path) {
            return disk_free_space_recursive(dirname($path));
        }

        return $free;
    }
}

if (!function_exists('check_python_environment')) {
    /**
     * Check if Python environment is properly set up
     */
    function check_python_environment()
    {
        $pythonPath = config('llm.python.path');
        
        // Check Python executable
        if (!file_exists($pythonPath)) {
            return false;
        }

        // Check required packages
        $process = Process::run("{$pythonPath} -c 'import torch, transformers, bitsandbytes'");
        return $process->successful();
    }
}

if (!function_exists('validate_model_config')) {
    /**
     * Validate model configuration
     */
    function validate_model_config($model, $size, $variant)
    {
        $validModels = ['llama2', 'mistral'];
        $validSizes = ['7B', '13B', '70B'];
        $validVariants = ['chat', 'instruct', 'base'];

        if (!in_array($model, $validModels)) {
            return false;
        }

        if (!in_array($size, $validSizes)) {
            return false;
        }

        if (!in_array($variant, $validVariants)) {
            return false;
        }

        // Model-specific validations
        if ($model === 'mistral' && $size !== '7B') {
            return false;
        }

        if ($model === 'mistral' && $variant === 'chat') {
            return false;
        }

        return true;
    }
}

if (!function_exists('check_system_requirements')) {
    /**
     * Check if system meets model requirements
     */
    function check_system_requirements($size)
    {
        $minRam = [
            '7B' => 16,
            '13B' => 32,
            '70B' => 64
        ];

        // Check RAM
        $totalRam = memory_get_total() / (1024 * 1024 * 1024); // Convert to GB
        if ($totalRam < $minRam[$size]) {
            return false;
        }

        // Check disk space
        $modelPath = config('llm.defaults.model_path');
        $diskFree = disk_free_space_recursive($modelPath) / (1024 * 1024 * 1024); // Convert to GB
        $requiredSpace = $size === '70B' ? 100 : ($size === '13B' ? 50 : 25);
        
        if ($diskFree < $requiredSpace) {
            return false;
        }

        return true;
    }
}
