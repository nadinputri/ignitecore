<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->text('two_factor_secret')
                ->after('password')
                ->nullable();

            $table->text('two_factor_recovery_codes')
                ->after('two_factor_secret')
                ->nullable();

            $table->timestamp('two_factor_confirmed_at')
                ->after('two_factor_recovery_codes')
                ->nullable();

            $table->boolean('two_factor_enabled')
                ->after('two_factor_confirmed_at')
                ->default(false);

            // Add index for faster lookups
            $table->index('two_factor_enabled');
        });

        // Add settings for 2FA
        if (Schema::hasTable('settings')) {
            DB::table('settings')->insert([
                [
                    'key' => 'two_factor_enabled',
                    'value' => '1',
                    'type' => 'boolean',
                    'group' => 'security',
                    'label' => 'Enable Two Factor Authentication',
                    'description' => 'Allow users to enable two-factor authentication',
                    'is_public' => false,
                    'is_system' => true,
                    'validation_rules' => json_encode(['boolean']),
                    'sort_order' => 1,
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
                [
                    'key' => 'two_factor_mandatory',
                    'value' => '0',
                    'type' => 'boolean',
                    'group' => 'security',
                    'label' => 'Mandatory Two Factor Authentication',
                    'description' => 'Require all users to enable two-factor authentication',
                    'is_public' => false,
                    'is_system' => true,
                    'validation_rules' => json_encode(['boolean']),
                    'sort_order' => 2,
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
            ]);
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Remove 2FA settings first
        if (Schema::hasTable('settings')) {
            DB::table('settings')
                ->whereIn('key', ['two_factor_enabled', 'two_factor_mandatory'])
                ->delete();
        }

        Schema::table('users', function (Blueprint $table) {
            $table->dropIndex(['two_factor_enabled']);
            $table->dropColumn([
                'two_factor_secret',
                'two_factor_recovery_codes',
                'two_factor_confirmed_at',
                'two_factor_enabled',
            ]);
        });
    }
};
