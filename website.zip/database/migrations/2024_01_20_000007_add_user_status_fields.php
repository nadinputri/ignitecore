<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Add admin and support agent flags
            $table->boolean('is_admin')->default(false)->after('remember_token');
            $table->boolean('is_support_agent')->default(false)->after('is_admin');

            // Add user status fields
            $table->string('status')->default('active')->after('is_support_agent');
            $table->timestamp('banned_at')->nullable()->after('status');
            $table->timestamp('suspended_until')->nullable()->after('banned_at');

            // Add indexes for common queries
            $table->index('is_admin');
            $table->index('is_support_agent');
            $table->index('status');
            $table->index('banned_at');
            $table->index('suspended_until');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Drop indexes
            $table->dropIndex(['is_admin']);
            $table->dropIndex(['is_support_agent']);
            $table->dropIndex(['status']);
            $table->dropIndex(['banned_at']);
            $table->dropIndex(['suspended_until']);

            // Drop columns
            $table->dropColumn([
                'is_admin',
                'is_support_agent',
                'status',
                'banned_at',
                'suspended_until',
            ]);
        });
    }
};
