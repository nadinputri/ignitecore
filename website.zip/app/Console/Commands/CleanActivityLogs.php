<?php

namespace App\Console\Commands;

use App\Models\ActivityLog;
use App\Models\Setting;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class CleanActivityLogs extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'activity-logs:clean {--days=90} {--force}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Clean up old activity logs';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $days = $this->option('days');
        $force = $this->option('force');

        // Get retention period from settings if available
        if (!$force) {
            $retentionDays = Setting::get('activity_log_retention_days', $days);
            $days = min($days, $retentionDays); // Use the shorter period
        }

        $date = Carbon::now()->subDays($days);
        
        $this->info("Cleaning activity logs older than {$days} days...");

        try {
            // Get count before deletion for reporting
            $totalCount = ActivityLog::where('created_at', '<', $date)->count();

            if ($totalCount === 0) {
                $this->info('No old logs found to clean.');
                return Command::SUCCESS;
            }

            // Confirm deletion if not forced
            if (!$force && !$this->confirm("This will delete {$totalCount} logs. Continue?")) {
                return Command::SUCCESS;
            }

            // Delete in chunks to avoid memory issues
            $deletedCount = 0;
            ActivityLog::where('created_at', '<', $date)
                ->chunkById(1000, function ($logs) use (&$deletedCount) {
                    foreach ($logs as $log) {
                        $log->delete();
                        $deletedCount++;
                    }
                });

            // Log the cleanup
            Log::info("Cleaned up {$deletedCount} activity logs older than {$days} days.");
            $this->info("Successfully deleted {$deletedCount} old activity logs.");

            return Command::SUCCESS;
        } catch (\Exception $e) {
            Log::error('Failed to clean activity logs: ' . $e->getMessage());
            $this->error('Failed to clean activity logs: ' . $e->getMessage());

            return Command::FAILURE;
        }
    }
}
