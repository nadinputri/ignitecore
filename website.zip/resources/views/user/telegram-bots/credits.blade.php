@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row mb-4">
        <div class="col-md-8">
            <h2>Credit History - {{ $bot->name }}</h2>
        </div>
        <div class="col-md-4 text-end">
            <a href="{{ route('user.telegram-bots.show', $bot) }}" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Bot
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Credit Summary</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <small class="text-muted">Total Credits Used:</small>
                        <div class="h3">{{ number_format($bot->total_credits_used) }}</div>
                    </div>

                    <div class="mb-3">
                        <small class="text-muted">Available Credits:</small>
                        <div class="h4">{{ number_format(auth()->user()->wallet->balance) }}</div>
                    </div>

                    <div class="mb-3">
                        <small class="text-muted">Cost per Message:</small>
                        <div>{{ setting('telegram_bot_credit_cost_per_message', 1) }} credits</div>
                    </div>

                    <a href="{{ route('user.wallet.index') }}" class="btn btn-primary btn-sm w-100">
                        <i class="fas fa-wallet"></i> Add Credits
                    </a>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Usage Statistics</h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <small class="text-muted">Today's Usage:</small>
                        <div class="h5">
                            {{ number_format($credits->where('created_at', '>=', now()->startOfDay())->sum('credits_used')) }}
                        </div>
                    </div>

                    <div class="mb-3">
                        <small class="text-muted">This Month:</small>
                        <div class="h5">
                            {{ number_format($credits->where('created_at', '>=', now()->startOfMonth())->sum('credits_used')) }}
                        </div>
                    </div>

                    <div class="mb-3">
                        <small class="text-muted">Average Daily Usage:</small>
                        <div>
                            {{ number_format($credits->where('created_at', '>=', now()->subDays(30))->sum('credits_used') / 30, 1) }}
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Detailed Credit History</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Date & Time</th>
                                <th>Action</th>
                                <th>Credits</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($credits as $credit)
                                <tr>
                                    <td>{{ $credit->created_at->format('M d, Y H:i') }}</td>
                                    <td>
                                        <span class="badge bg-secondary">
                                            {{ $credit->action_type }}
                                        </span>
                                    </td>
                                    <td>{{ number_format($credit->credits_used) }}</td>
                                    <td>
                                        @if($credit->metadata)
                                            <button type="button" class="btn btn-sm btn-link" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#creditDetails{{ $credit->id }}">
                                                <i class="fas fa-info-circle"></i> View Details
                                            </button>

                                            <!-- Details Modal -->
                                            <div class="modal fade" id="creditDetails{{ $credit->id }}" tabindex="-1">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Transaction Details</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <pre class="bg-light p-3 rounded">{{ json_encode($credit->metadata, JSON_PRETTY_PRINT) }}</pre>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @else
                                            <span class="text-muted">No additional details</span>
                                        @endif
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4" class="text-center py-3">
                                        No credit usage history found
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                @if($credits->hasPages())
                    <div class="card-footer">
                        {{ $credits->links() }}
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection
