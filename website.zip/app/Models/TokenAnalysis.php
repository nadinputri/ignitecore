<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TokenAnalysis extends Model
{
    protected $fillable = [
        'meme_token_id',
        'ai_score',
        'sentiment_analysis',
        'risk_factors',
        'technical_indicators',
        'social_metrics',
        'ai_recommendation',
        'analyzed_at'
    ];

    protected $casts = [
        'sentiment_analysis' => 'array',
        'risk_factors' => 'array',
        'technical_indicators' => 'array',
        'social_metrics' => 'array',
        'ai_score' => 'decimal:2',
        'analyzed_at' => 'datetime'
    ];

    public function memeToken()
    {
        return $this->belongsTo(MemeToken::class);
    }

    public function getRiskLevelAttribute()
    {
        if ($this->ai_score >= 75) return 'Low';
        if ($this->ai_score >= 50) return 'Medium';
        return 'High';
    }

    public function getSentimentSummaryAttribute()
    {
        $sentiment = $this->sentiment_analysis;
        $overall = isset($sentiment['overall']) ? $sentiment['overall'] : 'Neutral';
        $sources = isset($sentiment['sources']) ? count($sentiment['sources']) : 0;
        
        return "{$overall} (based on {$sources} sources)";
    }

    public function getTradeRecommendationAttribute()
    {
        if ($this->ai_score >= 80) return 'Strong Buy';
        if ($this->ai_score >= 60) return 'Buy';
        if ($this->ai_score >= 40) return 'Hold';
        if ($this->ai_score >= 20) return 'Sell';
        return 'Strong Sell';
    }

    public function scopeRecent($query)
    {
        return $query->orderBy('analyzed_at', 'desc');
    }

    public function scopeHighPotential($query)
    {
        return $query->where('ai_score', '>=', 70);
    }
}
