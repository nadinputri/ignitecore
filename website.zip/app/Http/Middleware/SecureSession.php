<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;

class SecureSession
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // Ensure secure cookie settings
        Config::set('session.secure', true);
        Config::set('session.http_only', true);
        Config::set('session.same_site', 'lax');
        
        // Set session security headers
        header('Set-Cookie: ' . config('session.cookie') . '=' . Session::getId() . '; HttpOnly; Secure; SameSite=Lax');

        // Regenerate session ID periodically
        if (!$request->ajax() && 
            (!Session::has('last_session_regeneration') || 
             time() - Session::get('last_session_regeneration') > 300)) { // 5 minutes
            Session::regenerate(true);
            Session::put('last_session_regeneration', time());
        }

        // Check for session fixation
        if (!Session::has('session_token')) {
            Session::put('session_token', Str::random(40));
        }

        // Validate session token
        if ($request->hasSession() && Session::has('session_token')) {
            $token = Session::get('session_token');
            if ($request->hasHeader('X-Session-Token') && $request->header('X-Session-Token') !== $token) {
                Session::flush();
                return response('Session validation failed', 401);
            }
        }

        // Check for session timeout
        if (Session::has('last_activity')) {
            $lastActivity = Session::get('last_activity');
            $timeout = config('session.lifetime') * 60; // Convert minutes to seconds

            if (time() - $lastActivity > $timeout) {
                Session::flush();
                return redirect()->route('login')->with('error', 'Session expired');
            }
        }

        // Update last activity timestamp
        Session::put('last_activity', time());

        // Store client information for security checks
        $clientInfo = [
            'ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'timestamp' => time()
        ];

        if (!Session::has('client_info')) {
            Session::put('client_info', $clientInfo);
        } else {
            // Check for suspicious changes in client information
            $storedInfo = Session::get('client_info');
            if ($storedInfo['ip'] !== $clientInfo['ip'] || 
                $storedInfo['user_agent'] !== $clientInfo['user_agent']) {
                
                // Log suspicious activity
                \Log::warning('Suspicious session activity detected', [
                    'stored' => $storedInfo,
                    'current' => $clientInfo
                ]);

                // Optional: Force re-authentication for security
                if (config('session.strict_security', true)) {
                    Session::flush();
                    return redirect()->route('login')
                        ->with('error', 'Please login again for security reasons');
                }
            }
        }

        // Set security headers
        $response = $next($request);
        
        // Prevent caching of sensitive pages
        if (auth()->check()) {
            $response->headers->set('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
            $response->headers->set('Pragma', 'no-cache');
            $response->headers->set('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT');
        }

        return $response;
    }

    /**
     * Determine if the request path should be excluded from session security
     *
     * @param  string  $path
     * @return bool
     */
    protected function shouldExclude($path)
    {
        $excludedPaths = [
            'assets',
            'css',
            'js',
            'images',
            'favicon.ico'
        ];

        foreach ($excludedPaths as $excludedPath) {
            if (Str::startsWith($path, $excludedPath)) {
                return true;
            }
        }

        return false;
    }
}
