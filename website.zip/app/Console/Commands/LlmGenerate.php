<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\LlmService;
use App\Models\LlmSetting;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class LlmGenerate extends Command
{
    protected $signature = 'llm:generate 
        {prompt : The prompt to send to the LLM}
        {--max-tokens=2048 : Maximum number of tokens to generate}
        {--temperature=0.7 : Sampling temperature}
        {--stream : Stream the output token by token}';

    protected $description = 'Generate text using the Local LLM';

    protected $llmService;

    public function __construct(LlmService $llmService)
    {
        parent::__construct();
        $this->llmService = $llmService;
    }

    public function handle()
    {
        $settings = LlmSetting::getConfig();

        if (!$settings->isReady()) {
            $this->error('LLM is not ready. Please check settings and model installation.');
            return 1;
        }

        $prompt = $this->argument('prompt');
        $options = [
            'max_tokens' => $this->option('max-tokens'),
            'temperature' => $this->option('temperature'),
            'stream' => $this->option('stream')
        ];

        try {
            // Rate limiting check
            $key = 'llm_requests_' . date('YmdH');
            $requests = Cache::get($key, 0);
            
            if ($requests >= $settings->max_requests_per_minute) {
                $this->error('Rate limit exceeded. Please try again later.');
                return 1;
            }

            // Content filtering
            if ($settings->content_filtering && !$this->isContentAllowed($prompt)) {
                $this->error('Content filtered. Please revise your prompt.');
                return 1;
            }

            // Start spinner for non-streaming output
            if (!$options['stream']) {
                $this->output->write('Generating');
                $spinner = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
                $i = 0;
            }

            // Generate response
            $response = $this->llmService->generateResponse($prompt, $options, function ($token) use (&$i, $spinner, $options) {
                if ($options['stream']) {
                    $this->output->write($token);
                } else {
                    $this->output->write("\r" . 'Generating ' . $spinner[$i]);
                    $i = ($i + 1) % count($spinner);
                }
            });

            // Clear spinner line for non-streaming output
            if (!$options['stream']) {
                $this->output->write("\r\033[K");
                $this->line($response);
            }

            // Update rate limiting
            Cache::increment($key);

            // Log request if enabled
            if ($settings->log_requests) {
                Log::channel('llm')->info('Generated response', [
                    'prompt' => $prompt,
                    'response' => $response,
                    'options' => $options,
                    'metrics' => $this->getMetrics()
                ]);
            }

            return 0;

        } catch (\Exception $e) {
            $this->error('Error generating response: ' . $e->getMessage());

            // Log error if enabled
            if ($settings->log_errors) {
                Log::channel('llm')->error('Generation error', [
                    'prompt' => $prompt,
                    'error' => $e->getMessage(),
                    'options' => $options,
                    'metrics' => $this->getMetrics()
                ]);
            }

            return 1;
        }
    }

    protected function isContentAllowed($content)
    {
        $settings = LlmSetting::getConfig();
        
        if (!$settings->blocked_words) {
            return true;
        }

        foreach ($settings->blocked_words as $word) {
            if (stripos($content, $word) !== false) {
                return false;
            }
        }

        return true;
    }

    protected function getMetrics()
    {
        return [
            'memory_usage' => memory_get_usage(true),
            'peak_memory' => memory_get_peak_usage(true),
            'cpu_usage' => sys_getloadavg()[0],
            'gpu_info' => get_gpu_status()
        ];
    }
}
